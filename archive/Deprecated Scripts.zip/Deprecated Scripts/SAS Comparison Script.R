library(tidyverse)
library(compareDF)
library(rio)

Filename <- "idmc"

File <- import(str_c("R:\\ZPSAS\\", Filename, ".sas7bdat"))
Last_Month_File <- import(str_c("R:\\ZPSASPrior\\", Filename, ".sas7bdat"))

File_Fix <- File %>% 
  filter(TYCNO > 1250000) %>% 
  mutate(across(contains("MDY"), ~as.Date(.x, "1960-01-01"))) %>% 
  group_by(TYCNO) %>% 
  mutate(IDMC = row_number()) %>% 
  ungroup()

Last_Month_File_Fix <- Last_Month_File %>% 
  filter(TYCNO > 1250000) %>% 
  mutate(across(contains("MDY"), ~as.Date(.x, "1960-01-01"))) %>% 
  group_by(TYCNO) %>% 
  mutate(IDMC = row_number()) %>% 
  ungroup()

Comparison <- compare_df(File_Fix, 
                         Last_Month_File_Fix, 
                         group_col = c("TYCNO", "IDMC"))

Comparison$change_summary

Comparison$change_count

create_output_table(Comparison, limit = 1000)

write_csv(Comparison$comparison_df, "Comparison Table.csv", na = "")
