library(TJJD)

Job_History <- read_excel("\\\\tjjd4avresaus1\\public\\HR and Analytics\\Job History.xlsx") %>% 
  arrange(`Empl ID`, `Eff Date`, Seq)
Coach_Data <- read_excel("\\\\tjjd4avresaus1\\public\\HR and Analytics\\Coach Data.xlsx")
Coach_Staffing <- read_excel("\\\\tjjd4avresaus1\\public\\HR and Analytics\\Coach Staffing.xlsx")
Facility_Lookup <- read_excel("\\\\tjjd4avresaus1\\public\\HR and Analytics\\CAPPS Facility Code Lookup.xlsx")

colnames(Job_History) <- colnames(Job_History) %>% 
  str_replace_all(" ", "_")

#Remove everything between temporary start and temporary end

Temporary_Starts <- Job_History %>% 
  filter(Rsn_Cd %in% c("041")) %>% 
  group_by(Empl_ID) %>% 
  mutate(Temp_Number = row_number()) %>% 
  ungroup() %>% 
  select(Empl_ID, Temp_Number, Temp_Start = Eff_Date)

Temporary_Ends <- Job_History %>% 
  filter(Rsn_Cd %in% c("042")) %>% 
  group_by(Empl_ID) %>% 
  mutate(Temp_Number = row_number()) %>% 
  ungroup() %>% 
  select(Empl_ID, Temp_Number, Temp_End = Eff_Date)

Temporary_Spells <- Temporary_Starts %>% 
  left_join(Temporary_Ends) %>% 
  mutate(Temp_End = replace_na(Temp_End, today())) %>% 
  rename(Emplo_ID = Empl_ID)

Temporary_Entries <- sqldf("select * from Job_History
                              inner join Temporary_Spells
                              on Empl_ID = Emplo_ID
                           and Temp_Start <= Eff_Date 
                           and Temp_End >= Eff_Date")

Permanent_Job_History <- Job_History %>% 
  anti_join(Temporary_Entries) %>% 
  filter(!str_detect(tolower(Functional_Job_Title), "counsel sub")) %>% 
  group_by(Empl_ID) %>% 
  mutate(First_Entry = min(Eff_Date) == Eff_Date) %>% 
  ungroup() %>% 
  mutate(across(contains(c("Date", "Dt")), ~as.Date(.x)),
         Start_Date = if_else(First_Entry, Last_Asgmt_Start_Dt,
                              if_else(is.na(Term_Dt), Eff_Date, Eff_Date - 1)),
         Hire = if_else(Action %in% c("REH", "HIR", "ADD"), 1, 0),
         Term = if_else(!is.na(Term_Dt), 1, 0)) %>% 
  left_join(Facility_Lookup) %>% 
  group_by(Empl_ID, Start_Date) %>% 
  summarize(Name = last(Name),
            Job_Title = last(Functional_Job_Title),
            Facility = last(Facility),
            Hire = max(Hire),
            Term = max(Term),
            Actions = str_c(Reason_Descr, collapse = ", ")) %>% 
  ungroup() %>% 
  mutate(End_Date = if_else(Term == 1, Start_Date,
                            if_else(Empl_ID == lead(Empl_ID), lead(Start_Date) - 1, today())),
         Start_Month = floor_date(Start_Date, 'month'),
         End_Month = floor_date(End_Date, 'month'),
         Start_FQ = case_when(month(Start_Month) %in% c(9:11) ~ 1,
                              month(Start_Month) %in% c(12, 1, 2) ~ 2,
                              month(Start_Month) %in% c(3:5) ~ 3,
                              month(Start_Month) %in% c(6:8) ~ 4),
         End_FQ = case_when(month(End_Month) %in% c(9:11) ~ 1,
                            month(End_Month) %in% c(12, 1, 2) ~ 2,
                            month(End_Month) %in% c(3:5) ~ 3,
                            month(End_Month) %in% c(6:8) ~ 4),
         Start_FY = State_FY(Start_Month),
         End_FY = State_FY(End_Month))

write_csv(Permanent_Job_History, "\\\\tjjd4avresaus1\\public\\HR and Analytics\\Job History Reformat.csv")

Date_Table <- data.frame(Date = seq.Date(as.Date("2018-09-01"), today(), "day"))
Month_Table <- data.frame(Month = seq.Date(as.Date("2018-09-01"), today(), "month"))

Employment_by_Month <- sqldf("select * from
                           Month_Table
                           inner join Permanent_Job_History
                           on Month>=Start_Month and
                           Month <= End_Month") %>% 
  arrange(Empl_ID, Month) %>% 
  group_by(Month, Empl_ID) %>% 
  summarize(Start_Month = min(Start_Month), 
            End_Month = max(End_Month),
            Name = last(Name),
            Job_Title = last(Job_Title),
            Facility = last(Facility),
            Hire = max(Hire),
            Term = max(Term),
            Actions = str_c(Actions, collapse = ", ")) %>% 
  mutate(Hire = if_else(Hire == 1 & Start_Month == Month, 1, 0))

write_csv(Employment_by_Month, "\\\\tjjd4avresaus1\\public\\HR and Analytics\\Job History Monthly.csv")
