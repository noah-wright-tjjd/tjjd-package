library(TJJD)
library(tidymodels)
library(performance)
library(ranger)

# Pull Data ----

Demographics <- ID_Get() %>%
  select(TJJD_Number, Race, Sex) %>%
  mutate(Race = if_else(Race %in% c("B", "H", "W"), Race, "O"),
         Race = factor(Race, levels = as.ordered(c("H", "B", "W", "O"))),
         Sex = factor(Sex, levels = as.ordered(c("M", "F"))))

Treatment_Needs <- Treatment_Needs_Get("Historical")

ACE_Score_From_PACT <- ACE_Score_Get(Source = "PACT", Timeframe = "Historical")

PACT_Risk <- PACT_Risk_Factor_Get()

Suicide_Assessments <- Suicide_Assessments_Get(Timeframe = "Historical")

CSEIT <- CSEIT_Get()

Assignments <- Assignments_Get("Historical")

# Assemble Dataset ----

Treatment_Needs_Initial_Factored <- Treatment_Needs %>%
  group_by(TJJD_Number) %>%
  summarize_all(first) %>%
  select(TJJD_Number, contains("Priority"), -Intellectual_Disability_Priority, -Medical_Priority) %>%
  mutate(across(contains("Priority"), ~factor(
    str_replace(.x, "HL2", "H"),
    levels = as.ordered(c("None", "L", "M", "H")))))

Secure_Assignments <- Assignments %>%
  filter(Facility_Type %in% c("Secure", "O & A")) %>%
  group_by(TJJD_Number) %>%
  summarize(Secure_Duration = sum(Assignment_Duration)) %>% 
  ungroup()

Suicide_Data <- Suicide_Assessments %>%
  filter(!Assessment %in% c("Not placed on SA", "Remove", NA),
         Facility %in% c("Evins", "Gainesville", "Giddings", "Mart", "Ron Jackson")) %>%
  group_by(TJJD_Number) %>%
  summarize(Initial_Assessments_Unadjusted = sum(Assessment_Type == "Initial"),
            Days_on_SA_Unadjusted = n_distinct(Assessment_Date),
            Ever_Protective = max(Assessment == "Protective")) %>% 
  ungroup()

DF_no_CSEIT <- Secure_Duration %>%
  inner_join(Treatment_Needs_Initial_Factored) %>%
  inner_join(Demographics) %>%
  left_join(Suicide_Data) %>%
  left_join(ACE_Score_From_PACT) %>%
  mutate(across(where(is.numeric), ~replace_na(.x, 0)),
         Initial_Assessments_Adjusted = Initial_Assessments_Unadjusted/Secure_Duration,
         Days_on_SA_Adjusted = (Days_on_SA_Unadjusted/Secure_Duration),
         Days_on_SA_Adjusted_Normal = Days_on_SA_Adjusted^(1/100))

DF_no_CSEIT %>% 
  filter(Days_on_SA_Adjusted>0) %>% 
  ggplot(aes(x = Days_on_SA_Adjusted)) +
  geom_histogram()

DF_CSEIT <- DF_no_CSEIT %>% 
  inner_join(CSEIT)

DF_Split <- DF_no_CSEIT %>%
  filter(Secure_Duration>60,
         Days_on_SA_Adjusted > 0) %>%
  select(Days_on_SA = Days_on_SA_Adjusted_Normal, Race, Sex, contains("Priority"), Emotional_Abuse:ACE_Score) %>%
  initial_split()

DF_train <- training(DF_Split)
DF_test <- testing(DF_Split)

#Assemble models ----

lm_spec <- set_engine(linear_reg(), engine = "lm")

lm_fit <- lm_spec %>%
  fit(Days_on_SA ~ . + Race * Sex,
      data = DF_train
  )

check_model(lm_fit)

lm_fit %>%
  tidy() %>%
  view()

rf_spec <- rand_forest(mode = "regression") %>%
  set_engine("ranger")

rf_fit <- rf_spec %>%
  fit(Days_on_SA ~ .,
      data = DF_train
  )

results_train <- lm_fit %>%
  predict(new_data = DF_train) %>%
  mutate(
    truth = DF_train$Days_on_SA,
    model = "lm"
  ) %>%
  bind_rows(rf_fit %>%
              predict(new_data = DF_train) %>%
              mutate(
                truth = DF_train$Days_on_SA,
                model = "rf"
              ))

results_test <- lm_fit %>%
  predict(new_data = DF_test) %>%
  mutate(
    truth = DF_test$Days_on_SA,
    model = "lm"
  ) %>%
  bind_rows(rf_fit %>%
              predict(new_data = DF_test) %>%
              mutate(
                truth = DF_test$Days_on_SA,
                model = "rf"
              ))

results_train %>%
  group_by(model) %>%
  yardstick::rmse(truth = truth, estimate = .pred, na.rm = TRUE)

results_test %>%
  group_by(model) %>%
  yardstick::rmse(truth = truth, estimate = .pred, na.rm = TRUE)

results_test %>%
  mutate(train = "testing") %>%
  bind_rows(results_train %>%
              mutate(train = "training")) %>%
  ggplot(aes(truth, .pred, color = model)) +
  geom_abline(lty = 2, color = "gray80", size = 1.5) +
  geom_point(alpha = 0.5) +
  facet_wrap(~train) +
  labs(
    x = "Truth",
    y = "Predicted",
    color = "Type of model"
  )
