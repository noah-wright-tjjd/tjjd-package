library(TJJD)

source("R/DB/Warehouse.R")

sqlQuery(Warehouse, "select * from Connect.ruleconductviolation") |> view()

sqlQuery(Warehouse, "select top 10 * from Connect.tv_vwmajorincidentreport") |> view()

MF <- Masterfiles_Get()

Committing_Offenses <- MF %>% 
  filter(Commitment_End_Date == "2099-12-31") %>% 
  count(Determinate_Sentence, Classifying_Offense) %>% 
  pivot_wider(names_from = Determinate_Sentence, values_from = n, values_fill = 0)

Youth <- MF %>% 
  group_by(TJJD_Number) %>%
  filter(max(Commitment_End_Date) >= "2018-09-01")

Names <- ID_Get() %>% 
  select(TJJD_Number, First_Name, Last_Name)

MF_Tags <- MF %>%
  select(TJJD_Number, Commitment_Type) %>%
  unique() %>% 
  mutate(Present = TRUE) %>% 
  pivot_wider(names_from = Commitment_Type, values_from = Present, values_fill = FALSE) %>% 
  filter(RVKD | MCMT | RCMT) %>% 
  select(-CMNT)

Current <- Youth %>% 
  filter(Commitment_End_Date == "2099-12-31")

Offense_History <- Offense_History_Get()

Offense_History_sql <- Offense_History_Get(Source = "sql")

Offense_History_All <- Offense_History_sql %>% 
  left_join(Criminal_Offense_Code_Lookup,by=c("REFCD"="OFFCODE")) %>%
  left_join(Criminal_Offense_Code_Lookup,by=c("ADJCD"="OFFCODE")) %>%
  left_join(Offense_History_Disposition_Lookup) %>%
  mutate(Adjudication_Date=as.Date(ADJMDY,origin="1960-01-01"),
         Referral_Date=as.Date(REFMDY,origin="1960-01-01")) %>%
  select(TJJD_Number=TYCNO,
         Masterfile_Pointer_Number=MFPTR,
         Offense_Number=RECNBR,
         Referral_Date,
         Referral_Offense_Code=REFCD,
         Referral_Offense=OFFDESC.x,
         Referral_Offense_Level=REFLVL,
         Referral_AP = OFFAP.x,
         Adjudication_Date,
         Adjudication_Offense_Code=ADJCD,
         Adjudication_Offense=OFFDESC.y,
         Adjudication_Offense_Level=LEVEL,
         Adjudication_AP = OFFAP.y,
         Disposition_Code = DISP,
         Disposition)

Risk_MLOS <- Risk_MLOS_Get(Source = "SQL")

Risk_MLOS_Format <- Risk_MLOS_Get()

Initial_M040_Counts <- Risk_MLOS  %>%
  mutate(M040_Date = as.Date(str_c(str_pad(startyy, 2, "left", "0"),
                                   str_pad(startmm, 2, "left", "0"),
                                   str_pad(startdd, 2, "left", "0")),
                             "%y%m%d")) %>% 
  select(TJJD_Number = tycno,
         Masterfile_Pointer_Number = mfptr,
         M040_Date,
         Referrals = refs,
         Adjudications = ajds,
         Against_Persons = ap) %>% 
  semi_join(Youth) %>% 
  group_by(TJJD_Number) %>% 
  summarize_all(first)

Detecting <- Offense_History_All %>% 
  count(Referral_Offense_Level, Referral_Offense) %>% 
  pivot_wider(names_from = Referral_Offense_Level, values_from = n)

# 1 = FL (Felony)
# 2 = MI (Misdemeanor)
# 3 = FC (Family Code)

#If referral offense level for 7350 is 3 and adjudication offense level is 1 or 2, count it as 1 or 2.

# The Number of felony/misdemeanor arrests or referrals to juvenile court. 

# 1.	if the referral level of the offense is FL or MI then that is counted for
# the referrals to juvenile court (#1). 
# 2.	If the referral date is the same then count all as 1; Per below examples,
# for Referral date 3/31/07 there are 3 records for FL and hence it is counted
# as 1;

Referral_Estimate <- Offense_History %>% 
  mutate(Referral_Offense_Level_Counting = if_else(Referral_Offense_Level == 3 & Referral_Offense_Code == 7350 & Adjudication_Offense_Level < 3, 
                                                   Adjudication_Offense_Level,
                                                   Referral_Offense_Level)) %>% 
  filter(Referral_Offense_Level_Counting %in% c(1, 2)) %>% 
  left_join(Initial_M040_Counts %>% 
              select(TJJD_Number, M040_Date)) %>% 
  filter(Referral_Date < M040_Date) %>% 
  group_by(TJJD_Number, Masterfile_Pointer_Number) %>% 
  summarize(Referrals_Calc = n_distinct(Referral_Date)) %>% 
  ungroup() %>% 
  semi_join(Youth)

Referrals_Comparison <- Referral_Estimate %>% 
  inner_join(Initial_M040_Counts) %>% 
  semi_join(Youth) %>% 
  mutate(Referrals_Match = Referrals_Calc == Referrals)

mean(Referrals_Comparison$Referrals_Match)

Referrals_Mismatch <- Offense_History %>% 
  semi_join(Referrals_Comparison %>% 
              filter(!Referrals_Match))
  

# The Number of felony arrests or referrals for offenses against a person.
#
# 1.	If the disposition code is one of AP/AT/PT/ND/CA/AD/CS/PD and the offense
# level is not FC then it is counted in #2 (Number of Felony Arrests or
# Referrals for Offenses Against Persons)

Felony_AP_Estimate <- Offense_History_All %>% 
  mutate(Referral_Offense_Level_Counting = if_else(Referral_Offense_Level == 3 & Referral_Offense_Code == 7350 & Adjudication_Offense_Level < 3, 
                                                   Adjudication_Offense_Level,
                                                   Referral_Offense_Level)) %>% 
  left_join(Initial_M040_Counts %>% 
              select(TJJD_Number, M040_Date)) %>% 
  filter(Referral_Date < M040_Date,
         Referral_Offense_Level_Counting == 1,
         Referral_AP == "Y" | Adjudication_AP == "Y") %>% 
  group_by(TJJD_Number, Masterfile_Pointer_Number) %>% 
  summarize(Against_Persons_Calc = n_distinct(Referral_Date)) %>% 
  ungroup() %>% 
  semi_join(Youth)


Felony_APs_Comparison <- Felony_AP_Estimate %>% 
  inner_join(Initial_M040_Counts) %>% 
  semi_join(Youth) %>% 
  mutate(Felony_APs_Match = Against_Persons_Calc == Against_Persons)

mean(Felony_APs_Comparison$Felony_APs_Match)

Felony_APs_Mismatch <- Offense_History %>% 
  semi_join(Felony_APs_Comparison %>% 
              filter(!Felony_APs_Match))


# The  Number of felony/misdemeanor convictions or adjudications

#1.	If the offense level is 'FL' then the referral is checked against the Code
#file has the AP flag set to 'Y' then it is counted in #3 (Number of Felony and
#or Misdemeanor Convictions or Adjudications

#Count against persons? Is that what these instructions are saying?

Adjudication_Estimate <- Offense_History_All %>% 
  left_join(Initial_M040_Counts %>% 
              select(TJJD_Number, M040_Date)) %>% 
  filter(Referral_Date < M040_Date,
         Referral_Offense_Level %in% c(1, 2) | Adjudication_Offense_Level %in% c(1, 2),
         Disposition_Code %in% c("AP", "AT", "AD", "PD", "PT", "ND", "CA", "CS")) %>% 
  group_by(TJJD_Number, Masterfile_Pointer_Number) %>% 
  summarize(Adjudications_Calc = n_distinct(Adjudication_Date)) %>% 
  ungroup() %>% 
  semi_join(Youth)

Adjudication_Estimate2 <- Offense_History_All %>% 
  left_join(Initial_M040_Counts %>% 
              select(TJJD_Number, M040_Date)) %>% 
  filter(Referral_Date < M040_Date,
         Referral_Offense_Level %in% c(1, 2) | Adjudication_Offense_Level %in% c(1, 2),
         Disposition_Code %in% c("AP", "AT", "AD", "PD", "CA",  "ND", "CS")) %>% 
  group_by(TJJD_Number, Masterfile_Pointer_Number) %>% 
  summarize(Adjudications_Calc = n_distinct(Adjudication_Date)) %>% 
  ungroup() %>% 
  semi_join(Youth)

Adjudications_Comparison <- Adjudication_Estimate %>% 
  inner_join(Initial_M040_Counts) %>% 
  semi_join(Youth) %>% 
  mutate(Adjudications_Match = Adjudications_Calc == Adjudications)

Adjudications_Comparison2 <- Adjudication_Estimate2 %>% 
  inner_join(Initial_M040_Counts) %>% 
  semi_join(Youth) %>% 
  mutate(Adjudications_Match = Adjudications_Calc == Adjudications)

mean(Adjudications_Comparison$Adjudications_Match)
mean(Adjudications_Comparison2$Adjudications_Match)

Adjudications_Mismatch <- Offense_History %>% 
  semi_join(Adjudications_Comparison %>% 
              filter(!Adjudications_Match))

All_Estimates <- Names %>% 
  left_join(MF_Tags) %>% 
  inner_join(Initial_M040_Counts) %>% 
  inner_join(Referral_Estimate) %>% 
  full_join(Adjudication_Estimate) %>% 
  full_join(Felony_AP_Estimate) %>% 
  mutate(across(contains("Calc"), ~replace_na(.x, 0)),
         across(c(MCMT, RCMT, RVKD), ~replace_na(.x, FALSE)),
         Referral_Diff = Referrals - Referrals_Calc,
         Adjudications_Diff = Adjudications - Adjudications_Calc,
         Against_Persons_Diff = Against_Persons - Against_Persons_Calc) %>% 
  select(TJJD_Number:M040_Date, contains("Referral"), contains("Adjudic"), contains("Against"))

All_Mismatches <- All_Estimates %>% 
  filter(Referral_Diff != 0 | Adjudications_Diff != 0 | Against_Persons_Diff != 0) %>% 
  semi_join(Current)

Mismatch_Histories <- Offense_History_All %>% 
  semi_join(All_Mismatches)

write_csv(All_Mismatches, "All Count Mismatch Youth.csv", na = "")
write_csv(Mismatch_Histories, "All Mismatch Offense Histories.csv", na = "")
