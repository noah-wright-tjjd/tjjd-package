library(TJJD)

Incidents <- Incidents_Get()

Rule_Violations <- Incident_Rule_Violations_Get()

RV_Indicators <- Rule_Violations %>% 
  group_by(TJJD_Number, Incident_Pointer_Number) %>% 
  summarize(Gang = sum(str_detect(All_Rule_Violations, "Gang")),
         MajDis = str_detect(All_Rule_Violations, "Major Disruption"),
         Escape = str_detect(All_Rule_Violations, "Escape"),
         Fleeing = str_detect(All_Rule_Violations, "Flee"))
  
Incidents_Raw <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=IRD035",rows_at_time=1),
         "SELECT TYCNO, ASPTR, ICPTR, STAFPER, LOC, STUDORM, LOCPLACE, STMDY, ITIME, REFSD, SELFREF, CATCODE, CATEGORY, ASSTA_AI, ASSTA_AO, ASSTU_AF, ASSTU_AY, ESC, ATTESC, FLEEAPP, PartMajDisFac, GANGACT, SuicidalBehav, SuicidalIdeation, STAFINJ, CATYI, CRITINJ, FORCE, AGENT, RESTRAIN, MRSCNTRL, MRSROUT
         FROM EVNTIC
         WHERE IYY<30 AND IYY>16")

Incidents <- Incidents_Raw %>% 
  mutate(Incident_URL=str_c("http://main.tyc.state.tx.us/ccsw/ccswp_i225_detail?F_TYCNBR=",TYCNO,"&F_PTR=",ICPTR),
         Incident_Date=as.Date(STMDY,origin="1960-01-01"),
         Incident_Month = floor_date(Incident_Date, 'month'),
         Incident_Time=str_pad(ITIME,4,pad="0"),
         Assault_On_Staff=if_else((is.na(ASSTA_AI)==FALSE|is.na(ASSTA_AO)==FALSE), 1, 0),
         Assault_On_Youth=if_else((is.na(ASSTU_AF)==FALSE|is.na(ASSTU_AY)==FALSE), 1, 0),
         Any_Restraint=if_else(is.na(FORCE)==FALSE|(is.na(RESTRAIN)==FALSE|is.na(AGENT)==FALSE|is.na(RESTRAIN)==FALSE|is.na(MRSCNTRL)==FALSE), 1, 0),
         Escape_or_Attempted=if_else((is.na(ATTESC)==FALSE|is.na(ESC)==FALSE), 1, 0),
         across(.cols = ASSTA_AI:MRSROUT, ~if_else(is.na(.x), 0, 1))) %>%
  select(TJJD_Number=TYCNO,
         Assignment_Pointer_Number=ASPTR,
         Incident_Pointer_Number=ICPTR,
         Incident_URL,
         Incident_Staff_Name=STAFPER,
         Location_Code=LOC,
         Dorm=STUDORM,
         Place_Code=LOCPLACE,
         Incident_Date,
         Incident_Month,
         Use_Of_Chemical_Agent=AGENT,
         Any_Restraint,
         Assault_On_Youth,
         Assault_On_Staff,
         Escape_or_Attempted,
         Fleeing_Apprehension = FLEEAPP,
         Gang=GANGACT,
         Gang = GANGACT,
         Major_Disruption = PartMajDisFac, 
         Manual_Restraint=FORCE,
         Mechanical_Restraints_Used_In_Security=RESTRAIN,
         Mechanical_Restraints_Used_For_Control=MRSCNTRL,
         Mechanical_Restraints_Used_During_Non_Routine_Transportation=MRSROUT) %>%
  left_join(Location_Type_Lookup) %>%
  left_join(Place_Code_Lookup)


Summary<-Incidents %>% 
  group_by(Incident_Month, Assignment_Location) %>% 
  summarize(across(where(is.numeric), sum)) %>% 
  select(-contains("Number"))

Summary_Facility<-Incidents %>% 
  filter(Incident_Month>=as.Date("2020-01-01"),
         Incident_Month<=as.Date("2020-08-01")) %>% 
  group_by(Assignment_Location) %>% 
  summarize(across(where(is.numeric), sum)) %>% 
  select(-contains("Number"))

write_csv(Summary, "Initial Summary.csv")
