library(TJJD)

Assignments <- Assignments_Get("Historical")

MF <- MF_Get("Historical") |> 
  fill(Determinate_Sentence)

Day1 <- "2015-08-31"
Day2 <- "2024-08-31"

All_Assigned_2015 <- Assignments |> 
  filter(Assignment_Start_Date <= Day1,
         Assignment_End_Date >= Day1) |> 
  inner_join(MF |> 
      filter(Admission_Date <= Day1,
             Commitment_End_Date >= Day1) |> 
        select(TJJD_Number, Determinate_Sentence) |> 
        unique()) |> 
  mutate(Facility_Type = if_else(Facility_Type == "O & A", "Secure", Facility_Type)) |> 
  count(Facility_Type, Determinate_Sentence) |> 
  group_by(Facility_Type) |> 
  summarize(Percent = n/sum(n))

All_Assigned_2024 <- Assignments |> 
  filter(Assignment_Start_Date <= Day2,
         Assignment_End_Date >= Day2) |> 
  inner_join(MF |> 
               filter(Admission_Date <= Day2,
                      Commitment_End_Date >= Day2) |> 
               select(TJJD_Number, Determinate_Sentence) |> 
               unique()) |> 
  mutate(Facility_Type = if_else(Facility_Type == "O & A", "Secure", Facility_Type)) |> 
  count(Facility_Type, Determinate_Sentence) |> 
  group_by(Facility_Type) |> 
  summarize(Percent = n/sum(n))



Assignments |> 
  filter()

Daily_Pop |> 
  filter(Date == "2025-02-20") |> 
  group_by(Facility) |> 
  summarize(Pop= sum(Total_Population)) |> 
  view()

MF <- MF_Get()

AS <- Assignments_Get()

Initial_MF <- MF |> 
  filter(Commitment_Type != "RVKD") |> 
  group_by(TJJD_Number) |> 
  summarize_all(first) |> 
  ungroup()

AS_Current <- Initial_MF |> 
  inner_join(AS |> 
  filter(Assignment_End_Date == "2099-12-31")) |> 
  mutate(Facility_Type = if_else(Facility_Type == "O & A", "Secure", Facility_Type)) |> 
  count(Facility_Type, Classifying_Offense_Felony_Level) |> 
  pivot_wider(names_from = Facility_Type, values_from = n, values_fill = 0)

write_csv(AS_Current, "Current by offense.csv")
