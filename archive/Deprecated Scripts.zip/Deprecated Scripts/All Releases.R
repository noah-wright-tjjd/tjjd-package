library(TJJD)
  
Assignments <- Assignments_Get()
Masterfiles <- MF_Get()

  
  Assignment_Release <- Assignments %>%
    mutate(Initial_MLOS_MPOC = first(MLOS_MPOC_Date)) %>%
    ungroup() %>%
    filter(is.na(Temporary) | Temporary == "N") %>%
    left_join(Assignments %>%
                mutate(Assignment_Pointer_Number = Assignment_Pointer_Number + 1) %>%
                select(TJJD_Number, Assignment_Pointer_Number, Release_From = Assignment_Location, Prior_MLOS_MPOC = MLOS_MPOC_Date, Prior_Movement_Type = Movement_Type, Prior_Movement_Code = Movement_Code, Prior_Movement_Description = Movement_Description, Prior_Temporary = Temporary, Prior_Security_Level = Security_Level, Prior_Facility_Type = Facility_Type)) %>%
    filter(Prior_Security_Level %in% c("Secure", "O & A"),
           !Security_Level %in% c("Secure", "O & A")) %>%
    mutate(Release_Date = Assignment_Start_Date,
           Release_FY = State_FY(Release_Date),
           Prior_Movement_Code = case_when(
             Prior_Facility_Type == "Contract Care" ~ "Secure Contract",
             Prior_Movement_Code %in% c("SCOP", "RPR") ~ Prior_Movement_Code,
             Prior_Movement_Code == "IP" & Assignment_Pointer_Number <= 3 ~ "Initial",
             Parole_Status == "N" ~ "Other_Inst",
             TRUE ~ "Other_Parole"),
           Release_Before_Initial_MLOS = Release_Date < Initial_MLOS_MPOC,
           Release_Before_Extended_MLOS = Release_Date < Prior_MLOS_MPOC)
  
  Commitment_Release <- Masterfiles %>%
    filter(Commitment_Type != "RVKD",
           !is.na(Discharge_Date)) %>%
    mutate(Release_Date = Discharge_Date,
           Release_Type = "Discharge",
           Release_Type_Description = "Discharged to Community") %>%
    filter(!Discharge_Reason_Code %in% c("STAD", "JAIL", "TTDC", "DIED", "JACT", NA)) %>%
    select(TJJD_Number, Determinate_Sentence, Release_Date, Release_Type)
  
  Secure_Release <- Assignment_Release %>%
    mutate(Release_FY = State_FY(Assignment_Start_Date)) %>%
    select(TJJD_Number, Release_From, Release_To = Assignment_Location, Release_Date = Assignment_Start_Date, Release_Type = Prior_Movement_Code, Release_Description = Prior_Movement_Description) %>%
    bind_rows(Commitment_Release)
  
  Secure_Release_by_Month <- Secure_Release %>% 
    filter(Release_Date >= "2018-09-01") %>% 
    group_by(Month = floor_date(Release_Date, "month")) %>% 
    summarize(Releases = n(),
              Discharge_Release = sum(Release_Type == "Discharge"),
              Assignment_Release = Releases - Discharge_Release)
  
  Secure_Release_by_FQ <- Secure_Release_by_Month %>% 
    filter(Month <= "2024-05-01") %>% 
    group_by(FY = State_FY(Month),
             FQ = State_FQ(Month),
             FYFQ = str_c("FY", FY, "-FQ", FQ)) %>% 
    summarize(across(is.numeric, sum)) %>% 
    ungroup()

ADP_by_FQ <- 
  
write_csv(Secure_Release_by_FQ, "Secure Release.csv")  

  Secure_Release_by_FQ %>% 
    ggplot(aes(x = FYFQ, y = Assignment_Release, group = 1)) +
    geom_line()
  
Revocations <- MF %>% 
  fill(Determinate_Sentence) %>% 
  filter(Commitment_Type == "RVKD",
         Determinate_Sentence == "N") %>% 
  count(Month = floor_date(Admission_Date, "month")) %>% 
  write_csv("Revocations.csv")
  
  Secure_Release_by_Month %>% 
    write_csv("Secure Release by Month.csv")
  