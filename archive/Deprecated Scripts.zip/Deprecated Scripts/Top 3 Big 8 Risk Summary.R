library(tidyverse)

Big8_Probation <- read_csv("Data Sources/All Probation PACT Big 8.csv")

Big8_Simple <- Big8_Probation %>% 
  select(TJJD_NUMBER, COUNTY_NAME, DATE_COMPLETED, RISK_LEVEL, contains("Big8")) %>% 
  pivot_longer(contains("Big8"), names_to = "Factor", values_to = "Score") %>% 
  filter(!str_detect(Factor, "Other")) %>% 
  separate(Factor, c("Big8", "Type"), sep = " - ") %>% 
  pivot_wider(names_from = Type, values_from = Score) %>% 
  rename(Overall_Risk_Category = RISK_LEVEL,
         Risk = Big8RiskFactor, 
         Protective = Big8ProtectiveFactor) %>% 
  group_by(Big8) %>% 
  mutate(Max_Risk = max(Risk)) %>% 
  ungroup()

Youth_Top_3 <- Big8_Simple %>% 
  mutate(Risk_Percent = Risk/Max_Risk) %>% 
  arrange(TJJD_NUMBER, -Risk_Percent) %>% 
  group_by(TJJD_NUMBER) %>% 
  mutate(Rank = row_number()) %>% 
  ungroup() %>% 
  filter(Rank <= 3,
         Risk > 0)

Top_3_Summary <- Youth_Top_3 %>% 
  group_by(Overall_Risk_Category) %>% 
  mutate(Youth_in_Category = n_distinct(TJJD_NUMBER)) %>% 
  group_by(Overall_Risk_Category, Big8) %>% 
  summarize(Youth = n(),
            Youth_in_Category = mean(Youth_in_Category),
            Percent_of_Risk_Category = Youth/Youth_in_Category) %>% 
  ungroup() %>% 
  select(-Youth, -Youth_in_Category) %>% 
  pivot_wider(names_from = Overall_Risk_Category,
              values_from = c(Percent_of_Risk_Category)) %>% 
  select(Big8, High, Moderate, Low)
