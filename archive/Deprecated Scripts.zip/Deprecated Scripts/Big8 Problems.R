library(TJJD)

options(scipen = 999)

Big8_Probation <- read_csv("Data Sources/All Probation PACT Big 8.csv")

Big8_Simple <- Big8_Probation %>% 
  select(TJJD_NUMBER, COUNTY_NAME, DATE_COMPLETED, RISK_LEVEL, contains("Big8")) %>% 
  pivot_longer(contains("Big8"), names_to = "Factor", values_to = "Score") %>% 
  filter(!str_detect(Factor, "Other")) %>% 
  separate(Factor, c("Big8", "Type"), sep = " - ") %>% 
  pivot_wider(names_from = Type, values_from = Score) %>% 
  rename(Overall_Risk = RISK_LEVEL,
         Risk = Big8RiskFactor, 
         Protective = Big8ProtectiveFactor) %>% 
  mutate(Buffer = Protective-Risk,
         Big4 = Big8 %in% c("Antisocial Behavior", "Antisocial Personality", "Criminal Associates", "Criminal Thinking"),
         At_Risk = Risk > Protective) %>% 
  group_by(Big8) %>% 
  mutate(Max_Risk = max(Risk)) %>% 
  ungroup()

Youth_Top_3 <- Big8_Simple %>% 
  mutate(Risk_Percent = Risk/Max_Risk) %>% 
  arrange(TJJD_NUMBER, -Risk_Percent) %>% 
  group_by(TJJD_NUMBER) %>% 
  mutate(Rank = row_number()) %>% 
  ungroup() %>% 
  filter(Rank <= 3)

Top_3_Summary <- Youth_Top_3 %>% 
  group_by(Overall_Risk) %>% 
  mutate(Youth_in_Category = n_distinct(TJJD_NUMBER)) %>% 
  group_by(Overall_Risk, Big8) %>% 
  summarize(Youth = n(),
            Youth_in_Category = mean(Youth_in_Category),
            Percent_of_Risk_Category = Youth/Youth_in_Category) %>% 
  ungroup() %>% 
  select(-Youth, -Youth_in_Category) %>% 
  pivot_wider(names_from = Overall_Risk,
              values_from = c(Percent_of_Risk_Category)) %>% 
  select(Big8, High, Moderate, Low)

At_Risk_Summary <- Big8_Simple %>% 
  group_by(FY = State_FY(DATE_COMPLETED), Overall_Risk, Big8) %>% 
  summarize(Youth = n(),
            Youth_at_Risk = sum(At_Risk),
            Percent_at_Risk = Youth_at_Risk/Youth) %>% 
  ungroup() %>% 
  select(-Youth, -Youth_at_Risk) %>% 
  pivot_wider(names_from = Overall_Risk,
              values_from = Percent_at_Risk) %>% 
  select(FY, Big8, High, Moderate, Low)

Statewide_Risk <- Big8_Simple %>% 
  group_by(Overall_Risk) %>% 
  summarize(Statewide_Youth = n_distinct(TJJD_NUMBER)) %>% 
  ungroup() %>% 
  mutate(Statewide_Percent = Statewide_Youth/sum(Statewide_Youth))

Department_Risk <- Big8_Simple %>% 
  group_by(Overall_Risk, COUNTY_NAME) %>% 
  summarize(Youth = n_distinct(TJJD_NUMBER)) %>% 
  group_by(COUNTY_NAME) %>% 
  mutate(Percent = Youth/sum(Youth)) %>% 
  ungroup() %>% 
  left_join(Statewide_Risk)
  

Big8_Summary <- Big8_Simple %>% 
  group_by(Overall_Risk, Big8, FY = State_FY(DATE_COMPLETED)) %>% 
  summarize(Youth = n_distinct(TJJD_NUMBER),
            Mean = mean(Risk)) %>% 
  filter(FY < 2023) %>% 
  select(-Youth) %>% 
  pivot_wider(names_from = FY,
              values_from = Mean)

ggplot(Big8_Simple %>% 
         filter(str_detect(Big8, "Behavior")), aes(x = Risk)) +
  geom_histogram() +
  facet_wrap(~Big8)
