EmployeeSummary<-EmployeeSummaryGet()

write_csv(EmployeeSummary,str_c("Produced Datasets\\Turnover History\\PG2 Data Logs\\Employee Data ",today(),".csv"))

Coaches<-EmployeeSummary %>%
  filter(str_detect(JobCodeDescription,"JCO")==TRUE)

TerminationData<-read_excel("Data sources\\Most Recent Termination Type.xlsx") %>%
  mutate(EmployeeID=as.numeric(`Empl ID`),
         StartDate=as.Date(`Last Start`),
         EndDate=as.Date(`Term Date`)) %>%
  select(EmployeeID,
         Title=`Functional Title`,
         StartDate,
         EndDate,
         TerminationType=Descr)

#Separate out identifying data for coaches from spells of employment


CoachIDTable<-Coaches %>%
  select(EmployeeID:StateSeniorityDate,CCSLocCode:FacilityType)

PG2CoachPositions<-Coaches %>%
  mutate(StartDate=if_else(is.na(CEIRehireDate)==FALSE&CEIRehireDate>PG2LastHireDate,CEIRehireDate,PG2LastHireDate)) %>%
  select(EmployeeID,
         Title=JobCodeDescription,
         StartDate,
         EndDate=TerminationDate)


#Add Termination Type to original data

MostRecentTermType<-TerminationData %>%
  group_by(EmployeeID) %>%
  summarize(EndDate=max(EndDate)) %>%
  inner_join(TerminationData) %>%
  select(EmployeeID,TerminationType)

PG2CoachPositions<-PG2CoachPositions %>%
  left_join(MostRecentTermType)

#Identify rehires

Rehires<-PG2CoachPositions %>%
  filter(is.na(EndDate)==TRUE,
         is.na(TerminationType)==FALSE) %>%
  select(EmployeeID) %>%
  inner_join(TerminationData)

#Add rehires back into data and identify employment spells

CoachPositionTable<-bind_rows(PG2CoachPositions,Rehires) %>%
  mutate(TerminationType=if_else(is.na(EndDate)==TRUE,"Currently Employed",TerminationType)) %>%
  unique() %>%
  arrange(EmployeeID,StartDate) %>%
  group_by(EmployeeID) %>% 
  mutate(EmploymentSpellNumber = row_number())


AllCoaches<-CoachIDTable %>%
  inner_join(CoachPositionTable) %>%
  mutate(TenureDate=if_else(is.na(EndDate)==TRUE,today(),EndDate),
         Tenure=as.numeric(TenureDate-StartDate)/365,
         StateTenure=as.numeric(TenureDate-StateSeniorityDate)/365,
         StartMonth=floor_date(StartDate,'month'),
         StartQuarter=quarter(StartDate,with_year=TRUE,fiscal_start=9),
         EndMonth=floor_date(EndDate,'month'),
         CoachTenure=if_else(Tenure<.25,"<3mos",
                             if_else(Tenure>=.25 & Tenure<2,"3mos-2yrs",
                                     if_else(Tenure>=2 & Tenure<5,"2yrs-5yrs",
                                             "5yrs+"))))

write_csv(AllCoaches,str_c("Produced Datasets\\Turnover History\\Quarterly Turnover Files\\Dataset used for ",today(),".csv"))

MonthTable<-data.frame(Month=seq.Date(as.Date("2018-09-01"),floor_date(today(),'month')-1,'month'))

CoachHistory<-sqldf('SELECT * FROM MonthTable
      inner join AllCoaches
      ON StartMonth<=Month AND TenureDate>=Month') %>%
  mutate(TenureFromMonthStart=(Month-StartDate)/365,
         CoachTenure=if_else(TenureFromMonthStart<.25,"<3mos",
                             if_else(TenureFromMonthStart>=.25 & TenureFromMonthStart<2,"3mos-2yrs",
                                     if_else(TenureFromMonthStart>=2 & TenureFromMonthStart<5,"2yrs-5yrs",
                                             "5yrs+"))))



#Quarterly Totals####

Coaches.Quarterly.Count<-CoachHistory %>%
  mutate(NumericMonth=month(Month),
         NumericYear=year(Month),
         FiscalMonth=if_else(NumericMonth>8,NumericMonth-8,NumericMonth+4),
         FiscalYear=if_else(FiscalMonth<5,NumericYear+1,NumericYear),
         FiscalQuarter=if_else(FiscalMonth<4,1,
                               if_else(FiscalMonth<7,2,
                                       if_else(FiscalMonth<10,3,4)))) %>%
  group_by(FiscalYear,FiscalQuarter,FacilityType,Facility) %>%
  summarize(AllCoaches=n_distinct(EmployeeID),
            AverageTenure=mean(TenureFromMonthStart))

Coaches.Quarterly.Terminations<- AllCoaches %>%
  mutate(NumericMonth=month(EndMonth),
         NumericYear=year(EndMonth),
         FiscalMonth=if_else(NumericMonth>8,NumericMonth-8,NumericMonth+4),
         FiscalYear=if_else(FiscalMonth<5,NumericYear+1,NumericYear),
         FiscalQuarter=if_else(FiscalMonth<4,1,
                               if_else(FiscalMonth<7,2,
                                       if_else(FiscalMonth<10,3,4)))) %>%
  group_by(FiscalYear,FiscalQuarter,FacilityType,Facility) %>%
  summarize(AllTerminations=n(),
            AverageTermTenure=mean(Tenure))

Coaches.Quarterly.Hires<-AllCoaches %>%
  mutate(NumericMonth=month(StartMonth),
         NumericYear=year(StartMonth),
         FiscalMonth=if_else(NumericMonth>8,NumericMonth-8,NumericMonth+4),
         FiscalYear=if_else(FiscalMonth<5,NumericYear+1,NumericYear),
         FiscalQuarter=if_else(FiscalMonth<4,1,
                               if_else(FiscalMonth<7,2,
                                       if_else(FiscalMonth<10,3,4)))) %>%
  group_by(FiscalYear,FiscalQuarter,FacilityType,Facility) %>%
  summarize(AllHires=n())

Coaches.Quarterly.Population<-Coaches.Quarterly.Count %>%
  left_join(Coaches.Quarterly.Terminations) %>%
  left_join(Coaches.Quarterly.Hires) %>%
  mutate_all(~replace(., is.na(.), 0)) %>%
  mutate(NetCoachGain=AllHires-AllTerminations,
         AllTurnover=AllTerminations/AllCoaches)

# Dunno what I was doing here:
#   Coaches.Quarterly.Population<-CoachHistory %>%
#   group_by(Month,FacilityType,Facility) %>%
#   summarize(AllCoaches=n_distinct(EmployeeID)) %>%
#   left_join(
#     AllCoaches %>%
#       group_by(Month=EndMonth,FacilityType,Facility) %>%
#       summarize(AllTerminations=n())) %>%
#   left_join(
#     AllCoaches %>%
#       group_by(Month=StartMonth,FacilityType,Facility) %>%
#       summarize(AllHires=n())) %>%
#   mutate_all(~replace(., is.na(.), 0)) %>%
#   mutate(NetCoachGain=AllHires-AllTerminations,
#          AllTurnover=AllTerminations/AllCoaches,
#          NumericMonth=month(Month),
#          NumericYear=year(Month),
#          FiscalMonth=if_else(NumericMonth>8,NumericMonth-8,NumericMonth+4),
#          FiscalYear=if_else(FiscalMonth<5,NumericYear+1,NumericYear),
#          FiscalQuarter=if_else(FiscalMonth<4,1,
#                                if_else(FiscalMonth<7,2,
#                                        if_else(FiscalMonth<10,3,4)))
#   )


write_csv(Coaches.Quarterly.Population,str_c("Produced Datasets\\Turnover History\\Quarterly Turnover Files\\Quarterly Turnover as of ",today(),".csv"))
write_csv(Coaches.Quarterly.Population,str_c("Produced Datasets\\Most Recent Quarterly Turnover.csv"))


Pop.Historical<-sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=URD033",rows_at_time=1),
                         "SELECT * from
           Loccode_Dailypop") %>%
  mutate(Date=as.Date(DAY,origin="1960-1-1")) %>%
  select(Date,
         TotalPopulation=POP,
         FemalePopulation=TotFem,
         LocationCode=LOCCODE) %>%
  full_join(sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=IRD035",rows_at_time=1),
                     "SELECT Date, LOC as LocationCode, count(TYCNO) as TotalAssignments
              FROM POPASFIXED
              left join DateCalendar on ASMDY<=SASDate and EASMDY>SASDate
              WHERE Date>='2014-01-01' and Date<GETDATE()
              GROUP BY LOC, Date") %>%
              mutate(Date=as.Date(Date))) %>%
  left_join(LocationTypeLookup)