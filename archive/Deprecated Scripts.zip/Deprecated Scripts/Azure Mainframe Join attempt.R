library(TJJD)

Employees <- Employee_Summary_Get()
Azure <- read_excel("Azure.xlsx")
Mainframe <- read_excel("Mainframe.xlsx")

#Need a regex that takes everything up to the first space and then omits everything after

Employee_Match <- Employees %>% 
  separate(Name, c("LastName", "FirstName"), sep = ", ") %>% 
  mutate(First = toupper(str_extract(FirstName, "[:alpha:]+")),
         Last = toupper(str_extract(LastName, "[:alpha:]+")),
         Title = toupper(Job_Code_Description),
         Location = Assignment_Location,
         Email = tolower(Email)) %>% 
  select(First, FirstName, Last, LastName, Location, Email)

Employee_Duplicates <- Employee_Match %>% 
  group_by(First, Last, Location) %>% 
  filter(n() > 1) %>% 
  filter()

Employee_Duplicates <- Employee_Match %>% 
  group_by(First, Last, Location) %>% 
  filter(n() > 1)

Azure_Match <- Azure %>% 
  mutate(Email = tolower(mail)) %>% 
  select(-mail) %>% 
  inner_join(Employee_Match)

Azure_Duplicat <- Azure_Match

Mainframe_Match <- Mainframe %>% 
  mutate(First = toupper(str_extract(`First Name`, "[:alpha:]+")),
         Last = toupper(str_extract(`Last Name`, "[:alpha:]+")),
         Title = toupper(Title)) %>% 
  select(M204_Userid = Userid,
         First,
         Last,
         Location)

Azure_Mainframe_Matches <- Mainframe_Match %>% 
  inner_join(Azure_Match %>% 
               group_by(First, Last, Location) %>% 
               summarize_all(last)) %>% 
  select(-Title)

write_csv(Azure_Mainframe_Matches, "Azure-Mainframe Matches.csv", na = "")
