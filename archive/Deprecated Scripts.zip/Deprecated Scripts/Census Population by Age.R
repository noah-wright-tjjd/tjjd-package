#Setup ####

rm(list=ls())

library(tidycensus)
library(tidyverse)

# library(skmeans)
# library(stringr)
# library(httr)
# library(readr)
# library(sf)
# library(maptools)
# library(GGally)
# library(cluster)
# library(factoextra)
# library(tmap)
# library(cartogram)

census_api_key("6fd505a0c0bea6451a39a092047309ac838de149",install=TRUE,overwrite=TRUE)
#for (i in 2009:2016) {acs5yrallvar[i-2008]<-load_variables(year=i,dataset="acs5", cache = TRUE)}

fips<-fips_codes
states<-unique(fips_codes$state)[1:51]
ACSVars<-load_variables(2020, "acs5", cache=TRUE)
DecennialVars <- load_variables(2020, "pl", cache = TRUE)

#Within states: "place", "county", "tract"
#Stateless: "metropolitan statistical area/micropolitan statistical area", "zcta" (zip code tabulation area)

GeometryPop_Grab <- function(Geogr, Years = 2020) {
  if(Geogr == "state" | Geogr == "county") {
    map_df(Years, ~get_acs(year = .x, geography = Geogr, variables = "B01001_001", geometry = TRUE, shift_geo = TRUE) %>% 
             mutate(Year = .x)
    )}
  else {
    map_df(Years, ~get_acs(year = .x, geography = Geogr, variables = "B01001_001", geometry = TRUE, shift_geo = FALSE) %>% 
             mutate(Year = .x))
  }
}

National <- c("state", "place", "county", "metropolitan statistical area/micropolitan statistical area", "zcta")
By_State <- c("tract", "blockgroup", "block")

ACS_Grab <- function(Vars, Geogr, Years = 2019) {
  if(Geogr %in% National) {
    map_df(Years, function(Yrs) {
      get_acs(year = Yrs, geography = Geogr, variables = Vars, geometry = FALSE) %>% 
        mutate(Year = Yrs,
               High_Error = ((moe/1.645)/estimate)>.2)
    } 
    )}
  else if (Geogr %in% By_State) {
    map_df(Years, function(Yrs) {
      map_df(states, ~get_acs(year = Yrs, geography = Geogr, state = .x, variables = Vars, geometry = FALSE)) %>% 
        mutate(Year = Yrs,
               High_Error = ((moe/1.645)/estimate)>.2)}
    )
  }
}

Vars_0_17 <- c("B01001_003", "B01001_004", "B01001_005", "B01001_006", "B01001_027", "B01001_028", "B01001_029", "B01001_030")
Vars_10_17 <- c("B01001_005", "B01001_006", "B01001_029", "B01001_030")

Population_0_17 <- get_acs(year = 2020, geography = "county", state = "TX", variables = Vars_0_17, geometry = FALSE) %>% 
  group_by(GEOID, NAME) %>% 
  summarize(Pop_0_17 = sum(estimate))

Population_10_17 <- get_acs(year = 2020, geography = "county", state = "TX", variables = Vars_10_17, geometry = FALSE) %>% 
  group_by(GEOID, NAME) %>% 
  summarize(Pop_10_17 = sum(estimate))

County_Youth <- Population_0_17 %>% 
  inner_join(Population_10_17)
