library(TJJD)

Visitor_Tracking <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=IRD035",rows_at_time=1),
                          "SELECT * FROM v_reported")

ID <- ID_Get()

Assignments <- Assignments_Get()

CCS_Contacts<-sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=IRD035",rows_at_time=1),
                      "SELECT * FROM idaddr")

CCSContacts_CurrentYouth_Guardians1<-CCS_Contacts %>%
  mutate(TJJD_Number=TYCNO,
         Source="CCS") %>%
  filter(GUARD1=="Y",
         is.na(PHONE1)==FALSE|(is.na(EMAIL)==FALSE&tolower(EMAIL)!="none")) %>%
  inner_join(Assignments) %>%
  inner_join(select(ID, TJJD_Number, First_Name, Last_Name)) %>%
  select(TJJD_Number,
         First_Name,
         Last_Name,
         Assignment_Location,
         Facility,
         Facility_Type,
         GuardianName=NAME1,
         Relationship=RELATE1,
         PhoneNumber=PHONE1,
         EmailAddress=EMAIL,
         Address = ADDRESS,
         City = CITY,
         Zipcode = ZIP,
         Source
  )

CCSContacts_CurrentYouth_Guardians2<-CCS_Contacts %>%
  mutate(TJJD_Number=TYCNO,
         Source="CCS",
         PHONE2 = as.character(PHONE2)) %>%
  filter(GUARD1=="Y",
         is.na(PHONE2)==FALSE) %>%
  inner_join(Assignments) %>%
  inner_join(select(ID, TJJD_Number, First_Name, Last_Name)) %>%
  select(TJJD_Number,
         First_Name,
         Last_Name,
         Assignment_Location,
         Facility,
         Facility_Type,
         GuardianName=NAME2,
         Relationship=RELATE2,
         PhoneNumber=PHONE2,
         EmailAddress = EMAIL,
         Address = ADDRESS,
         City = CITY,
         Zipcode = ZIP,
         Source
  )

VisitorTracking_CurrentYouth_Guardians<-Visitor_Tracking %>%
  mutate(TJJD_Number = TYCNO,
         GuardianName = str_c(FNAME," ",LNAME),
         Source="Visitor Tracking") %>%
  filter(LEGALGUARD=="Yes",
         (tolower(PHONE)!="none"|is.na(EMAILADD)==FALSE)) %>%
  inner_join(Assignments) %>%
  inner_join(select(ID, TJJD_Number, First_Name, Last_Name)) %>%
  select(TJJD_Number,
         First_Name,
         Last_Name,
         Assignment_Location,
         Facility,
         Facility_Type,
         GuardianName,
         Relationship=RELATIONSHIP,
         PhoneNumber=PHONE,
         EmailAddress=EMAILADD,
         Address = ADDRESS,
         City = CITY,
         State = STATE,
         Zipcode = ZIP,
         Source
  ) %>%
  unique()

AllContacts<-bind_rows(CCSContacts_CurrentYouth_Guardians1,
                       CCSContacts_CurrentYouth_Guardians2,
                       VisitorTracking_CurrentYouth_Guardians %>% 
                         mutate(Zipcode = as.character(Zipcode)))
