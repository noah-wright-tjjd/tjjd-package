library(TJJD)

source("R/DB/Warehouse.R")
source("R/DB/Production.R")

Assignments <- Assignments_Get()
MF <- MF_Get()

Years <- 2020:2024

Unique_by_Type <- map_df(Years, function(x) {
  By_Type <- Assignments |> 
    filter(State_FY(Assignment_Start_Date) <= x,
           State_FY(Assignment_End_Date) >= x) |> 
    mutate(Facility_Type = if_else(str_detect(Facility_Type, "O & A"), "Secure", Facility_Type),
           Year = x) |> 
    group_by(Year, Facility_Type) |> 
    summarize(Unique_Youth = n_distinct(TJJD_Number)) |> 
    ungroup() |> 
    na.omit() |> 
    filter(Facility_Type != "Other") |> 
    pivot_wider(names_from = Facility_Type, values_from = Unique_Youth)
  
  Total <- MF |> 
    filter(State_FY(Admission_Date) <= x,
           State_FY(Commitment_End_Date) >= x) |> 
    mutate(Year = x) |> 
    group_by(Year) |> 
    summarize(Unique_Youth_Total = n_distinct(TJJD_Number)) |> 
    ungroup()
  
  Total_Year <- Total |> 
    full_join(By_Type)
  
  return(Total_Year)
  
}
) 

write_csv(Unique_by_Type, "Unique Youth touching each facility type.csv")
