library(TJJD)

Start_Period <- as.Date("2018-09-01")
End_Period <- today()

SA <- Suicide_Assessments_Get()
Employment_by_Month <- CAPPS_Job_History_Monthly()
Daily <- Daily_Pop_Get()


Pop_by_Type <- Daily %>% 
  mutate(Facility_Type = if_else(Facility_Type == "O & A", "Secure", Facility_Type)) %>% 
  group_by(Date, Facility_Type) %>% 
  summarize(Pop = sum(Total_Population)) %>% 
  ungroup()

Secure_ADP_by_FQ <- Pop_by_Type %>% 
  filter(Facility_Type == "Secure",
         Date >= Start_Period,
         Date <= End_Period) %>% 
  group_by(FY = State_FY(Date), FQ = State_FQ(Date)) %>% 
  summarize(ADP = mean(Pop)) %>% 
  ungroup()

JCO_by_FQ <- Employment_by_Month %>% 
  mutate(Secure = Facility %in% c("Evins", "Gainesville", "Giddings", "Mart", "Ron Jackson")) %>% 
  filter(str_detect(Job_Title, "JCO"),
         Secure) %>% 
  group_by(Month) %>% 
  summarize(Bodies = n_distinct(Empl_ID)) %>% 
  ungroup() %>% 
  group_by(FY = State_FY(Month), FQ = State_FQ(Month)) %>% 
  summarize(Average_Monthly_JCO = mean(Bodies)) %>% 
  ungroup()

SA_by_FQ <- SA %>% 
  filter(!Assessment %in% c("Not placed on SA", "Remove"),
         Assessment_Type == "Initial",
         Assessment_Date >= Start_Period,
         Assessment_Date <= End_Period,
         Facility_Type %in% c("Secure", "O & A")) %>% 
  group_by(FY = State_FY(Assessment_Date), FQ = State_FQ(Assessment_Date)) %>% 
  summarize(SA_Count = n(),
            SA_Youth = n_distinct(TJJD_Number)) %>% 
  ungroup()

Metrics <- Secure_ADP_by_FQ %>% 
  inner_join(JCO_by_FQ) %>% 
  inner_join(SA_by_FQ) %>% 
  mutate(SA_per_100_ADP = SA_Count * 100 / ADP,
         FYFQ = str_c(FY, "-", FQ))

write_csv(Metrics, "Staffing Correlation Metrics.csv")
