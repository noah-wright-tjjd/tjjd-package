library(TJJD)
library(survival)
library(survminer)
library(broom)

#Evins starting being more selective in staffing in August, has that affected new-hire turnover?

Employment_History <- CAPPS_Job_History_Get()
Employment_by_Month <- CAPPS_Job_History_Monthly()
Employment_Spells <- CAPPS_Employment_Spells()
Employees <- Employee_Summary_Get()

Latest_Month <- Employment_by_Month$Month %>% max()

JCO_Monthly_Tenure <- Employment_by_Month %>% 
  filter(str_detect(Job_Title, "JCO"),
         Facility %in% c("Evins", "Gainesville", "Giddings", "Mart", "Ron Jackson")) %>% 
  inner_join(Employment_Spells) %>% 
  mutate(Last_Term_Month_Tenure = if_else(is.na(Last_Term_Month), Latest_Month, Last_Term_Month)) %>% 
  ungroup() %>% 
  filter(Month >= Last_Hire_Month,
         Month <= Last_Term_Month_Tenure,
         Month < Latest_Month) %>% 
  mutate(Tenure = as.numeric((Month + months(1) - 1) - Last_Hire),
         Category = case_when(Tenure <= 365 ~ "0yr_to_1yr",
                              Tenure <= 1095 ~ "1yr_to_3yr",
                              TRUE ~ "3yr+")) %>% 
  count(Facility, Month, Category) %>% 
  group_by(Month, Facility) %>% 
  mutate(Percent_Total = n/sum(n)) %>% 
  ungroup() %>% 
  select(-n) %>% 
  pivot_wider(names_from = Category, values_from = Percent_Total)

JCO_Summary_Data <- Employment_by_Month %>% 
  filter(str_detect(Job_Title, "JCO")) %>% 
  mutate(Secure = Facility %in% c("Evins", "Gainesville", "Giddings", "Mart", "Ron Jackson")) %>% 
  group_by(FY = State_FY(Month), FQ = State_FQ(Month), Secure) %>% 
  summarize(Bodies = n_distinct(Empl_ID),
            Hire = sum(Hire),
            Term = sum(Term)) %>% 
  ungroup()

LBB_Turnover <- Employment_by_Month %>% 
  filter(str_detect(Job_Title, "JCO"),
         Facility %in% c("Evins", "Gainesville", "Giddings", "Mart", "Ron Jackson")) %>% 
  group_by(FY = State_FY(Month), FQ = State_FQ(Month)) %>% 
  summarize(Bodies = n_distinct(Empl_ID),
            Hire = sum(Hire),
            Term = sum(Term)) %>% 
  group_by(FY) %>% 
  summarize(Average_Monthly = mean(Bodies),
            Hires = sum(Hire),
            Terms = sum(Term),
            Net = Hires - Terms,
            LBB_Turnover = Terms/Average_Monthly)

JCO_Survival <- function(Analysis_Start, Analysis_End, Survival_Days) {
  
  JCO_Employment_Spells <- Employment_History %>% 
    filter(str_detect(Job_Title, "JCO")) %>% 
    group_by(Empl_ID, Facility) %>% 
    mutate(UID = row_number(), 
           Spell_Start = (UID == 1) | Hire == 1) %>%
    group_by(Empl_ID, Facility, Spell_Start) %>%
    mutate(Spell_Number = if_else(Spell_Start, row_number(), NA_integer_)) %>% 
    ungroup() %>% 
    fill(Spell_Number) %>% 
    group_by(Empl_ID, Facility, Spell_Number) %>% 
    summarize(Name = last(Name),
              Hire = max(Hire),
              Term = max(Term),
              Start_Date = min(Start_Date),
              End_Date = max(End_Date),
              Job_Title = last(Job_Title),
              Spell_Duration = as.numeric(End_Date - Start_Date)) %>% 
    ungroup()
  
  Analysis_Start <- as.Date(Analysis_Start)
  Analysis_End <- as.Date(Analysis_End)
  
  JCOes_Survival <- JCO_Employment_Spells %>%
    filter(Start_Date >= Analysis_Start) %>% 
    separate(Job_Title, c("Job_Class", "Additional_Title"), sep = "-") %>%
    mutate(Job_Class = str_trim(Job_Class),
           Additional_Title = str_trim(Additional_Title),
           End_Date = if_else(End_Date > Analysis_End, Analysis_End, End_Date),
           Term = if_else(End_Date > Analysis_End, 0, Term),
           Spell_Duration = if_else(Term == 0, as.numeric(Analysis_End - Start_Date), Spell_Duration),
           Start_Year = year(Start_Date),
           Start_Month = floor_date(Start_Date, 'month'),
           Started_First_Week_of_Month = day(Start_Date) <= 7,
           Fiscal_Start_Year = State_FY(Start_Date),
           Fiscal_Start_Quarter = State_FQ(Start_Date),
           Fiscal_Start_Year_Split = if_else(Fiscal_Start_Year == 2022, if_else(Start_Month < "2022-04-01", "2022 before raise", "2022 post raise"),
                                                as.character(Fiscal_Start_Year)),
           Cutoff_Days = if_else(Spell_Duration > Survival_Days, Survival_Days, Spell_Duration),
           Cutoff_Term = if_else(Spell_Duration > Survival_Days, 0, Term),
           Evins_Hire_Changes = Start_Date >= "2022-01-01" & Facility == "Evins",
           TX_Model = Start_Date >= "2019-09-01",
           Covid = Start_Date >= "2020-04-01",
           Great_Res = Start_Date >= "2021-04-01",
           Bonus_15_Temporary = Start_Date >= "2022-03-01" & Start_Date < "2022-07-01",
           Bonus_15_Permanent = Start_Date >= "2022-07-01",
           Bonus_10_RJ = Start_Date >= "2022-07-01" & Start_Date <= "2022-10-01" & Facility == "Ron Jackson",
           Buddies = case_when(Facility == "Evins" & Start_Date >= "2022-05-01" ~ 1,
                               Facility == "Mart" & Start_Date >= "2022-06-01" ~ 1,
                               Facility == "Giddings" & Start_Date >= "2022-06-01" & Start_Date <= "2023-01-31" ~ 1,
                               Start_Date >= "2022-07-01" ~ 1,
                               TRUE ~ 0),
           Revised_Buddies = if_else(Facility == "Giddings" & Start_Date >= "2023-02-01", 1, 0), 
           Period = case_when(Start_Date >= "2022-07-01" ~ "4. Buddy_Raises",
                              Start_Date >= "2022-04-01" ~ "3. Transitional",
                              Start_Date >= "2021-03-01" ~ "2. Great_Resignation",
                              Start_Date >= "2020-03-01" ~ "1. COVID_Year1",
                              TRUE ~ "0. Pre_Covid"),
           Survival_Days = Survival_Days) %>% 
    group_by(Facility, Start_Date) %>% 
    mutate(Training_Cohort = n()) %>% 
    ungroup()
}

JCO_Data <- map_df(c(7, 30, 90, 180, 365), ~JCO_Survival("2018-09-01", today(), .x)) %>% 
  filter(!is.na(End_Date))

Timeframe_Turnover_by_Month <- JCO_Data %>% 
  filter(Facility %in% c("Evins", "Gainesville", "Giddings", "Mart", "Ron Jackson"),
         Start_Date <= floor_date(today(), "month") - 1 - Survival_Days) %>% 
  group_by(Fiscal_Start_Year, Fiscal_Start_Quarter, Start_Month, Survival_Days) %>% 
  summarize(Hires = sum(Hire),
            Turnover = sum(Cutoff_Term)/Hires) 
 #%>% 
#  select(-Hires) %>% 
 # pivot_wider(names_from = Survival_Days, values_from = Turnover)

Timeframe_Turnover_by_FQ <- JCO_Data %>% 
  group_by(Fiscal_Start_Year, Fiscal_Start_Quarter, Survival_Days) %>% 
  filter(Facility %in% c("Evins", "Gainesville", "Giddings", "Mart", "Ron Jackson"),
         max(Start_Date) <= floor_date(today(), "month") - 1 - Survival_Days) %>% 
  summarize(Hires = sum(Hire),
            Turnover = sum(Cutoff_Term)/Hires) %>% 
  select(-Hires) %>% 
#  pivot_wider(names_from = Survival_Days, values_from = Turnover) %>% 
  mutate(Timeframe = str_c("FY", Fiscal_Start_Year, " - FQ", Fiscal_Start_Quarter))

write_csv(Timeframe_Turnover_by_FQ %>% 
            mutate(Survival_Days = str_c("Days_", Survival_Days)) %>% 
            pivot_wider(names_from = Survival_Days, values_from = Turnover), "FQ Turnover.csv")

Timeframe_Turnover_by_CQ <- JCO_Data %>% 
  group_by(CY = year(Start_Month), CQ = quarter(Start_Month), Survival_Days) %>% 
  filter(Facility %in% c("Evins", "Gainesville", "Giddings", "Mart", "Ron Jackson"),
         max(Start_Date) <= today() - Survival_Days) %>% 
  summarize(Hires = sum(Hire),
            Turnover = sum(Cutoff_Term)/Hires) %>% 
#  select(-Hires) %>%
#  pivot_wider(names_from = Survival_Days, values_from = Turnover) %>% 
  mutate(Timeframe = str_c(CY, " - Q", CQ))

Timeframe_Turnover_by_Period <- JCO_Data %>% 
  filter(Facility %in% c("Evins", "Gainesville", "Giddings", "Mart", "Ron Jackson"),
         Start_Month <= floor_date(today(), "month") -1 - Survival_Days) %>% 
  group_by(Period, Survival_Days) %>% 
  summarize(Hires = sum(Hire),
            Turnover = sum(Cutoff_Term)/Hires) %>% 
  #  select(-Hires) %>% 
    pivot_wider(names_from = Survival_Days, values_from = Turnover)

Timeframe_Turnover_by_Facility <- JCO_Data %>% 
  filter(Facility %in% c("Evins", "Gainesville", "Giddings", "Mart", "Ron Jackson"),
         Start_Month <= floor_date(today(), "month") -1 - Survival_Days,
         Start_Month >= "2024-08-01") %>% 
  group_by(Facility, Survival_Days) %>% 
  summarize(Hires = sum(Hire),
            Turnover = sum(Cutoff_Term)/Hires) %>% 
    select(-Hires) %>% 
  pivot_wider(names_from = Survival_Days, values_from = Turnover)

Timeframe_Turnover_by_Facility %>% write_csv("Turnover at Points.csv")

Timeframe_Turnover_by_Month %>% 
  filter(Start_Month >= "2022-07-01",
         Survival_Days %in% c(7, 30, 90)) %>% 
  ggplot(aes(x = Start_Month, y = Turnover, group = as.character(Survival_Days), color = as.character(Survival_Days))) +
  geom_line()

Timeframe_Turnover_by_CQ %>% 
  ggplot(aes(x = Timeframe, y = Turnover, group = as.character(Survival_Days), color = as.character(Survival_Days))) +
  geom_line()

#Kaplan-Meier Curve

Cutoff <- 180

Analysis_Data <- JCO_Data %>%
  filter(Facility %in% Facilities,
         Survival_Days == Cutoff,
         Start_Date >= "2023-04-01",
         Start_Date <= "2025-03-31") %>% 
  mutate(April = if_else(Start_Date >= "2024-04-01", "24-25", "23-24"))

SurvDataFit <- survfit(Surv(Cutoff_Days, Cutoff_Term) ~ April, data = Analysis_Data |> filter(Facility == "Ron Jackson"))

ggsurvplot(
  fit = SurvDataFit,
  xlab = "Days After Hire",
  ylab = "Retention Probability",
  xlim = c(0, Cutoff),
  ylim = c(.2, 1),
  conf.int = FALSE
  ) +
  labs(title = "JCO Retention April - March, Ron Jackson")

