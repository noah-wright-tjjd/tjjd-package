library(TJJD)

ID <- ID_Get()

MF <- MF_Get()

MF %>% 
  filter(Discharge_Reason_Code == "SCOP") %>% 
  select(TJJD_Number) %>% 
  unique() %>% 
  anti_join(MF %>% 
              filter(Commitment_Type == "RCMT")) %>% 
  inner_join(MF) %>% 
  group_by(TJJD_Number) %>% 
  filter(n() > 1) %>% 
  view()

MF <- MF %>% 
  filter(Commitment_Type == "CMNT") %>% 
  mutate(Age_at_Commitment = Commitment_Date )


Start_Period <- as.Date("2019-09-01")
End_Period <- as.Date("2024-8-31")

Line_Smoothed <- function(DF, XCol, YCol, Title, Smoothed = TRUE, Split = TRUE) {
  
  if (Smoothed == TRUE & Split == TRUE) {
    
    DF %>% 
      ggplot(aes(x = {{XCol}}, y = {{YCol}})) +
      geom_line(aes(y = {{YCol}}), size = .5, alpha = .35) +
      geom_smooth(data = DF, aes(y = {{YCol}}), size = 1) +
      ylim(0, NA) +
      TJJD_Style() +
      labs(title = Title)
  } 
  else if (Smoothed == TRUE & Split == FALSE) 
  {
    DF %>% 
      ggplot(aes(x = {{XCol}}, y = {{YCol}})) +
      geom_line(aes(y = {{YCol}}), size = .5, alpha = .35) +
      geom_smooth(data = DF, aes(y = {{YCol}}), size = 1) +
      ylim(0, NA) +
      TJJD_Style() +
      labs(title = Title)
  } 
  else if (Smoothed == FALSE) 
  {
    DF %>% 
      ggplot(aes(x = {{XCol}}, y = {{YCol}})) +
      geom_line(aes(y = {{YCol}})) +
      ylim(0, NA) +
      TJJD_Style() +
      labs(title = Title)
  }
}

Waitlist_Youth <- read_excel("Data Sources/Waitlist Reporting.xlsx") %>% 
  mutate(Intake_Date = as.Date(replace_na(`Intake Date`, today())),
         Disposition_Date = as.Date(`Disposition Date`),
         Total_Time_on_Waitlist = as.numeric(Intake_Date - Disposition_Date),
         DoNotCount = replace_na(`Do Not Count`, "No")) %>% 
  filter(!is.na(`Disposition Date`),
         `Disposition Date` <= Intake_Date,
         DoNotCount == "No")

Waitlist_Calc <- Interval_Convert.Date(Waitlist_Youth,
                                       Disposition_Date,
                                       Intake_Date,
                                       "day") %>% 
  mutate(Daily_Time_on_Waitlist = as.numeric(Interval_Start - Disposition_Date))

Average_Time_on_Waitlist_at_Release <- Waitlist_Youth %>% 
  group_by(Month = floor_date(Intake_Date, "month")) %>% 
  summarize(Average_Waitlist_Time = mean(Total_Time_on_Waitlist)) %>% 
  ungroup()

write_csv(Average_Time_on_Waitlist_at_Release, "Average Time on Waitlist at Release.csv")

Waitlist_by_Day <- Waitlist_Calc %>% 
  filter(DoNotCount == "No" | is.na(DoNotCount),
         Interval_Start >= Start_Period,
         Interval_Start <= End_Period) %>% 
  count(Day = Interval_Start)

Waitlist_by_FQ <- Waitlist_by_Day %>% 
  mutate(FY = State_FY(Day),
         FQ = State_FQ(Day)) %>% 
  group_by(FY, FQ) %>% 
  summarize(Waitlist_ADP = mean(n))

write_csv(Waitlist_by_FQ, "Waitlist by FQ.csv")

Waitlist_by_Day_Line <- Waitlist_by_Day %>% 
  Line_Smoothed(Day, n, "TJJD Waitlist Count", Smoothed = FALSE) +
  xlim(Start_Period, End_Period + 30)

ggsave("Waitlist by day.png", Waitlist_by_Day_Line,
       width = 8.4,
       height = 5.4,
       units = "in")

Time_on_Waitlist_by_Day <- Waitlist_Calc %>% 
  filter(DoNotCount == "No") %>% 
  group_by(Day = Interval_Start) %>% 
  summarize(Count = n(),
            Average_Waitlist = mean(Daily_Time_on_Waitlist)) %>% 
  Line_Smoothed(Day, Average_Waitlist, "Average Time on Waitlist by Day", Smoothed = FALSE) +
  xlim(Start_Period, End_Period + 30)

ggsave("Average Time on waitlist by day.png", Time_on_Waitlist_by_Day,
       width = 8.4,
       height = 5.4,
       units = "in")

Total_Time_on_Waitlist_by_Admission_Month <- Waitlist_Youth %>% 
  filter(DoNotCount == "No",
         !is.na(Total_Time_on_Waitlist)) %>% 
  group_by(Month = floor_date(Intake_Date, "month")) %>% 
  summarize(Count = n(),
            Average_Total_Waitlist = mean(Total_Time_on_Waitlist)) %>% 
  Line_Smoothed(Month, Average_Total_Waitlist, "Average Days on Waitlist at Admission", Smoothed = FALSE) +
  xlim(Start_Period, End_Period + 30)

ggsave("Average Time on Waitlist at Admission.png", Total_Time_on_Waitlist_by_Admission_Month,
       width = 8.4,
       height = 5.4,
       units = "in")

Waitlist_Snapshots <- Waitlist_Calc %>% 
  filter(day(Interval_Start) == 1) %>% 
  group_by(Interval_Start) %>% 
  summarize(Youth = n_distinct(PID))

write_csv(Waitlist_Snapshots, "Waitlist by First of Month.csv")
