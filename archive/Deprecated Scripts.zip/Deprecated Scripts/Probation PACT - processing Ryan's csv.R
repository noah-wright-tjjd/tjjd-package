library(TJJD)

Probation_PACT <- read_csv("Data Sources\\Probation Pact.csv")
PACT_and_RPACT_With_Factors <- read_csv("PACT and PRACT Forms and Scores with Factors.csv")

Probation_PACT_Long_Results <- read_csv("Probation_PACT_Long_Results_Only 1.csv") %>% 
  bind_rows(read_csv("Probation_PACT_Long_Results_Only 2.csv")) %>% 
  bind_rows(read_csv("Probation_PACT_Long_Results_Only 3.csv"))

Not_Results <- Probation_PACT %>% 
  select(-c(FORM_INSTANCE_UID, DEPLOYMENT_UID, FORM_ID, STATUS, COMPLETED_BY_USER, COMPLETED_BY_USER_UID, PACT_PRE_COMMENTS__PACT_PRE_COMMENTS, STATUS_DESCRIPTION, DOMAIN_1__RECORD_OF_REFERRALS__1_AGE_AT_FIRST_OFFENSE:DOMAIN_12__SKILLS__DOMAIN_12_COMMENTS, CSEIT_EXTRACT_ROW_ID:WHY_IFNO))

rm(Probation_PACT)

PACT_Lookup <- PACT_and_RPACT_With_Factors %>% 
  select(Probation_PACT_Question_Format,
         Question_ID, 
         Answer_ID, 
         contains("Big8Risk"))ext_Results <- Probation_PACT %>% 
  select(TJJD_NUMBER, FORM_INSTANCE_ID, DOMAIN_1__RECORD_OF_REFERRALS__1_AGE_AT_FIRST_OFFENSE:DOMAIN_12__SKILLS__DOMAIN_12_COMMENTS) %>% 
  pivot_longer(DOMAIN_1__RECORD_OF_REFERRALS__1_AGE_AT_FIRST_OFFENSE:DOMAIN_12__SKILLS__DOMAIN_12_COMMENTS,
               names_to = "Probation_PACT_Question_Format",
               values_to = "Answer_Text") %>% 
  filter(!str_detect(Probation_PACT_Question_Format, "COMMENTS"))
library(TJJD)

Probation_PACT <- read_csv("Data Sources\\Probation Pact.csv")
PACT_and_RPACT_With_Factors <- read_csv("PACT and PRACT Forms and Scores with Factors.csv")

Probation_PACT_Long_Results <- read_csv("Probation_PACT_Long_Results_Only 1.csv") %>% 
  bind_rows(read_csv("Probation_PACT_Long_Results_Only 2.csv")) %>% 
  bind_rows(read_csv("Probation_PACT_Long_Results_Only 3.csv"))

Not_Results <- Probation_PACT %>% 
  select(-c(FORM_INSTANCE_UID, DEPLOYMENT_UID, FORM_ID, STATUS, COMPLETED_BY_USER, COMPLETED_BY_USER_UID, PACT_PRE_COMMENTS__PACT_PRE_COMMENTS, STATUS_DESCRIPTION, DOMAIN_1__RECORD_OF_REFERRALS__1_AGE_AT_FIRST_OFFENSE:DOMAIN_12__SKILLS__DOMAIN_12_COMMENTS, CSEIT_EXTRACT_ROW_ID:WHY_IFNO))

PACT_Lookup <- PACT_and_RPACT_With_Factors %>% 
  select(Probation_PACT_Question_Format,
         Section_ID,
         Section,
         Question_ID, 
         Question_Text, 
         Answer_ID, 
         Answer_Text, 
         Checklist, 
         contains("Big8Risk"))

Text_Results <- Probation_PACT %>% 
  select(TJJD_NUMBER, FORM_INSTANCE_ID, DOMAIN_1__RECORD_OF_REFERRALS__1_AGE_AT_FIRST_OFFENSE:DOMAIN_12__SKILLS__DOMAIN_12_COMMENTS) %>% 
  pivot_longer(DOMAIN_1__RECORD_OF_REFERRALS__1_AGE_AT_FIRST_OFFENSE:DOMAIN_12__SKILLS__DOMAIN_12_COMMENTS,
               names_to = "Probation_PACT_Question_Format",
               values_to = "Answer_Text") %>% 
  filter(!str_detect(Probation_PACT_Question_Format, "COMMENTS"))

Result_Sample_Non_Checklist <- Text_Results %>% 
  slice(24000001:36584576) %>% 
  inner_join(PACT_Lookup %>% 
               filter(Checklist == FALSE)) %>% 
  select(TJJD_NUMBER, FORM_INSTANCE_ID, Answer_ID)

Result_Sample_Checklist <- Text_Results %>% 
  slice(24000001:36584576) %>% 
  inner_join(PACT_Lookup %>% 
               filter(Checklist) %>% 
               select(Probation_PACT_Question_Format) %>% 
               unique()) %>% 
  separate(Answer_Text, as.character(c(1:11)), sep = ", ", fill = "right") %>% 
  mutate(`1` = if_else(str_detect(`1`, "Violent outbursts"), str_c(`1`, `2`, `3`, sep = ", "), `1`)) %>% 
  pivot_longer(c(`1`:`11`), names_to = "Response_Number", values_to = "Answer_Text") %>% 
  filter(!is.na(Answer_Text),
         Answer_Text != "NULL") %>% 
  select(-Response_Number) %>% 
  inner_join(PACT_Lookup) %>% 
  select(TJJD_NUMBER, FORM_INSTANCE_ID, Answer_ID)

Combine <-  Result_Sample_Checklist %>% 
  bind_rows(Result_Sample_Non_Checklist)


write_csv(Combine, "Probation_PACT_Long_Results_Only 3.csv")



Combine_Big8 <- Combine %>% 
  group_by(TJJD_NUMBER, FORM_INSTANCE_ID) %>% 
  summarize(across(contains("Risk"), sum))

Big8_Probation <- Not_Results %>% 
  inner_join(Combine_Big8)

#Block caps
#replace all space with "_"
#remove "-" and "."
#Add __ between records


Big8Risk <- PACT_and_RPACT_With_Factors %>% 
  select(Answer_ID, Answer_Text)


Results <- Probation_PACT_Long_Results %>% 
  inner_join(PACT_Lookup) %>% 
  group_by(TJJD_NUMBER, FORM_INSTANCE_ID) %>% 
  summarize(across(contains("Risk"), sum)) %>% 
  ungroup()

Max_Scores <- Results %>% 
  summarize(across(contains("Risk"), max))

Totals <- Not_Results %>% 
  inner_join(Results)

write_csv(Totals, "Probation PACT Big 8 Scoring.csv")


#Verification-----------------------------

Big_8 <- read_csv("Probation PACT Big 8 Scoring.csv")

Big_8_Assessments <- Big_8 %>% 
  count(TJJD_NUMBER, FORM_LABEL) %>% 
  pivot_wider(names_from = FORM_LABEL, values_from = n, values_fill = 0)

Means <- Big_8 %>% 
  group_by(FORM_LABEL) %>% 
  summarize(across(contains("Big8Risk"), mean))
