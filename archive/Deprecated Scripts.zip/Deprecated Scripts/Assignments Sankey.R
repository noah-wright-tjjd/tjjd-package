library(ggsankey)

Assignments <- Assignments_Get("Historical")

Complete_Records <- Assignments %>% 
  group_by(TJJD_Number) %>% 
  filter(min(Assignment_Start_Date) >= "2020-01-01",
         Movement_Type != "TA") %>% 
  mutate(Assignment_End_Date = if_else(Assignment_End_Date == "2099-12-31", today(), Assignment_End_Date)) %>% 
  filter(min(Assignment_Pointer_Number) == 1) %>% 
  ungroup()
  

Assignments_by_Day <- Complete_Records %>% 
  Interval_Convert.Date(Assignment_Start_Date, Assignment_End_Date, "day")

Sankey_Format <- Assignments_by_Day %>% 
  group_by(TJJD_Number, Date = Interval_Start) %>% 
  summarize(node = last(Facility_Type)) %>% 
  group_by(TJJD_Number) %>% 
  mutate(x = row_number()) %>% 
  filter(x %in% c(1, 91, 181)) %>% 
  select(-Date) %>% 
  ungroup() %>% 
  complete(TJJD_Number, x, fill = list(node = "Discharged")) %>% 
  group_by(TJJD_Number) %>% 
  mutate(next_x = lead(x),
         next_node = lead(node)) %>% 
  ungroup()

ggplot(Sankey_Format, aes(x = x, 
                          next_x = next_x, 
                          node = node, 
                          next_node = next_node,
                          fill = factor(node))) +
  geom_sankey()

Assignments_by_Month <- Assignments_by_Day %>% 
  filter(day(Interval_Start) == 1,
         year(Interval_Start) == 2022)

Sankey_Format2 <- Assignments_by_Month %>% 
  group_by(TJJD_Number, Interval_Start) %>% 
  summarize(Facility_Type = last(Facility_Type)) %>%
  group_by(TJJD_Number) %>% 
  mutate(First_Interval = min(Interval_Start),
         Last_Interval = max(Interval_Start)) %>% 
  ungroup() %>% 
  complete(nesting(TJJD_Number, First_Interval, Last_Interval), Interval_Start, fill = list(Facility_Type = "NA")) %>% 
  mutate(Facility_Type = if_else(Interval_Start > Last_Interval, "Youth Discharged",
                                 if_else(Interval_Start < First_Interval, "Not Admitted",
                                 Facility_Type))) %>% 
  pivot_wider(names_from = Interval_Start, values_from = Facility_Type) %>% 
  make_long(`2022-01-01`:`2022-12-01`)

