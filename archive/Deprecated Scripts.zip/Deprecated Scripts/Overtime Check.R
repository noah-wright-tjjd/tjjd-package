library(TJJD)

Request_Name <- "Overtime Analysis"

Request_Directory <- str_c("Produced Datasets/Requests/", Request_Name)

dir.create(Request_Directory)

Overtime_12months %>% 
  filter(str_detect(`Empl Name`,"Johnson,Jeffrey")) %>% 
  summarize(sum(`Oth Hrs`))

# Queries -----------------------------------------------------------------

Overtime_12months <- read_excel(str_c(Request_Directory,"/Overtime Feb20 - Jan21.xlsx"))

Employee_Summary <- Employee_Summary_Get()

Date_Table <- data.frame(Month = seq.Date(as.Date("2020-02-01"), as.Date("2021-01-01"), "month"))

Employee_Join <- Employee_Summary %>% 
  mutate(Start_Date = if_else(is.na(Rehire_Date), Initial_Hire_Date, Rehire_Date),
         End_Date = replace_na(Termination_Date, today()))

Employee_Summary_History<-sqldf("SELECT Month, Employee_ID, Name, Job_Code_Description, Facility, Start_Date, End_Date, Supervisor
from Date_Table
left join Employee_Join
on Employee_Join.Start_Date<=Date_Table.Month and Employee_Join.End_Date>=Date_Table.Month")

Overtime_History <- Employee_Summary_History %>% 
  left_join(Overtime_12months %>% 
              mutate(Employee_ID = as.numeric(`Empl ID`),
                     Month = floor_date(`Earns Begin`, "month")) %>% 
              group_by(Employee_ID, Month) %>% 
              summarize(Hours = sum(`Oth Hrs`),
                        Earnings = sum(`Oth Earns`))) %>% 
  mutate(OT_Hours = replace_na(Hours, 0),
         OT_Earnings = replace_na(Earnings, 0)) %>% 
  select(Month,
         Employee_ID,
         Name,
         Facility,
         Supervisor,
         Start_Date,
         End_Date,
         OT_Hours,
         OT_Earnings)

# Analysis ----------------------------------------------------------------

#Aggregation level: individual, supervisor, facility
#Timeframe: Annual, past 3 calendar months


Employees_Average <- Overtime_History %>% 
  group_by(Employee_ID, Name, Facility, Supervisor, Start_Date, End_Date) %>% 
  summarize(OT_Hours = mean(OT_Hours),
            OT_Earnings = mean(OT_Earnings))

Employees_Average_OT_Only <- Overtime_History %>% 
  filter(OT_Hours > 0) %>% 
  group_by(Employee_ID, Name, Facility, Supervisor, Start_Date, End_Date) %>% 
  summarize(OT_Hours = mean(OT_Hours),
            OT_Earnings = mean(OT_Earnings))

Supervisors_Monthly_Average <- Overtime_History %>% 
  group_by(Facility, Supervisor, Month) %>% 
  summarize(Employees = n_distinct(Employee_ID),
            Total_OT_Earnings = sum(OT_Earnings),
            Total_OT_Hours = sum(OT_Hours),
            Hours_Per_Employee_Mean = mean(OT_Hours),
            Hours_Per_Employee_SD = sd(OT_Hours))

Supervisors_Monthly_Average_OT_Only <- Overtime_History %>% 
  filter(OT_Hours>0) %>% 
  group_by(Facility, Supervisor, Month) %>% 
  summarize(Employees = n_distinct(Employee_ID),
            Total_OT_Earnings = sum(OT_Earnings),
            Total_OT_Hours = sum(OT_Hours),
            Hours_Per_Employee_Mean = mean(OT_Hours),
            Hours_Per_Employee_SD = sd(OT_Hours))

Facilities_Monthly_Average <- Overtime_History %>% 
  group_by(Facility, Month) %>% 
  summarize(Employees = n_distinct(Employee_ID),
            Total_OT_Earnings = sum(OT_Earnings),
            Total_OT_Hours = sum(OT_Hours),
            Hours_per_Employee = Total_OT_Hours / Employees)

Facilities_Monthly_Average_OT_Only <- Overtime_History %>% 
  filter(OT_Hours>0) %>% 
  group_by(Facility, Month) %>% 
  summarize(Employees = n_distinct(Employee_ID),
            Total_OT_Earnings = sum(OT_Earnings),
            Total_OT_Hours = sum(OT_Hours),
            Hours_per_Employee = Total_OT_Hours / Employees)

Total_Monthly_Average <- Overtime_History %>% 
  group_by(Month) %>% 
  summarize(Employees = n_distinct(Employee_ID),
            Total_OT_Earnings = sum(OT_Earnings),
            Total_OT_Hours = sum(OT_Hours),
            Hours_Per_Employee_Mean = mean(OT_Hours),
            Hours_Per_Employee_SD = sd(OT_Hours))

Total_Monthly_Average_OT_Only <- Overtime_History %>% 
  filter(OT_Hours>0) %>% 
  group_by(Month) %>% 
  summarize(Employees = n_distinct(Employee_ID),
            Total_OT_Earnings = sum(OT_Earnings),
            Total_OT_Hours = sum(OT_Hours),
            Hours_Per_Employee_Mean = mean(OT_Hours),
            Hours_Per_Employee_SD = sd(OT_Hours))

Simple_Savings_Calc <- Overtime_History %>% 
  filter(OT_Hours>0) %>% 
  mutate(OT_Rate = OT_Earnings/OT_Hours,
         Difference = OT_Hours-80,
         Savings = OT_Rate*Difference) %>% 
  summarize(sum(Savings))


# Visualization -----------------------------------------------------------

Employees_Average %>% 
  ggplot(aes(x = OT_Hours)) +
  geom_histogram()

Employees_Average_OT_Only %>% 
  ggplot(aes(x = OT_Hours)) +
  geom_histogram()

Supervisors_Monthly_Average %>% 
  ggplot(aes(x = Total_OT_Hours)) +
  geom_histogram()

Supervisors_Monthly_Average_OT_Only %>% 
  ggplot(aes(x = Total_OT_Hours)) +
  geom_histogram()

Facilities_Monthly_Average %>% 
  filter(is.na(Facility) == FALSE) %>% 
  ggplot(aes(x = Total_OT_Hours, y = reorder(Facility, Total_OT_Hours))) +
  geom_col()

Facilities_Monthly_Average %>% 
  filter(is.na(Facility) == FALSE) %>% 
  ggplot(aes(x = Hours_per_Employee, y = reorder(Facility, Total_OT_Hours))) +
  geom_col()

# Output ------------------------------------------------------------------

write_csv(Output, str_c(Request_Directory, Request_Name, ".csv"))