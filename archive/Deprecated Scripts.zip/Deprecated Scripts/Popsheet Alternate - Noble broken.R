library(TJJD)

Assignments <- Assignments_Get() %>%
  filter(Assignment_End_Date == "2099-12-31")

Dorm_Assignments<-Dorm_Assignments_Get() %>%
  filter(Dorm_Assignment_End_Date == "2099-12-31")

Stages<-Stages_Get()

Stages_Most_Recent_Regular<-Stages %>%
  filter(str_detect(Stage, "S") == TRUE) %>%
  group_by(TJJD_Number) %>%
  summarize_all(last) %>%
  select(TJJD_Number, Stage, Stage_Decision_Date)

ID<-ID_Get()

Incidents<-Incidents_Get()

Masterfiles<-Masterfiles_Get(Timeframe = 'historical')

Determinate_Status<-Masterfiles %>%
  filter(Commitment_Type != "RVKD") %>%
  group_by(TJJD_Number) %>%
  summarize_all(last)

Incidents_Assaultive<-Incidents %>%
  filter(Assault_On_Staff == 1|Assault_On_Youth == 1) %>%
  group_by(TJJD_Number) %>%
  summarize(Staff_Assaults_Past30Days = sum((Incident_Date >= today() - 30) & Assault_On_Staff == 1),
            Staff_Assaults_Past90Days = sum((Incident_Date >= today() - 90) & Assault_On_Staff == 1),
            All_Staff_Assaults = sum(Assault_On_Staff == 1),
            Youth_Assaults_Past30Days = sum((Incident_Date >= today() - 30) & Assault_On_Youth == 1),
            Youth_Assaults_Past90Days = sum((Incident_Date >= today()-90) & Assault_On_Youth == 1),
            All_Youth_Assaults = sum(Assault_On_Youth == 1))

Incidents_Major<-Incidents %>%
  filter(Priority_Rule_Violation_Category == 1) %>%
  group_by(TJJD_Number) %>%
  summarize(Major_RVPast30Days = sum(Incident_Date >= today() - 30),
            Major_RVPast90Days = sum(Incident_Date >= today() - 90),
            All_Major_RVIncidents = n())

L2_Hearings_Most_Recent <- L2_Hearings_Get('last')

# #PACT_Risk <- PACT_Risk_Get()
# 
# # PACT_Risk_Most_Recent <- PACT_Risk %>%
# #   group_by(TJJD_Number, Form) %>%
# #   summarize_all(last) %>%
# #   select(-Form_Instance_ID, -Form_Admin_Type) %>%
# #   mutate(Form = str_replace(Form, "Residential ", "R")) %>%
# #   pivot_wider(names_from = Form, values_from = c(Date_Completed, Score))
# 
# CSEIT <- CSEIT_Get()
# 
# ACE <- ACE_Score_Get()
# 
# ACE_Pact <- ACE_Score_From_PACT_Get()
# 
# All_ACE <- ACE %>%
#   full_join(ACE_Pact,by = "TJJD_Number") %>%
#   rename_at(vars(ends_with(".x")),
#             ~str_replace(., "\\.x", "- ACE Questions")) %>%
#   rename_at(vars(ends_with(".y")),
#             ~str_replace(., "\\.y", "- Derived from Pact"))

Statuses <- Statuses_Get()

Statuses_Current_No_RSU <- Statuses %>%
  filter(Status_End_Date == as.Date("2099-12-31")) %>%
  full_join(select(ID, TJJD_Number, ICE) %>%
              filter(ICE == "Y",
                     TJJD_Number %in% Current_Youth)) %>%
  mutate(ICE = if_else(is.na(ICE) == TRUE, "N", ICE),
         Status_Type = if_else(ICE == "Y", "ICE", Status_Type)) %>%
  filter(Status_Type != "SEC") %>%
  select(TJJD_Number, Status_Type)

Treatment_Needs <- Treatment_Needs_Get()

Treatment_Needs_Most_Recent <- Treatment_Needs %>%
  group_by(TJJD_Number) %>%
  summarize(Form060_UID = max(Form060_UID)) %>%
  inner_join(Treatment_Needs) %>%
  select(TJJD_Number,
         Date_of_060 = Review_Date,
         Medical_Priority:Capital_and_Serious_Violent_Priority)

All_Pop_Sheet_Variables<-Assignments %>%
  left_join(Statuses_Current_No_RSU) %>%
#  left_join(All_ACE) %>%
#  left_join(CSEIT) %>%
#  left_join(PACT_Risk_Most_Recent) %>%
  left_join(ID) %>%
  left_join(Incidents_Major) %>%
  left_join(Incidents_Assaultive) %>%
  left_join(Treatment_Needs_Most_Recent) %>%
  left_join(Determinate_Status) %>%
  left_join(L2_Hearings_Most_Recent) %>%
  left_join(Stages_Most_Recent_Regular) %>%
  left_join(Dorm_Assignments)

Pop_Sheet <- All_Pop_Sheet_Variables %>%
  select(TJJD_Number,
         First_Name,
         Last_Name,
         Sex,
         Age,
         DOB,
         IQ,
         Determinate_Sentence,
         Assignment_Start_Date,
         Parole_Status,
         Location_Type = Facility_Type,
         Facility,
         Location = Assignment_Location,
         Dorm,
         Status_Type,
         Most_Recent_Stage = Stage,
         Most_Recent_Stage_Decision_Date = Stage_Decision_Date,
#         Score_PACT,
#         Score_RPACT,
#         Continuum_Concern,
#         `Emotional_Abuse- ACE Questions`:`ACE_Score- Derived from Pact`,
         Major_RVPast30Days:Capital_and_Serious_Violent_Priority) %>%
  arrange(desc(Age)) %>%
  mutate(across(contains("Assaults")|contains("Major_RV"), ~replace(.x, is.na(.x), 0)))

write_csv(Pop_Sheet,str_c("Produced Datasets\\Population Snapshots\\Weekly Population - ",today(),".csv"))