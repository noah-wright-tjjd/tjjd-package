library(TJJD)
library(compareDF)

Connection_String <- "Driver=SQL Server;server=tjjd4avsql;database=IRD035"

POPAS <- sqlQuery(odbcDriverConnect(connection = Connection_String, rows_at_time=1),
                       "select * from POPAS")

POPASFixed <- sqlQuery(odbcDriverConnect(connection = Connection_String, rows_at_time=1),
                        "select * from POPASFixed")

POPASFX <- sqlQuery(odbcDriverConnect(connection = Connection_String, rows_at_time=1),
                      "select * from POPASFX")

Shared <- POPAS %>% 
  select(TYCNO, ASPTR) %>% 
  mutate(AS = 1) %>% 
  full_join(POPASFixed %>% 
              select(TYCNO, ASPTR) %>% 
              mutate(Fix = 1)) %>% 
  full_join(POPASFX %>% 
              select(TYCNO, ASPTR) %>% 
              mutate(FX = 1)) %>% 
  mutate(across(c(AS:FX), ~if_else(is.na(.x), 0, 1)),
         Distinct = (AS + FX + Fix) < 3) %>% 
  filter(!(TYCNO == 1229357 & ASPTR == 5))

AS_Shared <- POPAS %>% 
  semi_join(Shared %>% 
              filter(!Distinct)) %>% 
  arrange(TYCNO, ASPTR)

Fix_Shared <- POPASFixed %>% 
  semi_join(Shared %>% 
              filter(!Distinct)) %>% 
  arrange(TYCNO, ASPTR) %>% 
  select(-DSCFY)

FX_Shared <- POPASFX %>% 
  semi_join(Shared %>% 
              filter(!Distinct)) %>% 
  arrange(TYCNO, ASPTR)

Comparison_Results <- compare_df(AS_Shared, Fix_Shared)

Comparison_Results <- compare_df(Fix_Shared, FX_Shared, keep_unchanged_cols = FALSE)

Wide <- create_wide_output(Comparison_Results)


