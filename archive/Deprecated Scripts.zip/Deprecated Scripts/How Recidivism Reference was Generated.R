library(TJJD)

#Generate Youth Arrests Formatted-----------------------------------

Youth_Arrests_Raw <- read_sas("\\\\tjjd4avsascen\\apps\\Performance Measures\\FY 2023\\DPS\\Data\\Q4\\August Request\\arrest_maint_match.sas7bdat")

Youth_Arrests_Formatted <- Youth_Arrests_Raw %>%
    mutate(Arrest_Date = as.Date(DOA3, "%Y%m%d"),
           Arrest_Offense_Date = as.Date(DOO3, "%Y%m%d"),
           Arrest_Disposition_Date = as.Date(ADA3, "%Y%m%d"),
           TJJD_Number = as.integer(TYCNO),
           NCIC = as.numeric(AON3)) %>%
    left_join(DPS_Offense_Code_Lookup) %>%
    left_join(DPS_Arrest_Disposition_Code_Lookup, by = c("ADN3" = "Disposition_Code")) %>%
    select(TJJD_Number,
           DPS_Number = DPSNBR,
           Name = NAME,
           Arrest_Date,
           Sequence = SEQ3,
           Tracking_Incident_Number = TRS3,
           Arrest_Offense_Date,
           Arrest_Offense_Numeric = AON3,
           Arrest_Offense = OffDesc,
           Arrest_Offense_Notes = AOL3,
           Citation = CIT3,
           Level_and_Degree = LDA3,
           TJPCCategory:Violent,
           General_Offense_Character = GOC3,
           Arrest_Disposition_Numeric = ADN3,
           Arrest_Disposition,
           Arrest_Disposition_Notes = ADD3,
           Arrest_Disposition_Date,
           Referred_to_Prosecutor = REF3,
           Juvenile_Arrest = JUV3) %>%
    filter(!is.na(Arrest_Date))

write_csv(Youth_Arrests_Formatted, "Data Sources/Youth Arrests Formatted.csv")

#Generate youth incarceration formatted--------------------------------

Reinc <- import("\\\\tjjd4avsascen\\apps\\ARecid_23\\August\\TDCJ\\COHTDCJ.SAV")

Reinc_No_Dupe <- Reinc %>% 
  filter(duplicate == 0)

idate <- import("\\\\tjjd4avsascen\\apps\\ARecid_23\\August\\idate3.sas7bdat")
idatef <- import("\\\\tjjd4avsascen\\apps\\ARecid_23\\August\\idate_f3.sas7bdat")
idatefmatches <- import("\\\\tjjd4avsascen\\apps\\ARecid_23\\August\\idate_f3_matches.sas7bdat")

#Queries ----------------------------

Youth_Arrests <- read_csv("Data Sources/Youth Arrests Formatted.csv") %>% 
  mutate(Level_and_Degree = factor(Level_and_Degree, c("M*", "MC", "MB", "MA", "F*", "F3", "F2", "F1", "FX"), ordered = TRUE)) %>% 
  filter(Level_and_Degree >= "MB")

Masterfiles <- Masterfiles_Get(Timeframe = "Historical")

Assignments <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=IRD035",rows_at_time=1),
                        "SELECT TYCNO, ASPTR, PRLSTAT, ERDMDY, LOC, ASMDY, EASMDY, PRELOC, MVNTCODE, MVNTTYPE FROM POPASFixed") %>%
  left_join(Location_Type_Lookup,by = c("LOC" = "Location_Code")) %>%
  left_join(Location_Type_Lookup, by = c("PRELOC" = "Location_Code")) %>% 
  mutate(Earliest_Release_Date=as.Date(ERDMDY,origin="1960-01-01"),
         Assignment_Start_Date=as.Date(ASMDY,origin="1960-01-01"),
         Assignment_End_Date=as.Date(EASMDY,origin="1960-01-01"),
         Assignment_Duration=if_else(Assignment_End_Date==as.Date("2099-12-31"),
                                     -1,
                                     as.numeric(Assignment_End_Date-Assignment_Start_Date))) %>%
  select(TJJD_Number=TYCNO,
         Assignment_Pointer_Number=ASPTR,
         Assignment_Start_Date,
         Assignment_End_Date,
         Assignment_Duration,
         Earliest_Release_Date,
         Parole_Status=PRLSTAT,
         Assignment_Location = Assignment_Location.x,
         Facility = Facility.x,
         Security_Level = Security_Level.x,
         Facility_Type = Facility_Type.x,
         Previous_Assignment = Assignment_Location.y,
         Previous_Security_Level = Security_Level.y,
         Previous_Facility_Type = Facility_Type.y,
         Movement_Type=MVNTTYPE,
         Movement_Code=MVNTCODE) %>%
  left_join(Movement_Code_Lookup)

Demographics <- ID_Get() %>% 
  select(TJJD_Number, First_Name, Last_Name)

#Create cohorts. Releases to non-secure and discharges.  --------------------

Movement_from_Secure_Recidivism <- Assignments %>% 
  left_join(Assignments %>% 
              mutate(Assignment_Pointer_Number = Assignment_Pointer_Number + 1) %>% 
              select(TJJD_Number, Assignment_Pointer_Number, Prior_Movement_Type = Movement_Type, Prior_Movement_Description = Movement_Description)) %>% 
  mutate(Release_Date = Assignment_Start_Date,
         Release_FY = State_FY(Release_Date),
         Type = str_c("Movement from Secure to ", Facility_Type)) %>% 
  filter(Previous_Security_Level %in% c("Secure", "O & A"),
         !Security_Level %in% c("Secure", "O & A"),
         Prior_Movement_Type != "TA",
         !str_detect(tolower(Prior_Movement_Description), "jail")) %>% 
  select(TJJD_Number, Release_Date, Release_FY, Type)

Masterfiles_Recidivism <- Demographics %>% 
  inner_join(Masterfiles) %>% 
  mutate(Release_Date = Discharge_Date,
         Release_FY = State_FY(Discharge_Date),
         Type = str_c("Discharge - ", replace_na(Discharge_Reason, "Missing"))) %>% 
  filter(!Discharge_Reason_Code %in% c("STAD", "JAIL", "TTDC", "DIED", "JACT", NA),
         !First_Name %in% c("Commitment", "Vacated", "Invalid", "Overturned", "Reversed"),
         !Last_Name %in% c("Commitment", "Vacated", "Invalid", "Overturned", "Reversed")) %>% 
  select(TJJD_Number, Release_Date, Release_FY, Type)

Masterfiles_Excluded <- Masterfiles %>% 
  mutate(Release_Date = Discharge_Date,
         Release_FY = State_FY(Discharge_Date),
         Type = "Excluded") %>% 
  anti_join(Masterfiles_Recidivism, by = "TJJD_Number") %>% 
  group_by(TJJD_Number) %>% 
  summarize_all(first)

Cohort_Recidivism <- bind_rows(Masterfiles_Recidivism, Movement_from_Secure_Recidivism) %>% 
  arrange(TJJD_Number, Release_Date)

First_Release_Date <- Cohort_Recidivism %>% 
  group_by(TJJD_Number) %>% 
  summarize(First_Release_Date = first(Release_Date),
            Release_FY = first(Release_FY),
            Release_Type = first(Type)) %>% 
  ungroup() %>% 
  filter(Release_FY <= 2020)

Arrest_vs_Release <- Youth_Arrests %>% 
  inner_join(First_Release_Date) %>% 
  mutate(Release_to_Arrest = Arrest_Date - First_Release_Date) %>% 
  filter(Release_to_Arrest >= 0,
         Release_to_Arrest <= years(3))

#This differentiates between arrests in 2nd year vs. first year etc

Arrest_Format <- Arrest_vs_Release %>% 
  mutate(`1-Year` = Release_to_Arrest < days(365),
         `2-Year` = Release_to_Arrest < years(2),
         `3-Year` = Release_to_Arrest < years(3)) %>% 
  pivot_longer(`1-Year`:`3-Year`, names_to = "Years_from_Release", values_to = "Present") %>% 
  filter(Present) %>% 
  group_by(TJJD_Number, Years_from_Release) %>% 
  summarize(Worst_Level = max(Level_and_Degree),
            Violent = max(Violent)) %>% 
  ungroup() %>% 
  mutate(Any_Arrest = !is.na(Worst_Level),
         Felony_Arrest = str_detect(Worst_Level, "F"),
         Violent_Felony_Arrest = str_detect(Worst_Level, "F") & Violent)

Release_Format <- First_Release_Date %>% 
  mutate(Time_from_Release = as.Date("2021-08-31") - First_Release_Date,
         `1-Year` = Time_from_Release >= days(365),
         `2-Year` = Time_from_Release >= years(2),
         `3-Year` = Time_from_Release >= years(3)) %>% 
  pivot_longer(`1-Year`:`3-Year`, names_to = "Years_from_Release", values_to = "Present") %>% 
  filter(Present) %>% 
  select(-Present)

Recidivism_by_Youth <- Release_Format %>% 
  left_join(Arrest_Format) %>% 
  mutate(across(contains("Arrest"), ~replace_na(.x, 0))) %>% 
  select(-Time_from_Release) %>% 
  filter(Release_FY >= 2014) %>% 
  select(-Worst_Level, - Violent)

Recid_Check <- Recidivism_by_Youth %>% 
  group_by(Release_FY, Years_from_Release) %>% 
  summarize(N = n(),
            Recid_Rate = mean(Any_Arrest),
            Recid_Felony_Rate = mean(Felony_Arrest),
            Recid_Vio_Felony = mean(Violent_Felony_Arrest)) %>% 
  ungroup()

write_csv(Recidivism_by_Youth, "Data Sources/Youth Recidivism.csv")