library(TJJD)
library(arsenal)


#According to Jocelyn & Christie, there were 562 new admissions in FY23. 
#It's possible for a multiple commitment to be a new admission.
#For this reason, IDMC was added into NEWPOPMFINAL as the assignment pointer to identify the new admissions. IDMC is a commitment
# pointer. That being said, we should be using IDMC to identify new admissions for future iterations of TJJD's admission profile.
# It is still TBD whether we've been using the same methodology throughout the years.

# -----------------------------------------------------------------------------
Masterfiles <- Masterfiles_Get() %>%
  filter(Commitment_Start_Date >= "2022-09-01",
         Commitment_Start_Date <= "2023-08-31",
         Multi_Commit_UID == 1)

Newpopmfinal_newadmissions_citizenstatus <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=IRD035",rows_at_time=1),
                                                     "SELECT TYCNO, IDMC, CIT from NEWPOPMFINAL
                                       WHERE (STMDY BETWEEN '2022-09-01' AND '2023-08-31') AND (IDMC = '1')")

NewAdmissions <- inner_join(Masterfiles, Newpopmfinal_newadmissions_citizenstatus, by = c("TJJD_Number" = "TYCNO", 
                                                                                          "Multi_Commit_UID" = "IDMC"))


Risk_MLOS <- Risk_MLOS_Get(Source = 'sql')

Offense_History <- Offense_History_Get()

Offense_History_Raw <- Offense_History_Get(Source = 'sql')

ID <- ID_Get()

Prior_Placements_Raw <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=IRD035",rows_at_time=1),
                                 "SELECT IDHOME.TYCNO as TJJD_Number, NBROHM as Number_Placements, phendyy, phmm, phtype
         from IDHOME
         left join IDCA
         on IDHOME.TYCNO = IDCA.TYCNO")

Prior_Placements <- Prior_Placements_Raw %>% 
  mutate(Prior_Placement = !is.na(phendyy) | phendyy!="x" | !is.na(phmm) | !is.na(phtype) | Number_Placements >0) %>% 
  select(TJJD_Number, Prior_Placement)

On_Probation_at_Commitment <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=IRD035",rows_at_time=1),
                                       "SELECT TYCNO, PROBATFL
                                       from popmfixed
                                       where MFPTR = 1")

ACE_Scores_Raw <- ACE_Score_Get(Source = 'standard', Timeframe = 'historical')


Missing_ACE <- NewAdmissions %>%
  anti_join(ACE_Scores_Raw, by = "TJJD_Number")


ACE_Scores_PACT <- ACE_Score_Get(Source = "pact")


Missing_ACE_PACT <- ACE_Scores_PACT %>%
  semi_join(Missing_ACE, by = "TJJD_Number")


Completed_ACE_Table <- ACE_Scores_Raw %>%
  bind_rows(Missing_ACE_PACT)



Spec_Ed <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=IRD035",rows_at_time=1), "SELECT DISTINCT TYCNO as TJJD_Number, max(SPED) as Special_Education
                          FROM EDPDTL
                    group by TYCNO")

Test_Scores <- Test_Scores_Get()

Treatment_Needs <- Treatment_Needs_Get()

# Analysis ----------------------------------------------------------------

Offenses_Ind <- NewAdmissions %>% 
  select(TJJD_Number, Determinate_Sentence) %>%
  filter(Determinate_Sentence == "N") %>% 
  inner_join(Risk_MLOS %>% 
               rename(TJJD_Number = tycno)) %>% 
  select(TJJD_Number, Referrals = refs, Adjudications = ajds)


#Question: I removed INMDY which came with the All_Intakes table bc. it wasn't used in the creation of this
Offense_History_Det <- NewAdmissions %>% 
  select(TJJD_Number, Commitment_Start_Date, Determinate_Sentence) %>% 
  left_join(Offense_History) %>% 
  filter(Referral_Date <= Commitment_Start_Date,
         Determinate_Sentence == "Y") %>% 
  mutate(Adjudication_Offense_Level = if_else(Disposition_Code %in% c('AP','AT','CA','PT','ND','AD') & !is.na(Adjudication_Date) & is.na(Adjudication_Offense_Level), 
                                              if_else(is.na(Referral_Offense_Level), as.integer(3), Referral_Offense_Level),
                                              Adjudication_Offense_Level),
         Adjudication_Offense = if_else(Disposition_Code %in% c('AP','AT','CA','PT','ND','AD') & !is.na(Adjudication_Date) & is.na(Adjudication_Offense),
                                        Referral_Offense, Adjudication_Offense),
         N_Ref_Level = if_else(Referral_Offense_Code %in% c(7340, 7350), Adjudication_Offense_Level, Referral_Offense_Level),
         N_Ref_Code = if_else(Referral_Offense %in% c(7340, 7350), Adjudication_Offense, Referral_Offense))

Offenses_Det <- Offense_History_Det %>% 
  group_by(TJJD_Number) %>% 
  summarize(Referrals = sum(Referral_Offense_Level <= 2),
            Adjudications = sum(Adjudication_Offense_Level<=2 & Disposition_Code %in% c('AP','AT','CA','PT','ND','AD')))

Offenses_All <- On_Probation_at_Commitment %>% 
  rename(TJJD_Number = TYCNO,
         Probation_at_Commitment = PROBATFL) %>% 
  left_join(Prior_Placements) %>% 
  left_join(bind_rows(Offenses_Det,
                      Offenses_Ind)) %>% 
  mutate(Ref_3 = Referrals >= 3,
         Adj_2 = Adjudications >= 2) %>% 
  select(-Referrals, -Adjudications)

Test_Scores_First <- Test_Scores %>% 
  group_by(TJJD_Number, Subject) %>% 
  summarize(Score = first(Score),
            Test_Date = first(Test_Date)) %>% 
  pivot_wider(names_from = Subject,
              values_from = c(Test_Date, Score))

Treatment_Needs_First <- Treatment_Needs %>% 
  group_by(TJJD_Number) %>% 
  summarize(across(everything(), first)) %>% 
  ungroup() %>% 
  mutate(Mental_Health_Indicator = if_else(Mental_Health_Priority == "None"|Mental_Health_Priority == "L",0,1),
         Sexual_Behavior_Indicator = if_else(Sexual_Behavior_Priority == "None"|Sexual_Behavior_Priority == "L",0,1),
         Capital_and_Serious_Violent_Indicator = if_else(Capital_and_Serious_Violent_Priority == "None"|Capital_and_Serious_Violent_Priority == "L",0,1),
         Substance_Use_Indicator = if_else(Substance_Use_Priority == "None"|Substance_Use_Priority == "L",0,1),
         Number_Treatment_Needs = rowSums(across(Mental_Health_Indicator:Substance_Use_Indicator)))


#I've removed "Intake_Date" because it's not available in NEWPOPMFINAL. Don't know what to do about that.
#When comparing STMDY and INMDY from the All_Intakes table, STMDY is not always equal to
#INMDY, therefore, it's not a viable replacement.
#Something else is that Age_at_Intake is calculated off of the INMDY variable. Bc. it's not present,
#I can't calculate it. I can, however, replace Age_at_Intake with Age_at_Commitment_Start
Intakes_Format <- NewAdmissions %>%
  left_join(ID) %>% 
  left_join(Offenses_All) %>% 
  left_join(Treatment_Needs_First) %>% 
  left_join(Completed_ACE_Table) %>% 
  left_join(Test_Scores_First) %>%
  left_join(Spec_Ed) %>%
  mutate(DOB = as.Date(DOB),
         Age_at_Commitment_Start = floor(as.numeric(as.Date(Commitment_Start_Date) - as.Date(DOB)) / 365.25),
         Reading_to_Grade_Level = round(as.numeric(Test_Date_Reading - DOB)/365.25, 1) - Score_Reading - 5.5,
         Math_to_Grade_Level = round(as.numeric(Test_Date_Total_Math - DOB)/365.25, 1) - Score_Total_Math - 5.5,
         At_Grade_Level_Reading = if_else(Reading_to_Grade_Level > 0, 0, 1),
         At_Grade_Level_Math = if_else(Math_to_Grade_Level > 0, 0, 1))



#Excluding Last_Commitment_County because it's not relevant.
#Intake FY would be missing (no 1:1 replacement in NEWPOPMFINAL for INMDY).
#Replaced with Commitment FY.
#"Intake_Date" interestingly was associated with the STMDY variable,
# yet Age_At_Intake was calculated based off of INMDY.
# Intake Date was replaced with Commitment Start Date.
#"FelonyLevel" was replaced with "Classifying_Offense_Felony_Level"

Profile_Data <- Intakes_Format %>%
  separate(Commitment_Start_Date, into = c("Year", "Month", "Day"), convert = TRUE, remove = FALSE) %>%
  mutate("Intake_FY" = case_when(Month >= 9 ~ (Year + 1),
                                 TRUE ~ as.numeric(Year)
  )
  ) %>%
  select(TJJD_Number,
         First_Name,
         Last_Name,
         Citizenship = CIT,
         Sex,
         Race,
         Age_at_Intake = Age_at_Commitment_Start,
         Commitment_County,
         Classifying_Offense_Code,
         Classifying_Offense,
         Probation_at_Commitment:Adj_2,
         Intake_FY,
         Intake_Date = Commitment_Start_Date,
         FelonyLevel = Classifying_Offense_Felony_Level,
         Determinate = Determinate_Sentence,
         Reading_to_Grade_Level,
         At_Grade_Level_Reading,
         Math_to_Grade_Level,
         At_Grade_Level_Math,
         Special_Education,
         Mental_Health_Priority,
         Substance_Use_Priority,
         Sexual_Behavior_Priority,
         Capital_and_Serious_Violent_Priority,
         Mental_Health_Indicator,
         Substance_Use_Indicator,
         Sexual_Behavior_Indicator,
         Capital_and_Serious_Violent_Indicator,
         Number_Treatment_Needs,
         Emotional_Abuse:ACE_Score)

Profile_Data2 <- Profile_Data
Profile_Data2$Prior_Placement[is.na(Profile_Data2$Prior_Placement)] <- "FALSE"
Profile_Data2$Adj_2[is.na(Profile_Data2$Adj_2)] <- "FALSE"
Profile_Data2$Ref_3[is.na(Profile_Data2$Ref_3)] <- "FALSE"

count(Profile_Data, Sexual_Behavior_Indicator)

Median_Below_Grade_Level <- Profile_Data %>% 
  group_by(Intake_FY) %>% 
  summarize(Median_Reading = median(Reading_to_Grade_Level, na.rm = TRUE),
            Median_Math = median(Math_to_Grade_Level, na.rm = TRUE)) %>% 
  mutate(across(everything(), as.character)) %>% 
  pivot_longer(Median_Reading:Median_Math, names_to = "Metric", values_to = "n")

Summary_Counts <- map_df(colnames(Profile_Data2 %>% 
                                    select(-c(TJJD_Number:Last_Name, Reading_to_Grade_Level, Math_to_Grade_Level))),
                         ~count(Profile_Data, Intake_FY, !!sym(.x)) %>% 
                           mutate(Metric = .x,
                                  across(everything(), as.character)) %>% 
                           rename(Variable = .x)
) %>% 
  bind_rows(Median_Below_Grade_Level) %>% 
  pivot_wider(names_from = Intake_FY, values_from = `n`)


Profile_Data2 <- Profile_Data2 %>%
  relocate(
    TJJD_Number,
    First_Name,
    Last_Name,
    Citizenship,
    Sex,
    Race,
    Age_at_Intake,
    Commitment_County,
    Classifying_Offense_Code,
    Classifying_Offense,
    Probation_at_Commitment,
    Prior_Placement,
    Ref_3,
    Adj_2,
    Intake_FY,
    Intake_Date,
    FelonyLevel,
    Determinate,
    Reading_to_Grade_Level,
    Math_to_Grade_Level,
    Special_Education,
    Emotional_Abuse,
    Emotional_Neglect,
    Family_Violence,
    Household_Mental_Illness,
    Household_Substance_Abuse,
    Incarcerated_Household_Member,
    Parents_Separated_Divorced,
    Physical_Abuse,
    Physical_Neglect,
    Sexual_Abuse,
    ACE_Score,
    At_Grade_Level_Reading,
    At_Grade_Level_Math,
    Substance_Use_Indicator,
    Sexual_Behavior_Indicator,
    Capital_and_Serious_Violent_Indicator,
    Substance_Use_Priority,
    Sexual_Behavior_Priority,
    Capital_and_Serious_Violent_Priority,
    Mental_Health_Priority,
    Mental_Health_Indicator,
    Number_Treatment_Needs
  )

# Output ------------------------------------------------------------------
FYs <- str_c("FY", year(today()), "_")

write_csv(Profile_Data2, str_c("Output/", FYs, "Underlying Admission Data.csv"))
