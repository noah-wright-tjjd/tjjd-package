library(TJJD)

source("R/DB/Noble.R")

ID <- ID_Get()

Parent_Status <- sqlQuery(Noble,
                          "SELECT Form_Instance_ID_FK as Form_Instance_ID, Question_ID_FK as Question_ID, Answer_ID_FK as Answer_ID
         from NSG_FORM_INSTANCE_Answer_Value
         where Answer_ID_FK in (10556, 10558)")

Form_Instances <- sqlQuery(Noble,
                           "SELECT S.EID as TJJD_Number, Form_Instance_ID, FI.DATE_COMPLETED as Date_Completed, FO.NAME as Form, FLL.NAME as Form_Admin_Type
FROM   NSG_FORM_INSTANCE FI
INNER JOIN NSG_SUBJECT S ON 
(S.SUBJECT_ID = FI.SUBJECT_ID_FK)
INNER JOIN NSG_FORM FO ON 
(FI.FORM_ID_FK = FO.FORM_ID)
INNER JOIN NSG_FORM_LABEL_LOOKUP FLL ON 
(FI.FORM_LABEL_ID_FK=FLL.FORM_LABEL_ID)
WHERE FI.STATUS=400")

Current <- Assignments_Get() |> 
  filter(Assignment_End_Date == "2099-12-31")

Youth_With_Kids <- Current %>% 
  inner_join(ID) |> 
  semi_join(Form_Instances %>% 
              semi_join(Parent_Status)) |> 
  select(TJJD_Number, First_Name, Last_Name, DOB, Assignment_Location)

write_csv(Youth_With_Kids, "Youth with Kids.csv")
