library(TJJD)

#"idate" series of files contain incarceration recidivism indicators
#Try the following when network connection reestablished:
#Youth_Arrests_Raw <- read_sas("\\\\tjjd4avsascen\\apps\\Performance Measures\\FY 2023\\DPS\\Data\\Q4\\August Request\\arrest_maint_match.sas7bdat")
#Except from the tdcj folder, see if there's a link akin to arrest_maint_match

Arecid_Directory <- "Data Sources/Arecid_23/"

Arecid_Doc_Index <- data.frame(Filename = list.files(Directory)) %>% 
  mutate(Directory_Name = str_c(Arecid_Directory, Filename))

SAS_Data_Files <- Arecid_Doc_Index %>% 
  filter(str_detect(Filename, "sas7bdat"))

SAS_Data <- map(SAS_Data_Files %>% 
                  pull(Directory_Name), ~import(.x))

names(SAS_Data) <- str_remove_all(SAS_Data_Files %>% 
                                    pull(Filename), ".sas7bdat")

SPSS_File <- import("Data Sources/ARecid_23/TDCJ/COHTDCJ.SAV")
