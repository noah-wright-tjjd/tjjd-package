library(TJJD)
library(survival)
library(survminer)

Analysis_Start_Date <- as.Date("2018-04-01")
Analysis_End_Date <- as.Date("2021-03-01")

CEI<-sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=TYCEmployees",rows_at_time=1),
              "SELECT emplID, hiredate, rehiredate
           FROM CAPPS_CEI_Empl") %>%
  mutate(Hire_Date=as.Date(hiredate,format="%m/%d/%Y"),
         Rehire_Date=as.Date(rehiredate,format="%m/%d/%Y")) %>%
  select(TINSID=emplID,
         Hire_Date,
         Rehire_Date) %>%
  filter(Hire_Date!=Rehire_Date)

PG2 <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=TYCEmployees",rows_at_time=1),
                "SELECT TINSID, FullName, Email, LastHireDate, TerminationDate, BirthDate, EthnicCode, Gender, SeniorityDate, JobCodeDescription, PositionCodeDescription, CCSLocCode, Location, SupervisorFullname
                                          FROM TYC_PG2_JOB_CURR")

Combined <- PG2 %>%
  left_join(CEI) %>%
  mutate(Initial_Hire_Date = as.Date(LastHireDate),
         Termination_Date=as.Date(TerminationDate),
         State_Seniority_Date=as.Date(SeniorityDate),
         Birth_Date=as.Date(BirthDate),
         CCS_Loc_Code=str_replace(CCSLocCode,"MCA","MCL"),
         CCS_Loc_Code=str_replace(CCS_Loc_Code,"HNU","HKH"),
         CCS_Loc_Code=if_else(str_detect(PositionCodeDescription,"Case")==TRUE &
                                str_detect(tolower(PositionCodeDescription),"trans")==TRUE,"TRA",CCS_Loc_Code),
         CCS_Loc_Code=if_else(str_detect(PositionCodeDescription,"Case")==TRUE,str_replace(CCS_Loc_Code,"BOA","BWD"),CCS_Loc_Code)) %>%
  select(Employee_ID=TINSID,
         Name=FullName,
         Email,
         Birth_Date = BirthDate,
         Gender,
         Ethnicity = EthnicCode,
         Job_Code_Description = JobCodeDescription,
         Position_Code_Description = PositionCodeDescription,
         State_Seniority_Date,
         Initial_Hire_Date,
         Rehire_Date,
         Termination_Date = TerminationDate,
         Location_Code = CCS_Loc_Code,
         HR_Location = Location,
         Supervisor = SupervisorFullname) %>%
  left_join(Location_Type_Lookup, "Location_Code")

CM_Survival <- function(Analysis_Start, Analysis_End) {
  Start_Date<-as.Date(Analysis_Start)
  End_Date<-as.Date(Analysis_End)
  
  Coaches_Survival<-Combined  %>% 
    mutate(Last_Hire_Date = if_else(is.na(Rehire_Date), Initial_Hire_Date, Rehire_Date),
           Employment_Days = if_else(is.na(Termination_Date), as.numeric(Analysis_End - Last_Hire_Date), as.numeric(as.Date(Termination_Date) - Last_Hire_Date)),
           Terminated = if_else(is.na(Termination_Date), 0, 1)) %>% 
    filter(str_detect(Job_Code_Description, "Case"),
           Initial_Hire_Date >= Start_Date)
}

Case_Manager_Data<-CM_Survival("2012-09-01", today())

By_First_Year<-Coach_Data %>% 
  mutate(Start_Year = year(Last_Hire_Date),
         Fiscal_Start_Year = if_else(month(Last_Hire_Date) %in% c(9:12), year(Last_Hire_Date) + 1, year(Last_Hire_Date)),
         Second_Year_Days = if_else(Employment_Days>=365, 365, Employment_Days),
         Second_Year_Term = if_else(Employment_Days>365, 0, Terminated))

SurvDataFit<-survfit(Surv(Second_Year_Days, Second_Year_Term) ~ Facility, data = By_First_Year %>% 
                       filter(Facility_Type == "Secure"))

summary(SurvDataFit)

ggsurvplot(
  fit = SurvDataFit,
  xlab = "Days", 
  ylab = "Retention Probability")

#% loss after first 90 days
#% loss after first 6 months
#% loss after first year
#% loss after first 2 years

#Any predictors of loss rate?

write_csv(Employee_Summary, "Employees.csv")
