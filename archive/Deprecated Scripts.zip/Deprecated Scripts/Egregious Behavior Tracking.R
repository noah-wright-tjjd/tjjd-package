library(TJJD)

options(scipen = 999)

Start_Period <- as.Date("2018-09-01")
End_Period <- as.Date("2024-08-31")

#How frequently is youth assaulting / placed on suicide alert during their
#facility time?

Incidents <- Incidents_Get()
Incident_RV <- Incident_Rule_Violations_Get()
L2 <- L2_Hearings_Get()
SA <- Suicide_Assessments_Get()
Assignments <- Assignments_Get()

#Have to control for total days in the program over time period

Days_in_Secure <- Assignments %>% 
  filter(Assignment_End_Date >= End_Period,
         Facility_Type %in% c("Secure", "O & A")) %>% 
  mutate(Assignment_Duration = as.numeric(
    if_else(Assignment_End_Date >= End_Period, End_Period, Assignment_End_Date) -
      if_else(Assignment_Start_Date <= Start_Period, Start_Period, Assignment_Start_Date)))

RV <- Incident_RV %>% 
  select(-All_Rule_Violations) %>% 
  ungroup()

#Suicide Alerts

SA_Cohort <- SA %>% 
  filter(!Assessment %in% c("Not Assessed", "Remove"),
         Assessment_Date >= Start_Period,
         Assessment_Date <= End_Period)

#All fighting, assault, chunking, threaten with weapon

Aggression_RV <- RV %>% 
  ungroup() %>% 
  count(Rule_Violation, Description) %>% 
  filter(str_detect(Description, "Assault|Fighting|Chunk|with a Weapon"),
         !str_detect(Description, "Unauth")) %>% 
  pull(Rule_Violation)

Aggression <- Incidents %>% 
  filter(Facility_Type %in% c("Secure", "O & A"),
         Incident_Date <= End_Period,
         Incident_Date >= Start_Period) %>% 
  inner_join(RV %>% 
              filter(Rule_Violation %in% Aggression_RV))

L2_All <- L2 %>% 
  filter(Hearing_Date >= Start_Period,
         Hearing_Date <= End_Period)

#Attempted Escape and Escape

Escape <- Incidents %>% 
  filter(Facility_Type %in% c("Secure", "O & A"),
         Incident_Date >= Start_Period,
         Incident_Date <= End_Period) %>% 
  semi_join(RV %>% 
              filter(str_detect(Rule_Violation, "ESC")))

#Program_Destroying 
#Distribution of substances, possession of substances,
#hostage incident, security referral, resisting movement/ removal, disrupting
#scheduled activity, major disruption of facility operations,
#extortion/blackmail, tampering with safety equip, tampering with monitoring
#equip?

Program_Destroying_RV <- RV %>% 
  ungroup() %>% 
  count(Rule_Violation, Description) %>% 
  filter(str_detect(Description, "Sub|Host|Disrup|Extor|Tamper")) %>% 
  pull(Rule_Violation)

Program_Destroying <- Incidents %>% 
  left_join(RV %>% 
              filter(Rule_Violation %in% Program_Destroying_RV) %>% 
              select(TJJD_Number, Incident_Pointer_Number) %>% 
              unique() %>% 
              mutate(Program_Destroying = 1)) %>% 
  filter(RSU_Referral == 1 | Program_Destroying == 1,
         Incident_Date >= Start_Period,
         Incident_Date <= End_Period) 

# Egregious_Behavior_Rates <- SA_Cohort %>% 
#   bind_rows(Aggression) %>% 
#   bind_rows(Escape) %>% 
#   bind_rows(Program_Destroying) %>% 
#   bind_rows(L2_All) %>% 
#   inner_join(N_Cohort) %>% 
#   inner_join(Days_in_Secure) %>% 
#   mutate(Rate_per_100_youth_per_month = 3000 * Count / Secure_Days,
#          Percent = Youth/n) %>% 
#   select(-Count, -Youth, -n, -Secure_Days) %>% 
#   pivot_wider(names_from = Cohort, values_from = c(Rate_per_100_youth_per_month, Percent))


