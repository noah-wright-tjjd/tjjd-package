library(TJJD)

PACT_Directory <- "Data Sources/PACT Results - Quarterly/"

PACT_Results <- map_df(list.files(PACT_Directory),
                       ~read_csv(str_c(PACT_Directory, .x)))

Aliased_PACT_Results_Produced <- read_csv("PACT Results for UNO Request.csv")

Form_Alias_Produced <- Aliased_PACT_Results_Produced %>% 
  select(Form_Instance_ID, Alias_Number) %>% 
  unique()

Form_Original <- PACT_Results %>% 
  select(Form_Instance_ID, TJJD_Number) %>% 
  unique()

Original_Form_Aliasing <- Form_Alias %>% 
  inner_join(Form_Original) %>% 
  select(TJJD_Number, Alias_Number) %>% 
  unique()

UNO_Cohort_Produced <- read_csv("UNO Cohort.csv")

Alias_Match <- UNO_Cohort_Produced %>% 
  rename(Alias_Number_Non_PACT = Alias_Number) %>% 
  inner_join(Original_Form_Aliasing %>% 
               rename(Alias_Number_PACT = Alias_Number)) %>% 
  select(-TJJD_Number)

write_csv(Alias_Match, "Alias Match.csv")

Original Code

Cohort <- bind_cols(Cohort_Aliasing, data.frame(Alias_Number = sample(c(200000:300000), nrow(Cohort_Aliasing))))

write_csv(Cohort, "UNO Cohort.csv")

Aliased_PACT_Results <- PACT_Results %>% 
  inner_join(Cohort) %>% 
  select(-TJJD_Number) %>% 
  relocate(Alias_Number)

Aliased_PACT_Results %>% 
  filter(User_ID == 1867, Form_Instance_ID == 194258)

write_csv(Aliased_PACT_Results, "PACT Results for UNO Request.csv", na = "")
