library(dplyr)
library(gganimate)
library(gapminder)


anim <- ggplot(mtcars, aes(mpg, disp)) +
  transition_states(gear, transition_length = 2, state_length = 1) +
  enter_fade() +
  exit_fade()


animate(anim)


# Change all to 'cubic-in-out' for a smoother appearance
anim1 <- anim +
  ease_aes('cubic-in-out')

animate(anim1)


# Only change easing of y variables
anim2 <- anim +
  ease_aes(y = 'bounce-in')
## Not run: 
##D animate(anim2)
## End(Not run)

data <- data.frame(
  x = 1:10,
  y = runif(10),
  begin = runif(10, 1, 100),
  length = runif(10, 5, 20),
  enter = runif(10, 5, 10),
  exit = runif(10, 5, 10)
)

anim <- ggplot(airquality, aes(Day, Temp)) +
  geom_point(aes(colour = factor(Month))) +
  transition_time(Day)

# Removing a time point will prolong the tweening between neighbouring time
# points so the time dimension stays linear
airquality_missing <- airquality[airquality$Day <= 10 | airquality$Day >= 20, ]
anim1 <- ggplot(airquality_missing, aes(Day, Temp)) +
  geom_point(aes(colour = factor(Month))) +
  transition_time(Day)

# Range can be constrained if needed
anim2 <- ggplot(airquality, aes(Day, Temp)) +
  geom_point(aes(colour = factor(Month))) +
  transition_time(Day, range = c(10L, 20L))

# The group aesthetic is used to connect elements
# No grouping
anim3 <- ggplot(airquality, aes(Day, Temp)) +
  geom_line() +
  transition_time(Month)

# Group by month
anim4 <- ggplot(airquality, aes(Day, Temp)) +
  geom_line(aes(group = Month)) +
  transition_time(Month) +
  enter_fade() +
  exit_fade()

anim <- ggplot(airquality, aes(Day, Temp, group = Month)) +
  geom_line() +
  transition_reveal(Day)

# Non-paths will only show the current position, not the history
anim1 <- ggplot(airquality, aes(Day, Temp, group = Month)) +
  geom_line() +
  geom_point(colour = 'red', size = 3) +
  transition_reveal(Day)

# Points can be kept by giving them a unique group and set `keep = TRUE` (the
# default)
anim2 <- ggplot(airquality, aes(Day, Temp, group = Month)) +
  geom_line() +
  geom_point(aes(group = seq_along(Day))) +
  geom_point(colour = 'red', size = 3) +
  transition_reveal(Day)

# Since ggplot2 3.4 geom_ribbon and geom_area has used stat_align
# This stat is incompatible with transition_reveal when applied before
# stats are calculated
anim3 <- ggplot(airquality, aes(Day, Temp, group = Month)) +
  geom_area() +
  transition_reveal(Day)

# This can be fixed by either reverting to use stat_identity
anim4 <- ggplot(airquality, aes(Day, Temp, group = Month)) +
  geom_area(stat = "identity") +
  transition_reveal(Day)

# Or by applying the transition after the stat
anim5 <- ggplot(airquality, aes(Day, Temp, group = Month)) +
  geom_area() +
  transition_reveal(after_stat(x))