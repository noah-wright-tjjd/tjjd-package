library(TJJD)

#Bracket employee ages by 5-year intervals

Employees <- Employee_Summary_Get()

Age_Check <- Employees |> 
  filter(str_detect(Job_Code_Description, "JCO"),
         Facility %in% Facilities,
         is.na(Termination_Date)) |> 
  mutate(Age = floor(as.numeric(today() - as.Date(Birth_Date))/365.25),
         Age_Bracket = case_when(Age <= 25 ~ "21-25",
                                 Age <= 30 ~ "26-30",
                                 Age <= 35 ~ "31-35",
                                 Age <= 40 ~ "36-40",
                                 Age <= 50 ~ "41-50",
                                 Age <= 60 ~ "51-60",
                                 TRUE ~"61+"))

Age_Check |> 
  count(Facility, Age_Bracket) |> 
  group_by(Facility) |> 
  mutate(Percent = n/sum(n)) |> 
  ungroup() |> 
  write_csv("JCO Age.csv")

Age_Check |> 
  ggplot(aes(x = Age)) +
  geom_histogram() +
  facet_wrap(~Facility)

Age_Check |> 
  mutate(Under40 = Age <= 30) |> 
  count(Facility, Under40) |> 
  group_by(Facility) |> 
  summarize(Percent = n/sum(n))

#Investigate why ALOS is declining

#More early transfers?

#Older youth coming in?

ID <- ID_Get()

MF <- MF_Get()

Discharges <- MF |> 
  filter(!is.na(Discharge_Date), !is.na(Discharge_Reason))

