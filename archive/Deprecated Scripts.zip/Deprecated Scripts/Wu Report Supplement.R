library(TJJD)

MF <- MF_Get()

DateParam <- "2025-03-31"

Cohort <- MF |> 
  filter(Admission_Date <= DateParam,
         Commitment_End_Date >= DateParam) |> 
  select(TJJD_Number)

Initial <- MF |> 
  mutate(Determinate_Sentence = if_else(TJJD_Number == 1303855, "N", Determinate_Sentence),
         Determinate_Sentence = if_else(TJJD_Number == 1304434, "N", Determinate_Sentence)
  ) |> 
  group_by(TJJD_Number) |> 
  summarize_all(first) |> 
  ungroup() |> 
  semi_join(Cohort) |> 
  mutate(Committing_Offense = if_else(is.na(Classifying_Offense), Commitment_Offense, Classifying_Offense),
         Committing_Offense_Level = if_else(is.na(Classifying_Offense_Felony_Level), Commitment_Offense_Felony_Level, Classifying_Offense_Felony_Level)) |> 
  select(TJJD_Number, Determinate_Sentence, Commitment_County, Committing_Offense, Committing_Offense_Level) |> 
  na.omit()

Cohort |> 
  anti_join(Initial) |> 
  inner_join(MF)

write_csv(Initial, "WuTable Mar 31 2025.csv", na = "")
