library(tidyverse)
library(tidymodels)

options(scipen = 999)

#Introduction ----------------------------

data(crickets, package = "modeldata")
names(crickets)

# Plot the temperature on the x-axis, the chirp rate on the y-axis. The plot
# elements will be colored differently for each species:
ggplot(crickets, 
       aes(x = temp, y = rate, color = species, pch = species, lty = species)) + 
  # Plot points for each data point and color by species
  geom_point(size = 2) + 
  # Show a simple linear model fit created separately for each species:
  geom_smooth(method = lm, se = FALSE, alpha = 0.5) + 
  scale_color_brewer(palette = "Paired") +
  labs(x = "Temperature (C)", y = "Chirp Rate (per minute)")

interaction_fit <-  lm(rate ~ (temp + species)^2, data = crickets) 

# To print a short summary of the model:
interaction_fit

# Place two plots next to one another:
par(mfrow = c(1, 2))

# Show residuals vs predicted values:
plot(interaction_fit, which = 1)

# A normal quantile plot on the residuals:
plot(interaction_fit, which = 2)

# Fit a reduced model:
main_effect_fit <-  lm(rate ~ temp + species, data = crickets) 

# Compare the two:
anova(main_effect_fit, interaction_fit)

summary(main_effect_fit)

new_values <- data.frame(species = "O. exclamationis", temp = 15:20)

predict(main_effect_fit, new_values)

corr_res <- map(mtcars %>% select(-mpg), cor.test, y = mtcars$mpg)

# The first of ten results in the vector: 
corr_res[[1]]

library(broom)

tidy(corr_res[[1]])

corr_res |> 
  map_dfr(tidy, .id = "predictor") |> 
  ggplot(aes(x = fct_reorder(predictor, estimate))) +
  geom_point(aes(y = estimate)) +
  geom_errorbar(aes(ymin = conf.low, ymax = conf.high), width = 1) +
  labs(x = NULL, y = "Correlation with mpg")

split_by_species <- crickets |> 
  group_nest(species)

split_by_species

model_by_species <- split_by_species |> 
  mutate(model = map(data, ~lm(rate ~ temp, data = .x)))

model_by_species |> 
  mutate(coef = map(model, tidy)) |> 
  select(species, coef) |> 
  unnest(cols = coef)

#Modeling Basics -----------------------

data(ames)

ggplot(ames, aes(x = Sale_Price)) + 
  geom_histogram(bins = 50, col= "white") +
  scale_x_log10()

ames_mod <- ames |> 
  mutate(Sale_Price = log10(Sale_Price))

library(skimr)

ames |> skim()

set.seed(501)

ames_split <- initial_split(ames_mod, prop = .8)

ames_split

ames_train <- training(ames_split)
ames_test <- testing(ames_split)

#Stratified, but defaults to stratifying on quartiles (no other options?)

set.seed(502)

ames_split_strata <- initial_split(ames, prop = 0.8, strata = Sale_Price)

#Split with validation set

set.seed(52)

# To put 60% into training, 20% in validation, and 20% in testing:

ames_val_split_val <- initial_validation_split(ames, prop = c(0.6, 0.2))
ames_val_split_val

#Model assumes independent unit of analysis (not, e.g. the same entity over time)

linear_reg() |> set_engine("lm")

linear_reg() |> set_engine("glmnet")

linear_reg() |> set_engine("stan")

linear_reg() |> set_engine("lm") |> translate()

linear_reg(penalty = 1) |> set_engine("glmnet") |> translate()

linear_reg() |> set_engine("stan") |> translate()

lm_model <- linear_reg() |> 
  set_engine("lm")

lm_form_fit <- lm_model |> 
  fit(Sale_Price ~ Longitude + Latitude, data = ames_train)

lm_form_fit

lm_xy_fit <- lm_model |> 
  fit_xy(x = ames_train |> select(Longitude, Latitude),
         y = ames_train |> select(Sale_Price))

lm_xy_fit

rand_forest(trees = 1000, min_n = 5) |> 
  set_engine("ranger", verbose = TRUE) |> 
  set_mode("regression") |> 
  translate()

lm_form_fit |> 
  extract_fit_engine()

lm_form_fit |> 
  extract_fit_engine() |> 
  vcov()

model_res <- lm_form_fit |> 
  extract_fit_engine() |> 
  summary()

model_res

param_est <- model_res |> 
  coef()

param_est

class(param_est)

param_est

tidy(lm_form_fit)

ames_test_small <- ames_test |> 
  slice(1:5)

ames_test_small_pred <- predict(lm_form_fit, new_data = ames_test_small)

ames_test_small |> 
  select(Sale_Price) |> 
  bind_cols(ames_test_small_pred) |> 
  bind_cols(predict(lm_form_fit, new_data = ames_test_small, type = "pred_int"))

tree_model <- decision_tree(min_n = 2) |> 
  set_engine("rpart") |> 
  set_mode("regression")

tree_fit <- tree_model |> 
  fit(Sale_Price ~ Longitude + Latitude, data = ames_train)

ames_test_small |> 
  select(Sale_Price) |> 
  bind_cols(predict(tree_fit, ames_test_small))

#Workflow

lm_model <- linear_reg() |> 
  set_engine("lm")

lm_wflow <- workflow() |> 
  add_model(lm_model)

lm_wflow

lm_wflow <- lm_wflow |> 
  add_formula(Sale_Price ~ Longitude + Latitude)

lm_wflow

lm_fit <- fit(lm_wflow, ames_train)

lm_fit

predict(lm_fit, ames_test)

lm_fit |> update_formula(Sale_Price ~ Longitude)

lm_wflow <- lm_wflow |> 
  remove_formula() |> 
  add_variables(outcome = Sale_Price, predictors = c(Longitude, Latitude))

fit(lm_wflow, ames_train)
