rm(list=ls())

library(TJJD)

IncidentRV<-GetIncidentRuleViolations()
Incidents<-GetIncidents()
L2Data<-GetL2Hearings()
RSUData<-GetRSUDetention() %>%
  filter(AdmissionType=="S")

L2Upheld<-L2Data %>%
  filter(HearingOffenseProven=="Y") %>%
  group_by(TJJDNumber,IncidentPointerNumber) %>%
  summarize(L2Upheld=max(HearingOffenseProven)) 

SecurityAdmission<-RSUData %>%
  select(TJJDNumber,IncidentPointerNumber,SecurityAdmission=AdmissionType)

RVIndicators<-IncidentRV %>%
  filter(str_detect(Description,c("Assault|Fighting|with a Weapon"))==TRUE) %>%
  select(TJJDNumber,IncidentPointerNumber,Description) %>%
  mutate(Indicator=1) %>%
  pivot_wider(names_from = Description,values_from = Indicator) %>%
  group_by(TJJDNumber,IncidentPointerNumber) %>%
  summarize_all(list(max)) %>%
  ungroup() %>%
  mutate(Aggressive=1)

#Secure Facilities, January 2018 and August 2019 onward

MetricUniverse<-Incidents %>%
  filter(IncidentDate>=as.Date("2017-12-01") & IncidentDate<=as.Date("2020-01-31"),
         FacilityType=="Secure"|FacilityType=="O & A") %>%
  left_join(L2Upheld) %>%
  left_join(SecurityAdmission) %>%
  left_join(RVIndicators) %>%
  mutate_if(is.factor,as.character) %>%
  mutate(L2Upheld=if_else(is.na(L2Upheld)==TRUE,"N","Y"),
         SecurityAdmission=if_else(is.na(SecurityAdmission)==TRUE,"N","Y"),
         UseOfChemicalAgent=if_else(is.na(UseOfChemicalAgent)==TRUE,"N","Y"),
         UseofPhysicalForce=if_else(is.na(UseofPhysicalForce)==TRUE,"N","Y"),
         MechanicalRestraintsUsedInSecurity=if_else(is.na(MechanicalRestraintsUsedInSecurity)==TRUE,"N","Y"),
         MechanicalRestraintsUsedForControl=if_else(is.na(MechanicalRestraintsUsedForControl)==TRUE,"N","Y"),
         MechanicalRestraintsUsedDuringNonRoutineTransportation=if_else(is.na(MechanicalRestraintsUsedDuringNonRoutineTransportation)==TRUE,"N","Y"))

MetricUniverse[is.na(MetricUniverse)] <- 0
MetricUniverse<-MetricUniverse[!duplicated(MetricUniverse[c("TJJDNumber","IncidentPointerNumber")]),]

RVbyFacility<-MetricUniverse %>%
  group_by(Facility,Month=floor_date(IncidentDate,'month')) %>%
  summarize(`Security referrals`=sum(SecurityReferral=="Y"&PriorityRuleViolationCategory!=9),
            `Security referrals w/o admission`=sum(SecurityReferral=="Y"&SecurityAdmission=="N"&PriorityRuleViolationCategory!=9),
            `OC Spray`=sum(UseOfChemicalAgent=="Y"),
            `Manual Restraint`=sum(UseofPhysicalForce=="Y"),
            `Mechanical Restraint Used for Control`=sum(MechanicalRestraintsUsedForControl=="Y"),
            `Any Mechanical Restraint`=sum(MechanicalRestraintsUsedInSecurity=="Y"|MechanicalRestraintsUsedForControl=="Y"|MechanicalRestraintsUsedDuringNonRoutineTransportation=="Y"),
            `Minor rule violations`=sum(PriorityRuleViolationCategory==2),
            `Minor rule violations getting security referral`=sum(PriorityRuleViolationCategory==2&SecurityReferral=="Y"),
            `Major rule violations`=sum(PriorityRuleViolationCategory==1),
            `Major rule violations getting security referral`=sum(PriorityRuleViolationCategory==1&SecurityReferral=="Y"),
            `Major rule violations upheld`=sum(PriorityRuleViolationCategory==1 & L2Upheld=="Y"),
            `All rule violations`=`Major rule violations`+`Minor rule violations`,
            `General violence`=sum(Aggressive),
            `General violence upheld`=sum(Aggressive==1&L2Upheld=="Y"),
            `Assault on youth with injury`=sum(`Assault Causing Bodily Injury to Another Youth`),
            `Assault on youth without injury`=sum(`Assault – Unauth. Physical Contact w/ Youth (No Injury)`),
            `Assault on staff with injury`=sum(`Assault Causing Bodily Injury to Staff`),
            `Assault on staff without injury`=sum(`Assault – Unauth. Physical Contact w/ Staff (No Injury)`),
            `Fighting with injury`=sum(`Fighting that Results in Bodily Injury`),
            `Threatening with a weapon`=sum(`Threatening Another with a Weapon`),
            `All assault with injury and fighting with injury`=sum(`Assault Causing Bodily Injury to Another Youth`==1|
                                                                     `Assault Causing Bodily Injury to Staff`==1|
                                                                     `Fighting that Results in Bodily Injury`==1),
            `All injurious upheld`=sum((`Assault Causing Bodily Injury to Another Youth`==1|
                                          `Assault Causing Bodily Injury to Staff`==1|
                                          `Fighting that Results in Bodily Injury`==1) & 
                                         L2Upheld=="Y")
  ) %>%
  ungroup()

RVTotals<-RVbyFacility %>%
  select(-Facility) %>%
  group_by(Month) %>%
  summarize_all(list(sum)) %>%
  mutate(Facility="Total") %>%
  bind_rows(RVbyFacility)

source("DailyPop.R")

LBBCoachCount<-read_csv("LBBFY13toCY19Formatted.csv") %>%
  mutate(Month=as.Date(Date,format="%m/%d/%Y")) %>%
  select(-Date)

NewCamilleMetricCounts<-RVTotals %>% 
  pivot_longer(cols=`Security referrals`:`All injurious upheld` , names_to="Metric") %>%
  pivot_wider(names_from = Month, values_from = value)

CamilleMetricsAndPopulation<-RVTotals %>%
  inner_join(AverageDailyByMonth) %>%
  mutate(Facility=if_else(str_detect(Facility,"Ron Jackson")==TRUE,"Ron Jackson",Facility)) %>%
  group_by(Facility,Month) %>%
  summarize_all(sum) %>%
  left_join(LBBCoachCount) %>%
  fill(Count,.direction="up") %>%
  fill(Terminations,.direction="up")

ComparisonAssignments<-GetAssignmentsJoinedWithMasterfiles() %>%
  filter(AssignmentStartDate<=as.Date("2017-12-31")&AssignmentEndDate>=as.Date("2017-12-31"),
         FacilityType=="Secure"|FacilityType=="O & A") %>%
  mutate(MonthYear="Dec 31 2017") %>%
  bind_rows(GetAssignmentsJoinedWithMasterfiles() %>%
              filter(AssignmentStartDate<=as.Date("2019-12-31")&AssignmentEndDate>=as.Date("2019-12-31"),
                     FacilityType=="Secure"|FacilityType=="O & A") %>%
              mutate(MonthYear="Dec 31 2019"))

ComparisonAssignments<-ComparisonAssignments %>%
  left_join(GetRiskMLOS()) %>%
  left_join(GetTreatmentNeeds())
         

write_csv(ComparisonAssignments,"ComparisonAssigments.csv")

write_csv(NewCamilleMetricCounts,"NewCamilleMetricCounts.csv")
write_csv(CamilleMetricsAndPopulation,"Metrics and Population for 2017 Comparison.csv")
