library(TJJD)
library(gganimate)
library(zoo)
library(av)

Permanent_Job_History <- CAPPS_Job_History_Get()

JCOs <- Permanent_Job_History %>% 
  filter(str_detect(toupper(Job_Title), "JCO"),
         Facility %in% c("Evins", "Gainesville", "Giddings", "Mart", "Ron Jackson")) %>% 
  group_by(Empl_ID) %>% 
  mutate(First_Start = min(Start_Date)) %>% 
  ungroup()

Date_Table <- data.frame(Date = seq.Date(as.Date("2018-09-01"), today(), "day"))

Employment_by_Day <- sqldf("select * from
                           Date_Table
                           inner join JCOs
                           on Date >= Start_Date and
                           Date <= End_Date") %>% 
  select(Date, Facility, Empl_ID, First_Start) %>% 
  unique()

JCO_Daily_Tenure <- Employment_by_Day %>% 
  mutate(Tenure = as.numeric(Date - First_Start),
         Tenure_Anim = if_else (Tenure >= 1826, 1826, Tenure),
         Category = case_when(Tenure <= 365 ~ "0yr-1yr",
                              Tenure <= 1461 ~ "1yr-4yr",
                              TRUE ~ "5yr+"))

Category_Summary <- JCO_Daily_Tenure %>% 
  count(Facility, Date, Category) %>% 
  rename(JCO_Count = n) %>% 
#  mutate(Category = factor(Category, levels = c("Training", "Training_to_1yr", "1yr_to_3yr", "3yr+"), ordered = TRUE)) %>% 
  group_by(Category) %>% 
  mutate(Rolling = rollmean(JCO_Count, k = 30, fill = NA, align = 'right')) %>% 
  ungroup() %>% 
  group_by(Date, Facility) |> 
  mutate(Rolling_Perc = Rolling/sum(Rolling)) |> 
  ungroup() |> 
  mutate(Category = as.factor(Category),
         MonthYear = format(Date, "%b %Y")) %>% 
  filter(Date >= "2018-10-01",
         Date <= "2024-08-01")

#Static

ggplot(Category_Summary |> 
         filter(Category == "5yr+"), aes(x = Date, y = Rolling_Perc, label = Category, color = Facility)) +
  geom_line() +
  TJJD_Style() +
  labs(title = "JCO Staff by Tenure")

Timepoints<- n_distinct(Category_Summary$Date)

Needed_FPS <- 90

Desired_Length <- Timepoints/Needed_FPS


# 
# p <- ggplot(Category_Summary %>% 
#               filter(!is.na(Rolling)), aes(x = Category, y = Rolling)) +
#   geom_col() +
#   ylim(0, 600) +
#   labs(title = "Date: {frame_time}") +
#   transition_time(Date)
# 
# animate(p,
#         fps = Needed_FPS,
#         duration = Desired_Length)

#Line graph

#Hide legend, add category as label

p <- ggplot(Category_Summary, aes(x = Date, y = Rolling, label = Category, color = Category)) +
  geom_line(linewidth = 1) +
  geom_point(size = 4) +
  geom_text(nudge_y = 35,
            size = 8) +
  TJJD_Style() +
  theme(legend.position="none") +
  labs(title = "JCO Staff by Tenure on {frame_along}") +
  facet_wrap(~Facility, scales = "free") +
  transition_reveal(Date)


anim <- animate(p,
        nframes = Timepoints,
        fps = Needed_FPS,
        duration = Desired_Length,
        renderer = av_renderer())
