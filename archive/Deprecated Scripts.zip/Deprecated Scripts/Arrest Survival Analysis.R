# Survival analysis of arrests because why the heck not
#Rough, very rough

library(TJJD)
library(survival)
library(survminer)
library(broom)

First_Release <- First_Secure_Release_Get()

Arrests <- read_csv("Data Sources\\Youth Arrests Formatted.csv") %>% 
  mutate(Level_and_Degree = factor(Level_and_Degree, c("M*", "MC", "MB", "MA", "F*", "F3", "F2", "F1", "FX"), ordered = TRUE)) %>% 
  filter(Level_and_Degree >= "MB")

Worst_Offense <- Arrests %>% 
  group_by(TJJD_Number, Arrest_Date) %>% 
  summarize(Level = max(Level_and_Degree),
            Violent = max(Violent)) %>% 
  ungroup() %>% 
  mutate(Violent = replace_na(Violent, 0),
         Violent_Felony = str_detect(Level, "F") & Violent == 1,
         Felony = str_detect(Level, "F"),
         Misdemeanor = str_detect(Level, "M"))

Cutoff <- 365

First_Arrest_After_Release <- Worst_Offense %>% 
  left_join(First_Release %>% 
              select(TJJD_Number, Release_Date)) %>% 
  filter(Arrest_Date > Release_Date) %>% 
  group_by(TJJD_Number) %>% 
  summarize_all(first) %>% 
  ungroup() %>% 
  right_join(First_Release) %>% 
  mutate(Days_to_Arrest = as.numeric(Arrest_Date - Release_Date),
         Cutoff_Days = if_else(Days_to_Arrest > Cutoff, Cutoff, Days_to_Arrest),
         Cutoff_Days = replace_na(Cutoff_Days, Cutoff),
         Cutoff_Surv = !is.na(Cutoff_Days),
         Release_FY = State_FY(Release_Date))

Analysis_Data <- First_Arrest_After_Release %>%
  filter(Release_Date >= "2019-09-01",
         Release_Date <= "2021-08-31")

SurvDataFit <- survfit(Surv(Cutoff_Days, Cutoff_Surv) ~ Release_FY, data = Analysis_Data)

ggsurvplot(
  fit = SurvDataFit,
  xlab = "Days After Release",
  ylab = "Arrest Likelihood",
  xlim = c(0, Cutoff),
  ylim = c(min(SurvDataFit$surv), 1)
) +
  labs(title = "Youth Arrested Post-Release")
