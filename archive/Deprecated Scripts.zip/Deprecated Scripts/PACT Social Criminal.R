library(TJJD)

PACT_Risks <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avjuvrepdb;database=NSGCMS_TX_TJJD_JUVENILE",rows_at_time=1),
         "SELECT S.EID as TJJD_Number, Form_Instance_ID, DATE_COMPLETED as Date_Completed, F.NAME as Form, FLL.NAME as Form_Admin_Type, FST.Name as Form_Scoring_Type, Raw_Score, Score, Score_Classification_Text
          FROM   [NSG_FORM_INSTANCE_SCORE] FIS
                 INNER JOIN NSG_FORM_INSTANCE FI
                         ON ( FIS.FORM_INSTANCE_ID_FK = FI.FORM_INSTANCE_ID )
                 INNER JOIN NSG_FORM_SCORING_FORM_SCORE_TARGET FST
                         ON ( FIS.FORM_SCORE_TARGET_ID_FK = FST.FORM_SCORE_TARGET_ID )
                 INNER JOIN NSG_SUBJECT S
                         ON ( S.SUBJECT_ID = FI.SUBJECT_ID_FK )
                 INNER JOIN NSG_USER U
                         ON ( U.USER_ID = FI.COMPLETED_BY_USER_ID_FK )
                 INNER JOIN NSG_FORM F
                         ON ( FI.FORM_ID_FK = F.FORM_ID )
                 LEFT OUTER JOIN NSG_FORM_LABEL_LOOKUP FLL
                              ON ( FI.FORM_LABEL_ID_FK = FLL.FORM_LABEL_ID )
                              WHERE (form_id=121 OR form_id=125)")

Form_Scoring_Matrix <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avnobsql1;database=NSGCMS_TX_TJJD_JUVENILE",rows_at_time=1),
                       "SELECT *
          FROM   NSG_FORM_SCORING_MATRIX")
 
Instance_Score_Sample <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avnobsql1;database=NSGCMS_TX_TJJD_JUVENILE",rows_at_time=1),
                                "SELECT top 100 *
          FROM   NSG_FORM_INSTANCE_SCORE")

PACT_Risks_Wide <- PACT_Risks %>% 
  filter(Form == 'PACT',
         !str_detect(Form_Scoring_Type, "TCM")) %>% 
  select(-Raw_Score) %>% 
  pivot_wider(names_from = Form_Scoring_Type, values_from = c(Score, Score_Classification_Text)) %>% 
  group_by(TJJD_Number) %>% 
  summarize_all(last) %>% 
  ungroup()

write_csv(PACT_Risks_Wide, "PACT Social and Criminal Risk.csv")
