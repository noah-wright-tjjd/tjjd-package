#“library” is a function that loads supporting packages and not especially relevant to rewriting this for SQL
library(tidyverse)
library(lubridate)
library(httr)
library(jsonlite)

Historical_Data <- read_csv("C:\\Users\\Wright-N\\Desktop\\Axon Data.csv")

#These are the elements needed to connect to the API
Secret <- "guvyKwZh+qE0miggHz96ZNaXuPixphGm0+GfIWWfOmU="
Partner_ID <-  "FBD16FB4-2E9D-4724-A8AD-7CF70BBD39BF"
Client_ID <- "B84B24C7-EDAD-4F3A-B89E-F728DF77434F"
api_path <-  "api.evidence.com"

#This is me writing the function R will use to connect to this specific API and issue a token request, “evidence_com_api”. First, it establishes the URL being connected to (along with headers) in the “url” object. Then, it runs the POST function with that URL along with any additional path.
evidence_com_api <- function(path) {
  url <- modify_url(paste0("https://", api_path), path = path)
  body <- list(
    grant_type = "client_credentials",
    partner_id = Partner_ID,
    client_id= Client_ID,
    client_secret = Secret,
    Description = "Read_Again")
  
  POST(
    url,
    body = body,
    encode = "form",
    content_type("application/x-www-form-urlencoded")
  )
}

#Here I’m running the evidence_com_api function requesting an authorization token.
resp <- evidence_com_api(path = "/api/oauth2/token")

#Reformatting the token
json <- content(resp)

#Now that I have the token I’m spelling out the URL for actually acquiring the data. “str_c” is a simple concatenation function, it just combines strings together. The “GET_URL” object I’m ultimately creating has two parameters, a start date and end date that determine the range of records I’m querying. I always set both start and end to the same date due to restrictions on query sizes.
GET_URL <- str_c("https://api.evidence.com/api/v1/agencies/FBD16FB4-2E9D-4724-A8AD-7CF70BBD39BF/reports/data?reportType=EvidenceCreated&fromDate=", today()-1, "&toDate=", today()-1, "&pageSize=50&pageOffset=")

#This is the tricky part. The API only allows you to GET 1 page of records at a time. The problem is that a single day of TJJD bodycam logs can have up to 50 pages of records. The function below pulls one page at a time (from 0 to 49) and then binds all the rows of each individual result together to create one big table for a given date. This might be easier to show than to explain in writing.
Created <- map_df(c(0:99), function(x) {
  Increment <- GET(str_c(GET_URL, x),
                   add_headers(Authorization = paste0("Bearer ", json$access_token)))
  
  Query_Results <- rawToChar(Increment$content) %>%
    fromJSON %>% 
    data.frame()
  
  colnames(Query_Results) <- str_remove_all(colnames(Query_Results), "data.")
  
  return(Query_Results)
}
)
  
  #Finally, I’m reformatting the data I just queried for ease of use. This part I can do in SQL, it’s just variations on select statements and a few simple transformations.
Bodycam_Format <- Created %>%
    mutate(across(contains("date"),~ymd_hms(str_replace(str_sub(.x,1,-11),"T"," "))),
           Employee_ID = as.numeric(ownerBadgeId),
           Owner_First = ownerFirstName,
           Owner_Last = ownerLastName,
           Owner = str_c(ownerFirstName, " ", ownerLastName),
           Clip_Start = dateRecordStart,
           Clip_End = dateRecordEnd,
           Date_Clip_Start = as.Date(dateRecordStart),
           Date_Clip_End = as.Date(dateRecordEnd),
           Seconds_Duration = as.numeric(durationSeconds),
           Hours_Duration = as.numeric(durationSeconds)/3600) %>%
    select(Evidence_ID = evidenceId,
           Employee_ID,
           Owner_First,
           Owner_Last,
           Owner,
           Serial_Number = serialNumber,
           Clip_Start,
           Clip_End,
           Date_Clip_Start,
           Date_Clip_End,
           Seconds_Duration,
           Hours_Duration) %>%
    mutate(Clip_End = if_else(is.na(Clip_End), Clip_Start + Seconds_Duration, Clip_End),
           Date_Clip_End = as.Date(Clip_End))

Historical_Update <- bind_rows(Historical_Data,
                               Bodycam_Format) %>% 
  unique() %>% 
  arrange(Clip_Start)

write_csv(Historical_Update, "C:\\Users\\Wright-N\\Desktop\\Axon Data.csv")