#Population Recreation Attempt

library(TJJD)

Daily_Pop<- Daily_Pop_Get()

Assignments <- Assignments_Get()

Services <- Services_Get()

Statuses <- Statuses_Get()

Date_Table <- data.frame(Date = seq.Date(today()-730, today(), "day"))

Assignments_by_Day <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=IRD035",rows_at_time=1),
                               "SELECT Date, TYCNO as TJJD_Number, ASPTR as Assignment_Pointer_Number, LOC as Location_Code
              FROM POPASFIXED
              left join DateCalendar on ASMDY<=SASDate and EASMDY>SASDate
              WHERE Date>='2018-01-01' and Date<GETDATE()") %>%
  mutate(Date=as.Date(Date)) %>% 
  left_join(Location_Type_Lookup)


#Exclude Overnights and Deportations: S6L, S6M, S6O, S5B

Services_No_Count <- Services %>% 
  filter(Service_Code %in% c('S6L', 'S6M', 'S6O', 'S5B'))

Services_No_Count_Daily <- sqldf("select Date, TJJD_Number, Service_Youth_Location as Location_Code, Service_Name
                                 from Date_Table
                                 left join Services_No_Count
                                 on Service_Start_Date <= Date and
                                 Service_End_Date >= Date")

Services_No_Count_Wide <- Services_No_Count_Daily %>% 
  count(Date, Location_Code, Service_Name) %>% 
  pivot_wider(names_from = Service_Name, values_from = n, values_fill = 0)

#Exclude all but RSU from facility and HWH
#Exclude all but Detention and Jail from parole

Statuses_No_Count <- Statuses %>% 
  filter(!(Status_Type == "SEC" & Facility_Type %in% c("Secure", "Halfway House", "Contract Care", "O & A")),
         !(Status_Type %in% c("DET", "JAIL") & Facility_Type == "Parole")
  )

Statuses_No_Count_Daily <- sqldf("select Date, TJJD_Number, Status_Location as Location_Code, Status_Type
                                 from Date_Table
                                 left join Statuses_No_Count
                                 on Status_Start_Date <= Date and
                                 Status_End_Date >= Date")

Statuses_No_Count_Wide <- Statuses_No_Count_Daily %>% 
  count(Date, Location_Code, Status_Type) %>% 
  pivot_wider(names_from = Status_Type, values_from = n, values_fill = 0)

Pop_Recreation <- Assignments_by_Day %>% 
  anti_join(Statuses_No_Count_Daily) %>% 
  anti_join(Services_No_Count_Daily) %>% 
  group_by(Date, Location_Code) %>% 
  summarize(Calculated_Population = n()) %>% 
  ungroup()

Check <- Daily_Pop %>% 
  inner_join(Pop_Recreation) %>% 
  left_join(Statuses_No_Count_Wide) %>% 
  left_join(Services_No_Count_Wide) %>% 
  mutate(Mismatch = Calculated_Population - Total_Population) %>% 
  select(Date, Assignment_Location, Total_Assignments, SAS_Population = Total_Population, Calculated_Population:Mismatch)
