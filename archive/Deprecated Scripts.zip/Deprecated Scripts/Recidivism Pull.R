Recidivism_Pull <- function(Start_Date = "2018-09-01", End_Date = "2022-08-31") {

Masterfiles_All <- Masterfiles_Get(Timeframe = "Historical")

Masterfiles_Cohort <- Masterfiles_All %>% 
  filter(Discharge_Date >= Start_Date,
         Discharge_Date <= End_Date)

Youth <- Masterfiles_Cohort %>% 
  select(TJJD_Number) %>% 
  unique()

Assignments_All <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=IRD035",rows_at_time=1),
                            "SELECT TYCNO, ASPTR, PRLSTAT, ERDMDY, LOC, ASMDY, EASMDY, PRELOC, MVNTCODE, MVNTTYPE, TEMPFLAG FROM POPASFixed") %>%
  left_join(Location_Type_Lookup,by = c("LOC" = "Location_Code")) %>%
  left_join(Location_Type_Lookup, by = c("PRELOC" = "Location_Code")) %>% 
  mutate(Earliest_Release_Date=as.Date(ERDMDY,origin="1960-01-01"),
         Assignment_Start_Date=as.Date(ASMDY,origin="1960-01-01"),
         Assignment_End_Date=as.Date(EASMDY,origin="1960-01-01"),
         Assignment_Duration=if_else(Assignment_End_Date==as.Date("2099-12-31"),
                                     -1,
                                     as.numeric(Assignment_End_Date-Assignment_Start_Date))) %>%
  select(TJJD_Number=TYCNO,
         Assignment_Pointer_Number=ASPTR,
         Assignment_Start_Date,
         Assignment_End_Date,
         Assignment_Duration,
         Earliest_Release_Date,
         Parole_Status=PRLSTAT,
         Assignment_Location = Assignment_Location.x,
         Facility = Facility.x,
         Security_Level = Security_Level.x,
         Facility_Type = Facility_Type.x,
         Previous_Assignment = Assignment_Location.y,
         Previous_Security_Level = Security_Level.y,
         Previous_Facility_Type = Facility_Type.y,
         Movement_Type=MVNTTYPE,
         Movement_Code=MVNTCODE,
         Temporary = TEMPFLAG) %>%
  left_join(Movement_Code_Lookup)

Assignments_Cohort <- Assignments_All %>% 
  semi_join(Youth)

# CCS_Offense_Categories <- read_excel("Reference/CCS Offense Categories.xlsx") %>% 
#   select(OFFCODE:Category)

Demos <- ID_Get() %>%
  select(TJJD_Number, First_Name, Last_Name, Sex, Race, DOB)


#Analysis --------------------

# Define Releases:
# Program Completion
# Transition Movements Before Initial or Revocation Minimum Length of Stay.
# Transition Movements after Completion of Initial or Revocation Minimum Length of Stay
# Conditional Placement before minimum length of stay
# Conditional Placement after minimum length of stay
# Pop management or exec release
# RRP Release

First_Release_From_TJJD_Secure <- Assignments_Cohort %>% 
  group_by(TJJD_Number) %>% 
  mutate(Initial_MLOS = first(Earliest_Release_Date)) %>% 
  ungroup() %>% 
  filter(is.na(Temporary) | Temporary == "N") %>% 
  left_join(Assignments_Cohort %>% 
              mutate(Assignment_Pointer_Number = Assignment_Pointer_Number + 1) %>% 
              select(TJJD_Number, Assignment_Pointer_Number, Prior_MLOS = Earliest_Release_Date, Prior_Movement_Type = Movement_Type, Prior_Movement_Code = Movement_Code, Prior_Movement_Description = Movement_Description, Prior_Temporary = Temporary)) %>% 
  filter(Previous_Security_Level %in% c("Secure", "O & A"),
         !Security_Level %in% c("Secure", "O & A")) %>% 
  mutate(Release_Date = Assignment_Start_Date,
         Release_FY = State_FY(Release_Date),
         Prior_Movement_Code = case_when(
           Previous_Facility_Type == "Contract Care" ~ "Secure Contract",
           Prior_Movement_Code %in% c("SCOP", "RPR") ~ Prior_Movement_Code,
           Prior_Movement_Code == "IP" & Assignment_Pointer_Number <= 3 ~ "Initial",
           Parole_Status == "N" ~ "Other_Inst",
           TRUE ~ "Other_Parole"),
         Release_Before_Initial_MLOS = Release_Date < Initial_MLOS,
         Release_Before_Extended_MLOS = Release_Date < Prior_MLOS) %>% 
  group_by(TJJD_Number) %>% 
  summarize_all(first) %>% 
  ungroup()

First_Discharge <- Masterfiles_Cohort %>% 
  filter(Commitment_Type != "RVKD") %>% 
  mutate(Release_Date = Discharge_Date,
         Release_Type = "Discharge") %>% 
  filter(!Discharge_Reason_Code %in% c("STAD", "JAIL", "TTDC", "DIED", "JACT", NA)) %>% 
  select(TJJD_Number, Release_Date, Release_Type) %>% 
  group_by(TJJD_Number) %>% 
  summarize_all(first) %>% 
  ungroup()

Release_Cohort <- First_Release_From_TJJD_Secure %>% 
  select(TJJD_Number, Release_Date = Assignment_Start_Date, Release_Type = Prior_Movement_Code, Prior_Movement_Description) %>% 
  bind_rows(First_Discharge) %>% 
  semi_join(Names %>% 
              filter(!tolower(First_Name) %in% c("commitment", "vacated", "invalid", "overturned", "reversed"),
                     !tolower(Last_Name) %in% c("commitment", "vacated", "invalid", "overturned", "reversed"))
  ) %>% 
  group_by(TJJD_Number) %>% 
  arrange(Release_Date) %>% 
  summarize_all(first) %>% 
  mutate(Release_FY = State_FY(Release_Date),
         Release_Type = if_else(TJJD_Number == 1261370, "Secure Contract", Release_Type)) %>% 
  filter(Release_Date >= Start_Date,
         Release_Date <= End_Date)

First_Release <- First_Secure_Release_Get()

Arrests <- read_csv("Data Sources\\Youth Arrests Formatted.csv") %>% 
  mutate(Level_and_Degree = factor(Level_and_Degree, c("M*", "MC", "MB", "MA", "F*", "F3", "F2", "F1", "FX"), ordered = TRUE)) %>% 
  filter(Level_and_Degree >= "MB")

Arrest_vs_Release <- Arrests %>% 
  inner_join(First_Release) %>% 
  mutate(Release_to_Arrest = Arrest_Date - Release_Date) %>% 
  filter(Release_to_Arrest >= 0,
         Release_to_Arrest <= years(3))

First_Arrest_After_Release <- Arrest_vs_Release %>% 
  group_by(TJJD_Number) %>% 
  summarize_all(first) %>% 
  ungroup()

Arrest_Format <- Arrest_vs_Release %>%
  mutate(`1-Year` = Release_to_Arrest < days(365),
         `2-Year` = Release_to_Arrest < years(2),
         `3-Year` = Release_to_Arrest < years(3)) %>%
  pivot_longer(`1-Year`:`3-Year`, names_to = "Years_from_Release", values_to = "Present") %>%
  filter(Present) %>%
  group_by(TJJD_Number, Years_from_Release) %>%
  summarize(Worst_Level = max(Level_and_Degree),
            Violent = max(Violent)) %>%
  ungroup() %>%
  mutate(Any_Arrest = !is.na(Worst_Level),
         Felony_Arrest = str_detect(Worst_Level, "F"),
         Violent_Felony_Arrest = str_detect(Worst_Level, "F") & Violent)

Release_Format <- Release_Cohort %>%
  mutate(Time_from_Release = as.Date("2023-08-31") - Release_Date,
         `1-Year` = Time_from_Release >= days(365),
         `2-Year` = Time_from_Release >= years(2),
         `3-Year` = Time_from_Release >= years(3)) %>%
  pivot_longer(`1-Year`:`3-Year`, names_to = "Years_from_Release", values_to = "Present") %>%
  filter(Present) %>%
  select(TJJD_Number, Release_Date, Time_from_Release, Years_from_Release)

Recidivism_by_Youth <- Demos %>% 
  inner_join(Release_Format) %>%
  left_join(Arrest_Format) %>%
  mutate(across(contains("Arrest"), ~replace_na(.x, 0)))

return(Recidivism_by_Youth)
}
