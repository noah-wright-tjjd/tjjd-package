#TJJD Population Statistics as of 12/31/2019

library(TJJD)

Assignments<-GetAssignments() %>%
  filter(AssignmentEndDate>=as.Date("2019-12-31"),
         AssignmentStartDate<=as.Date("2019-12-31"),
         FacilityType=="Secure"|FacilityType=="O & A")

GlennFixMasterfiles<-read_sas("r:\\ZPSAS\\newpopmfinal.sas7bdat")

POPMEarliestReleaseDateInfo<-GlennFixMasterfiles %>%
  mutate(TJJDNumber=as.integer(TYCNO)) %>%
  select(TJJDNumber,
         CommitmentStartDate=STMDY,
         MasterfileEarliestReleaseDate=ERDMDY)

HomeStatus<-sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=IRD035",rows_at_time=1),
                     "SELECT TYCNO, HOMEDEC, HOMEYYMM
                     FROM ID") %>%
  select(TJJDNumber=TYCNO,
         HomeDecision=HOMEDEC,
         HomeDecisionDate=HOMEYYMM)

ID<-GetID() %>%
  inner_join(HomeStatus)


TreatmentNeeds<-GetTreatmentNeeds()

MostRecentTreatmentNeeds<-TreatmentNeeds %>%
  group_by(TJJDNumber) %>%
  summarize(Form060UID=max(Form060UID)) %>%
  inner_join(TreatmentNeeds)

IncidentRVs<-GetIncidentRuleViolations()

Incidents<-GetIncidents()

IncidentsPast60Days<-Incidents %>%
  filter(IncidentDate>=as.Date("2019-09-01"),
         IncidentDate<=as.Date("2019-11-30"))

AllIncidentsBySeverity<-Incidents %>%
  group_by(TJJDNumber,PriorityRuleViolationCategory) %>%
  summarize(Count=n()) %>%
  pivot_wider(values_from = Count, names_from = PriorityRuleViolationCategory) %>%
  select(TJJDNumber,MajorAllTime=`1`,MinorAllTime=`2`)

AllIncidentsBySeverity60Days<-IncidentsPast60Days %>%
  group_by(TJJDNumber,PriorityRuleViolationCategory) %>%
  summarize(Count=n()) %>%
  pivot_wider(values_from = Count, names_from = PriorityRuleViolationCategory) %>%
  select(TJJDNumber,MajorPast60=`1`,MinorPast60=`2`)

AggresiveRVs<-IncidentRVs %>%
  filter(str_detect(Description,c("Assault|Fighting|with a Weapon"))==TRUE)

AggresiveIncidents<-select(AggresiveRVs,TJJDNumber,IncidentPointerNumber) %>%
  inner_join(Incidents) %>%
  group_by(TJJDNumber) %>%
  summarize(AggresiveAllTime=n())

AggresiveIncidentsPast60<-select(AggresiveRVs,TJJDNumber,IncidentPointerNumber) %>%
  inner_join(IncidentsPast60Days) %>%
  group_by(TJJDNumber) %>%
  summarize(AggresivePast60=n())

MasturbationAndExposureRVs<-IncidentRVs %>%
  filter(str_detect(Description,c("Masturbation|Exposing"))==TRUE)

MasturbationAndExposurePast60<-select(MasturbationAndExposureRVs,TJJDNumber,IncidentPointerNumber) %>%
  inner_join(IncidentsPast60Days) %>%
  group_by(TJJDNumber) %>%
  summarize(MasturbationExposurePast60=n())

PACTRisk<-GetPACTRisk()

MostRecentPACTRisk<-PACTRisk %>%
  group_by(TJJDNumber) %>%
  summarize(FormPACTUID=max(FormPACTUID)) %>%
  inner_join(PACTRisk)

Dataset<-Assignments %>% 
  left_join(MostRecentTreatmentNeeds) %>% 
  inner_join(ID) %>% 
  left_join(AllIncidentsBySeverity) %>%
  left_join(AllIncidentsBySeverity60Days) %>%
  left_join(AggresiveIncidents) %>%
  left_join(AggresiveIncidentsPast60) %>%
  left_join(MasturbationAndExposurePast60) %>%
  left_join(MostRecentPACTRisk)

write_csv(Dataset,"Dataset 12-31-2019.csv")
