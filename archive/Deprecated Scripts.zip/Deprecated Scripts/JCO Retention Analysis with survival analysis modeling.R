library(TJJD)
library(survival)
library(survminer)
library(broom)

#Evins starting being more selective in staffing in August, has that affected new-hire turnover?

# CEI<-sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=TYCEmployees",rows_at_time=1),
#               "SELECT emplID, hiredate, rehiredate
#            FROM CAPPS_CEI_Empl") %>%
#   mutate(Hire_Date=as.Date(hiredate,format="%m/%d/%Y"),
#          Rehire_Date=as.Date(rehiredate,format="%m/%d/%Y")) %>%
#   select(TINSID=emplID,
#          Hire_Date,
#          Rehire_Date) %>%
#   filter(Hire_Date!=Rehire_Date)
# 
# PG2 <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=TYCEmployees",rows_at_time=1),
#                 "SELECT TINSID, FullName, Email, LastHireDate, TerminationDate, BirthDate, EthnicCode, Gender, SeniorityDate, JobCodeDescription, PositionCodeDescription, CCSLocCode, Location, SupervisorFullname
#                                           FROM TYC_PG2_JOB_CURR")
# 
# Combined <- PG2 %>%
#   left_join(CEI) %>%
#   mutate(Initial_Hire_Date = as.Date(LastHireDate),
#          Termination_Date=as.Date(TerminationDate),
#          State_Seniority_Date=as.Date(SeniorityDate),
#          Birth_Date=as.Date(BirthDate),
#          CCS_Loc_Code=str_replace(CCSLocCode,"MCA","MCL"),
#          CCS_Loc_Code=str_replace(CCS_Loc_Code,"HNU","HKH"),
#          CCS_Loc_Code=if_else(str_detect(PositionCodeDescription,"JCO")==TRUE &
#                                 str_detect(tolower(PositionCodeDescription),"trans")==TRUE,"TRA",CCS_Loc_Code),
#          CCS_Loc_Code=if_else(str_detect(PositionCodeDescription,"JCO")==TRUE,str_replace(CCS_Loc_Code,"BOA","BWD"),CCS_Loc_Code)) %>%
#   select(Employee_ID=TINSID,
#          Name=FullName,
#          Email,
#          Birth_Date = BirthDate,
#          Gender,
#          Ethnicity = EthnicCode,
#          Job_Code_Description = JobCodeDescription,
#          Position_Code_Description = PositionCodeDescription,
#          State_Seniority_Date,
#          Initial_Hire_Date,
#          Rehire_Date,
#          Termination_Date = TerminationDate,
#          Location_Code = CCS_Loc_Code,
#          HR_Location = Location,
#          Supervisor = SupervisorFullname) %>%
#   left_join(Location_Type_Lookup, "Location_Code")
# 
# JCO_Survival <- function(Analysis_Start, Analysis_End) {
#   Start_Date <- as.Date(Analysis_Start)
#   End_Date <- as.Date(Analysis_End)
#   
#   JCOes_Survival <- Combined  %>%
#     mutate(Last_Hire_Date = if_else(is.na(Rehire_Date), Initial_Hire_Date, Rehire_Date),
#            Employment_Days = if_else(is.na(Termination_Date), as.numeric(Analysis_End - Last_Hire_Date), as.numeric(as.Date(Termination_Date) - Last_Hire_Date)),
#            Terminated = if_else(is.na(Termination_Date), 0, 1)) %>%
#     filter(str_detect(Job_Code_Description, "JCO"),
#            Initial_Hire_Date >= Start_Date)
# }

Month_Lookup <- data.frame(Month_Number = as.character(1:12),
                           Month = month.abb)

BLS_Texas <- read_excel("Data Sources/BLS Contextual Data.xlsx")

BLS_Reformat <- BLS_Texas %>%
  pivot_longer(2:56,
               names_to = "Month_Year",
               values_to = "Metric") %>%
  mutate(Year = as.character(str_sub(Month_Year, -4, -1)),
         Month = str_sub(Month_Year, 1, 3),
         Day = as.character(1)) %>%
  left_join(Month_Lookup) %>%
  mutate(Month = as.Date(str_c(Year, Month_Number, Day, sep = "-"))) %>%
  select(`Series ID`, Month, Metric) %>%
  pivot_wider(names_from = `Series ID`, values_from = Metric)

Employment_History <- CAPPS_Job_History_Get()
Employment_by_Month <- CAPPS_Job_History_Monthly()

# Employee_Summary <- Employee_Summary_Get()
# 
# #Min 10 years
# #Rule of 80: Service credit + age >= 80
# 
# Retirement_Proximity <- Employee_Summary %>% 
#   filter(is.na(Termination_Date),
#          !str_detect(Division, "Inspector|Ombuds")) %>% 
#   mutate(Age = floor(as.numeric(today() - as.Date(Birth_Date))/365.25),
#          State_Tenure = as.numeric(today() - State_Seniority_Date)/365.25,
#          Rule_of_80 = State_Tenure + Age,
#          Eligible = if_else(State_Tenure >= 10 & Rule_of_80 >= 80,
#            "Y", "N"),
#          Eligible_in_One_Year = Rule_of_80 > 78 & Rule_of_80 < 80)
# 
# JCO_Retirement_Summary <- count(Retirement_Proximity %>% 
#                                   filter(str_detect(Job_Code_Description, "JCO")), 
#                                 Eligible) %>% 
#   mutate(Percent = n/sum(n))
# 
# Location_Retirement_Summary <- count(Retirement_Proximity, HR_Location, Eligible) %>% 
#   group_by(HR_Location) %>% 
#   mutate(Percent = n/sum(n))

JCO_Summary_Data <- Employment_by_Month %>% 
  filter(str_detect(Job_Title, "JCO"),
         Facility %in% c("Evins", "Gainesville", "Giddings", "Mart", "Ron Jackson")) %>% 
  group_by(Month) %>% 
  summarize(Bodies = n_distinct(Empl_ID),
            Hires = sum(Hire),
            Terms = sum(Term),
            Net = Hires - Terms)

JCO_Survival <- function(Analysis_Start, Analysis_End, Survival_Days) {
  
  JCO_Employment_Spells <- Employment_History %>% 
    filter(str_detect(Job_Title, "JCO")) %>% 
    group_by(Empl_ID, Facility) %>% 
    mutate(UID = row_number(), 
           Spell_Start = (UID == 1) | Hire == 1) %>%
    group_by(Empl_ID, Facility, Spell_Start) %>%
    mutate(Spell_Number = if_else(Spell_Start, row_number(), NA_integer_)) %>% 
    ungroup() %>% 
    fill(Spell_Number) %>% 
    group_by(Empl_ID, Facility, Spell_Number) %>% 
    summarize(Name = last(Name),
              Hire = max(Hire),
              Term = max(Term),
              Start_Date = min(Start_Date),
              End_Date = max(End_Date),
              Job_Title = last(Job_Title),
              Spell_Duration = as.numeric(End_Date - Start_Date)) %>% 
    ungroup()
  
  Analysis_Start <- as.Date(Analysis_Start)
  Analysis_End <- as.Date(Analysis_End)
  
  JCOes_Survival <- JCO_Employment_Spells %>%
    filter(Start_Date >= Analysis_Start) %>% 
    separate(Job_Title, c("Job_Class", "Additional_Title"), sep = "-") %>%
    mutate(Job_Class = str_trim(Job_Class),
           Additional_Title = str_trim(Additional_Title),
           End_Date = if_else(End_Date > Analysis_End, Analysis_End, End_Date),
           Term = if_else(End_Date > Analysis_End, 0, Term),
           Spell_Duration = if_else(Term == 0, as.numeric(Analysis_End - Start_Date), Spell_Duration),
           Start_Year = year(Start_Date),
           Start_Month = floor_date(Start_Date, 'month'),
           Started_First_Week_of_Month = day(Start_Date) <= 7,
           Fiscal_Start_Year = State_FY(Start_Date),
           Fiscal_Start_Quarter = State_FQ(Start_Date),
           Fiscal_Start_Year_Split = if_else(Fiscal_Start_Year == 2022, if_else(Start_Month < "2022-04-01", "2022 before raise", "2022 post raise"),
                                                as.character(Fiscal_Start_Year)),
           Cutoff_Days = if_else(Spell_Duration > Survival_Days, Survival_Days, Spell_Duration),
           Cutoff_Term = if_else(Spell_Duration > Survival_Days, 0, Term),
           Evins_Hire_Changes = Start_Date >= "2022-01-01" & Facility == "Evins",
           TX_Model = Start_Date >= "2019-09-01",
           Covid = Start_Date >= "2020-04-01",
           Great_Res = Start_Date >= "2021-04-01",
           Bonus_15_Temporary = Start_Date >= "2022-03-01" & Start_Date < "2022-07-01",
           Bonus_15_Permanent = Start_Date >= "2022-07-01",
           Bonus_10_RJ = Start_Date >= "2022-07-01" & Start_Date <= "2022-10-01" & Facility == "Ron Jackson",
           Buddies = case_when(Facility == "Evins" & Start_Date >= "2022-05-01" ~ 1,
                               Facility == "Mart" & Start_Date >= "2022-06-01" ~ 1,
                               Facility == "Giddings" & Start_Date >= "2022-06-01" & Start_Date <= "2023-01-31" ~ 1,
                               Start_Date >= "2022-07-01" ~ 1,
                               TRUE ~ 0),
           Revised_Buddies = if_else(Facility == "Giddings" & Start_Date >= "2023-02-01", 1, 0), 
           Period = case_when(Start_Date >= "2022-07-01" ~ "4. Buddy_Raises",
                              Start_Date >= "2022-04-01" ~ "3. Transitional",
                              Start_Date >= "2021-03-01" ~ "2. Great_Resignation",
                              Start_Date >= "2020-03-01" ~ "1. COVID_Year1",
                              TRUE ~ "0. Pre_Covid"),
           Survival_Days = Survival_Days) %>% 
    group_by(Facility, Start_Date) %>% 
    mutate(Training_Cohort = n()) %>% 
    ungroup()
}

JCO_Data <- map_df(c(7, 30, 90, 180, 365), ~JCO_Survival("2018-09-01", today(), .x)) %>% 
  filter(!is.na(End_Date))

Timeframe_Turnover_by_Month <- JCO_Data %>% 
  filter(Facility %in% c("Evins", "Gainesville", "Giddings", "Mart", "Ron Jackson"),
         Start_Date <= floor_date(today(), "month") - 1 - Survival_Days) %>% 
  group_by(Fiscal_Start_Year, Fiscal_Start_Quarter, Start_Month, Survival_Days) %>% 
  summarize(Hires = sum(Hire),
            Turnover = sum(Cutoff_Term)/Hires) 
 #%>% 
#  select(-Hires) %>% 
 # pivot_wider(names_from = Survival_Days, values_from = Turnover)

Timeframe_Turnover_by_FQ <- JCO_Data %>% 
  group_by(Fiscal_Start_Year, Fiscal_Start_Quarter, Survival_Days) %>% 
  filter(Facility %in% c("Evins", "Gainesville", "Giddings", "Mart", "Ron Jackson"),
         max(Start_Date) <= floor_date(today(), "month") - 1 - Survival_Days) %>% 
  summarize(Hires = sum(Hire),
            Turnover = sum(Cutoff_Term)/Hires) %>% 
  select(-Hires) %>% 
#  pivot_wider(names_from = Survival_Days, values_from = Turnover) %>% 
  mutate(Timeframe = str_c("FY", Fiscal_Start_Year, " - FQ", Fiscal_Start_Quarter))

Timeframe_Turnover_by_CQ <- JCO_Data %>% 
  group_by(CY = year(Start_Month), CQ = quarter(Start_Month), Survival_Days) %>% 
  filter(Facility %in% c("Evins", "Gainesville", "Giddings", "Mart", "Ron Jackson"),
         max(Start_Date) <= today() - Survival_Days) %>% 
  summarize(Hires = sum(Hire),
            Turnover = sum(Cutoff_Term)/Hires) %>% 
#  select(-Hires) %>%
#  pivot_wider(names_from = Survival_Days, values_from = Turnover) %>% 
  mutate(Timeframe = str_c(CY, " - Q", CQ))

Timeframe_Turnover_by_Period <- JCO_Data %>% 
  filter(Facility %in% c("Evins", "Gainesville", "Giddings", "Mart", "Ron Jackson"),
         Start_Month <= floor_date(today(), "month") -1 - Survival_Days) %>% 
  group_by(Period, Survival_Days) %>% 
  summarize(Hires = sum(Hire),
            Turnover = sum(Cutoff_Term)/Hires) %>% 
  #  select(-Hires) %>% 
    pivot_wider(names_from = Survival_Days, values_from = Turnover)

Timeframe_Turnover_by_Month %>% 
  filter(Start_Month >= "2020-07-01",
         Survival_Days %in% c(7, 30, 60)) %>% 
  ggplot(aes(x = Start_Month, y = Turnover, group = as.character(Survival_Days), color = as.character(Survival_Days))) +
  geom_line()

Timeframe_Turnover_by_FQ %>% 
  ggplot(aes(x = Timeframe, y = Turnover, group = as.character(Survival_Days), color = as.character(Survival_Days))) +
  geom_line()

#Kaplan-Meier Curve

Cutoff <- 90

Analysis_Data <- JCO_Data %>%
  filter(Facility %in% c("Ron Jackson", "Gainesville", "Giddings", "Mart", "Evins"),
         Survival_Days == Cutoff) %>% 
  mutate(Fiscal = str_c("FY", Fiscal_Start_Year, " - FQ", Fiscal_Start_Quarter))

SurvDataFit <- survfit(Surv(Cutoff_Days, Cutoff_Term) ~ Fiscal, data = Analysis_Data)

ggsurvplot(
  fit = SurvDataFit,
  xlab = "Days After Hire",
  ylab = "Retention Probability",
  xlim = c(0, Cutoff),
  ylim = c(min(SurvDataFit$surv), 1)
  ) +
  labs(title = "JCO Retention by Period of Hire")

#Cox Proportional Hazards, impact of buddy system and FY

Cox_Data <- Analysis_Data %>%
  left_join(BLS_Reformat, by = c("Start_Month" = "Month"))

#Recent Data 

coxph(Surv(Cutoff_Days, Cutoff_Term) ~
        TX_Model +
        Great_Res +
        Bonus_15_Temporary +
        Bonus_15_Permanent +
        Bonus_10_RJ +
        Started_First_Week_of_Month +
        Training_Cohort
      ,
      data = Cox_Data %>% 
        filter(Start_Date >= "2022-09-01",
               Facility == "Mart")) %>%
  tidy(exp = TRUE)

#Longer Term

# coxph(Surv(Cutoff_Days, Cutoff_Term) ~ 
#         TX_Model + 
#         Opening_Rate + 
#         Hire_Rate + 
#         Quit_Rate + 
#         Bonus_15_Temporary + 
#         Bonus_15_Permanent +
#         Facility +
#         Started_First_Week_of_Month,
#       data = Cox_Data) %>% 
#         tidy(exp = TRUE)

