library(TJJD)
Lookup<-LocationTypeLookup

Dailypop<-DailyPopGet()

EmployeeSummaryGet

ServiceTable<-RawGet(services,sql)

Services.Raw.SQL<-ServiceTable %>%
  filter(ENDMDY>19723)

Services.SQL<-sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=IRD035",rows_at_time=1),
         "SELECT * FROM POPSS
                                   WHERE ENDMDY>19723") %>%
  left_join(ServiceCodeLookup,c("TYPESERV"="Service Code")) %>%
  left_join(ServiceCompletionCodeLookup,by=c("REASON"="ReasonCode")) %>%
  mutate(ServiceStartDate=as.Date(STMDY,origin="1960-01-01"),
         ServiceEndDate=as.Date(ENDMDY,origin="1960-01-01")) %>%
  select(TJJDNumber=TYCNO,
         ServiceYouthLocation=LOC,
         ServiceDeliveredLocation=SSLOC,
         ServiceCode=TYPESERV,
         ServiceName=Service,
         ServiceDescription=`Service Description`,
         ServiceCategory=Category,
         ServiceCategoryDescription=`Category Description`,
         ServiceStartDate,
         ServiceEndDate,
         ServiceLeavingCode=REASON,
         ServiceLeavingReason=Reason,
         ServiceLeavingNotes=EXPLAIN)

Service.SQL.Problem<-Services.SQL %>%
  filter(str_detect(ServiceCode,"NFR|SRF|SRI|SRS")==TRUE)

CCSCodes<-sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=IRD035",rows_at_time=1),
                   "SELECT * FROM SSCODE")

CCSCodes.Fix<-CCSCodes %>%
  mutate(CCSActiveSince=ymd(str_pad(ACTIVYMD,6,"left","0")),
         InactiveSinceFix=if_else(INACTYMD==999999,300101,as.numeric(INACTYMD)),
         CCSInactiveSince=ymd(str_pad(InactiveSinceFix,6,"left","0"))) %>%
  select(ServiceCode=TYPESERV,
         Active=ACTIVE,
         CCSServiceName=SERVNAME,
         CCSActiveSince,
         CCSInactiveSince)

Codes<-Services.SQL %>%
  group_by(ServiceCode) %>%
  summarize(Appearances=n(),
            FirstPOPSSAppearance=min(ServiceEndDate),
            LastPOPSSAppearance=max(ServiceEndDate)) %>%
  full_join(CCSCodes.Fix)

str(CCSCodes.Fix)
str(Services.SQL)


write_csv(Codes,"Service Codes.csv")

#Summary Stats

Services<-ServicesGet()

mode <- function(codes){
  which.max(tabulate(codes))
}

Services.Summary<-Services %>%
  filter(ServiceEndDate!=as.Date("2099-12-31")) %>%
  mutate(ServiceDuration=as.numeric(ServiceEndDate-ServiceStartDate)) %>%
  group_by(ServiceCode,
           ServiceName,
           ServiceDescription) %>%
  summarize(MeanDuration=mean(ServiceDuration),
            SDDuration=sd(ServiceDuration),
            ModeDuration=mode(ServiceDuration))

write_csv(Services.Summary,"Services Since 2014, Duration Summaries.csv")

