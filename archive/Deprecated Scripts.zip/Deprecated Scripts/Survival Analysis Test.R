library(TJJD)
library(survival)
library(survminer)

SurvData<-read_csv("Survival Data.csv")


SurvDataTime<-SurvData %>%
  mutate(Time=(as.Date(`Tenure Date`)-as.Date(`Start Date`)),
         Status=if_else(Status=="Active",0,1))

SurvDataTime.Facilities<-SurvDataTime %>%
  filter(FacilityType=="Secure")

SurvDataFit<-survfit(Surv(Time, Status) ~ FacilityType, data = SurvDataTime)

ggsurvplot(
  fit = SurvDataFit,
  xlab = "Days", 
  ylab = "Termination Probability")

