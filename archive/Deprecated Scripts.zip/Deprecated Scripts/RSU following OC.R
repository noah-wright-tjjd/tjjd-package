library(TJJD)

source("R/DB/Warehouse.R")

PopSheet <- sqlQuery(Warehouse, "select * from Connect.PopulationSheet_Current")

Incidents <- Incidents_Get()

OC <- Incidents %>% 
  filter(Use_Of_Chemical_Agent == 1,
         Incident_Date >= (today() - 90)) %>% 
  mutate(Incident_Time = str_c(str_sub(Incident_Time, 1, 2), ":", str_sub(Incident_Time, 3, 4)),
         Incident_Datetime = ymd_hm(str_c(Incident_Date, " ", Incident_Time)))

RSU_Detention <- RSU_Detention_Get()

RSU <- RSU_Detention %>% 
  filter(Admission_Type == "S")

RSU_Following_OC <- OC %>% 
  inner_join(RSU %>% select(TJJD_Number:Admission_Type)) %>% 
  mutate(Gap_Minutes = RSU_Detention_Start_Datetime - Incident_Datetime) %>% 
  select(TJJD_Number, 
         Incident_Pointer_Number,
         Incident_URL,
         Facility,
         Priority_Rule_Violation_Description,
         Incident_Datetime,
         RSU_Start_Datetime = RSU_Detention_Start_Datetime,
         Gap_Minutes,
         RSU_End_Datetime = RSU_Detention_End_Datetime,
         RSU_Detention_Duration_Hours) %>% 
  arrange(desc(Gap))

write_csv(RSU_Following_OC, "RSU Following OC Use Past 90 Days.csv", na = "")
