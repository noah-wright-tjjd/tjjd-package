library(tidyverse)
library(haven)
library(arsenal)
library(RODBC)
library(naniar)
library(readxl)
library(sqldf)
library(lubridate)

###Daily Youth Assignment Count

IRD035<-odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=IRD035",rows_at_time=1)
DateTable<-data.frame(Date=seq.Date(as.Date("2012-9-1"),today(),"day"))
LocationLookup<-read_excel("LocationTypeLookupHistorical.xlsx")

WidgetStaffingParameters<-data.frame(Facility=c("Evins","Gainesville","Giddings","Mart","Ron Jackson"),Fixed=c(49,41,46,65,48))

AllAssignmentFieldsSQL<-sqlQuery(IRD035, "SELECT TYCNO as TJJDNumber, 
                                                      MFPTR as MasterFilePointerNumber, 
                                 ASPTR as AssignmentPointerNumber, 
                                 DATEADD(DAY,ASMDY,21914) as AssignmentStartDate,
                                 DATEADD(DAY,EASMDY,21914) as AssignmentEndDate,
                                 LOC as LocationCode
                                 FROM POPASFIXED
                                 WHERE ASYY>11 and ASYY<30") %>%
  mutate(AssignmentStartDate=as.Date(AssignmentStartDate),
         AssignmentEndDate=as.Date(AssignmentEndDate)) %>%
  left_join(LocationLookup)

AssignmentDates<-sqldf('SELECT *
                         FROM AllAssignmentFieldsSQL
                         INNER JOIN DateTable ON AssignmentEndDate>=Date AND AssignmentStartDate<=Date')

AssignmentHistory<-AssignmentDates[!duplicated(AssignmentDates[c("TJJDNumber","Date")]),]

MultiEntryTest<-AssignmentHistory %>%
  group_by(TJJDNumber,Date) %>%
  summarize(Entries=n()) %>%
  filter(Entries>1)

AllDormFieldsSQL<-sqlQuery(IRD035, "SELECT TYCNO as TJJDNumber,
                                 ASPTR as AssignmentPointerNumber, 
                                 DATEADD(DAY,STMDY,21914) as DormAssignmentStartDate,
                                 DATEADD(DAY,ENDMDY,21914) as DormAssignmentEndDate,
                                 DORM as Dorm
                                 FROM DRMPDTL") %>%
  mutate(DormAssignmentStartDate=as.Date(DormAssignmentStartDate),
         DormAssignmentEndDate=as.Date(DormAssignmentEndDate))

DormAssignmentDates<-sqldf('SELECT *
      FROM AllDormFieldsSQL
      LEFT JOIN DateTable ON DormAssignmentEndDate>=Date AND DormAssignmentStartDate<=Date')

DormAssignmentHistory<-DormAssignmentDates[!duplicated(DormAssignmentDates[c("TJJDNumber","Date")]),]

MultiEntryTest<-DormAssignmentHistory %>%
  group_by(TJJDNumber,Date) %>%
  summarize(Entries=n()) %>%
  filter(Entries>1 & is.na(Date)==FALSE) %>%
  inner_join(DormAssignmentHistory)

StatusFieldsSQL<-sqlQuery(IRD035,'SELECT 
      TYCNO as TJJDNumber,
      DATEADD(DAY,STMDY,21914) as StatusStartDate,
      DATEADD(DAY,ENDMDY,21914) as StatusEndDate,
      STTYPE as StatusType
      FROM POPST') %>%
  mutate(StatusStartDate=as.Date(StatusStartDate),
         StatusEndDate=as.Date(StatusEndDate)) %>%
  filter(StatusEndDate>=as.Date("2017-09-01"))

StatusDates<-sqldf('SELECT *
      FROM StatusFieldsSQL
      LEFT JOIN DateTable ON StatusEndDate>=Date AND StatusStartDate<=Date')

StatusHistory<-StatusDates[!duplicated(StatusDates[c("TJJDNumber","StatusType","Date")]),]

OutOfFacility<-StatusHistory %>%
  filter(StatusType!="SEC") %>%
  rename(OutOfFacility=StatusType) %>%
  select(TJJDNumber,Date,OutOfFacility)

SecurityStays<-StatusHistory %>%
  filter(StatusType=="SEC") %>%
  rename(SecurityPop=StatusType) %>%
  anti_join(OutOfFacility,by=c("TJJDNumber","Date")) %>%
  select(TJJDNumber,Date,SecurityPop) 

SecurityFieldsSQL<-sqlQuery(IRD035,"SELECT 
                          TYCNO as TJJDNumber,
                          ASPTR as AssignmentPointerNumber,
                          ICPTR as IncidentPointerNumber,
                          DATEADD(DAY,STMDY,21914) as SecurityStartDate,
                          SDTIME as SecurityStartTime,
                          DATEADD(DAY,ENDMDY,21914) as SecurityEndDate,
                          SRTIME as SecurityEndTime,
                          LOC as LocationCode
                          FROM EVNTSD
                          WHERE SECDET='S' AND FY>2017") %>%
  left_join(LocationLookup)

SecurityTimeTable<-SecurityFieldsSQL %>%
  mutate(SecurityStartDateTime=ymd_hm(str_c(SecurityStartDate," ",str_pad(SecurityStartTime,4,pad=0))),
         SecurityEndDateTime=ymd_hm(str_c(SecurityEndDate," ",str_pad(SecurityEndTime,4,pad=0))),
         SecurityMinutes=(SecurityEndDateTime-SecurityStartDateTime))

SecurityByMonth<-SecurityTimeTable %>%
  mutate(Date=as.Date(str_c(year(SecurityStartDate),month(SecurityStartDate),1,sep="-"))) %>%
  group_by(Date,Facility) %>%
  summarize(SecurityHours=sum(SecurityMinutes)/60)

YouthHistory<-AssignmentHistory %>%
  left_join(OutOfFacility) %>%
  left_join(SecurityStays) %>%
  mutate(OutOfFacility=if_else(is.na(OutOfFacility)==TRUE,0,1),
         SecurityPop=if_else(is.na(SecurityPop)==TRUE,0,1))

#Don't need dorm count for this analysis
#DailyDormCount<-YouthHistory %>%
#  group_by(Date,AssignmentLocation,Dorm) %>%
#  summarize(Assignments=n(),
#            OutOfFacility=sum(OutOfFacility),
#            SecurityPop=sum(SecurityPop)) %>%
#  mutate(Population=Assignments-OutOfFacility)

DailyFacilityCount<-YouthHistory %>%
  group_by(Date,Facility) %>%
  summarize(Assignments=n(),
            OutOfFacility=sum(OutOfFacility),
            SecurityPop=sum(SecurityPop)) %>%
  mutate(Population=Assignments-OutOfFacility)

MonthlyFacilityCount<-data.frame(DailyFacilityCount) %>%
  mutate(Date=as.Date(str_c(year(Date),month(Date),1,sep="-"))) %>%
  group_by(Date,Facility) %>%
  summarize(Assignments=mean(Assignments),
            OutOfFacility=mean(OutOfFacility),
            SecurityPop=mean(SecurityPop),
            Population=mean(Population)) %>%
  left_join(SecurityByMonth) %>%
  left_join(WidgetStaffingParameters) %>%
  mutate(WidgetStaffingNeeds=(Population*13/16)+Fixed)

write_csv(MonthlyFacilityCount,"FacilityPopulation.csv")

YouthRace<-sqlQuery(IRD035,"SELECT TYCNO as TJJDNumber, RACE as Race
                            FROM ID")
YouthHistoryWithRace<-inner_join(YouthHistory,YouthRace)

DailyFacilityCountWithRace<-YouthHistoryWithRace %>%
  group_by(Date,Facility,Race) %>%
  summarize(Assignments=n(),
            OutOfFacility=sum(OutOfFacility),
            SecurityPop=sum(SecurityPop)) %>%
  mutate(Population=Assignments-OutOfFacility)

write_csv(DailyFacilityCountWithRace,"Daily Facility Count With Race.csv")
