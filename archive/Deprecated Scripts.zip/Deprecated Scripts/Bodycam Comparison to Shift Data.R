library(TJJD)

FootageRaw<-read_excel("3weeksAprilFootage.xlsx")
ShiftsRaw<-read_excel("3weeksAprilShifts.xlsx")

HR<-odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=TYCEmployees",rows_at_time = 1)
HRtables<-sqlTables(HR)
HRGeneral<-sqlQuery(HR, "SELECT * FROM TYC_PG2_JOB_CURR")

#HR Data
HRGeneralTable<-HRGeneral %>%
  filter(is.na(TINSID)==FALSE) %>%
  mutate(LastHireDate=as.Date(LastHireDate),
         TerminationDate=as.Date(TerminationDate),
         CCSLocCode=str_replace(CCSLocCode,"MCA","MCL")) %>%
  select(TINSID,
         FullName,
         EmploymentStatus,
         EmploymentStatusReason,
         JobCodeDescription,
         PositionCodeDescription,
         LastHireDate,
         TerminationDate,
         CCSLocCode)

IRD035<-odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=IRD035",rows_at_time=1)
IRD035tables<-sqlTables(IRD035)

LocationLookup<-sqlQuery(IRD035, "SELECT LOCCODE,LOCNAME
                           FROM LOCCODE")

HRGeneralTable<-left_join(HRGeneralTable,LocationLookup,c("CCSLocCode"="LOCCODE"))
HRGeneralTable$Location<-HRGeneralTable$LOCNAME
HRGeneralTable<-select(HRGeneralTable,-LOCNAME)


# Convert dates

FootageRaw[,str_detect(colnames(FootageRaw),"date_")]<-map(FootageRaw[,str_detect(colnames(FootageRaw),"date_")], function(x) {
  ymd_hms(str_replace(str_sub(x,1,-11),"T"," "))
}
)


#Duplicate Check
FootageRawDuplicates<-FootageRaw %>%
  group_by(owner_badge_id,created_date_record_start,date_record_end) %>%
  summarize(clips=n()) %>%
  filter(clips>1) %>%
  inner_join(FootageRaw)

FootageFields<-FootageRaw[!duplicated(select(FootageRaw,owner_badge_id,created_date_record_start,date_record_end)),] %>%
  filter(is.na(date_record_end)==FALSE)

#Create Camera Data Table
FootageTable<-FootageFields %>% 
  mutate(EvidenceID=evidence_id,
         TINSID=as.numeric(owner_badge_id),
         ClipStart=created_date_record_start,
         ClipEnd=date_record_end,
         NumericClipStart=as.numeric(created_date_record_start),
         NumericClipEnd=as.numeric(date_record_end),
         Role=uploaded_by_role,
         ClipHoursDuration=as.numeric((date_record_end-created_date_record_start)/3600),
         HoursGap=ifelse(owner_badge_id==lag(owner_badge_id,1),(created_date_record_start-lag(date_record_end,1))/3600,NA),
         LessThanOneHourGap=HoursGap>.25 & HoursGap<1,     
         OneToEightHourGap=HoursGap>=1 & HoursGap<8,
         SequentialEightPlusHourGap=HoursGap>8 & lag(HoursGap,1)>8) %>%
  select(EvidenceID,
         TINSID,
         Role,
         ClipStart,
         ClipEnd,
         NumericClipStart,
         NumericClipEnd,
         ClipHoursDuration,
         HoursGap,
         LessThanOneHourGap,
         OneToEightHourGap,
         SequentialEightPlusHourGap) %>%
  arrange(TINSID,NumericClipStart)

FootageJoin<-FootageTable %>%
  select(EvidenceID,TINSID,ClipStart,ClipEnd,NumericClipStart,NumericClipEnd,ClipHoursDuration)


#Create Shift Table


ShiftSample<-ShiftsRaw %>%
  filter(str_detect(`Job Type Scheduled`,paste(c("JCO","JCO Supv","Dorm Supvr"),collapse='|'))==TRUE
         & str_detect(Facility,"HWH")==FALSE) %>%
  mutate(StartDateTime=ymd_hms(str_c(`Start Date`," ",str_sub(`Start Time`,-8,-1))),
         EndDateTime=ymd_hms(str_c(`End Date`," ",str_sub(`End Time`,-8,-1))),
         ShiftStart=StartDateTime,
         ShiftEnd=EndDateTime,
         ShiftStartNumeric=as.numeric(StartDateTime),
         ShiftEndNumeric=as.numeric(EndDateTime),
         EmployeeID=as.numeric(`Employee ID`))

ShiftSample %>%
  group_by(EmployeeID) %>%
  summarize(n()) %>%
  nrow()

#Cleaning Tasks: Check overlap between tables and employee ID's

sum(ShiftSample$Length)

FootageTable %>%
  group_by(TINSID) %>%
  summarize(n()) %>%
  na.omit %>%
  nrow()

sum(FootageTable$ClipHoursDuration)

EmployeeIDNotinCamData<-select(ShiftSample,EmployeeID) %>%
  anti_join(FootageTable,by=c("EmployeeID"="TINSID")) %>%
  unique() %>%
  na.omit %>%
  mutate(MissingIn="Axon") %>%
  left_join(HRGeneralTable,by=c("EmployeeID"="TINSID"))

EmployeeIDNotinShiftData<-select(FootageTable,TINSID) %>%
  anti_join(ShiftSample,by=c("TINSID"="EmployeeID")) %>%
  unique() %>%
  na.omit %>% 
  mutate(MissingIn="Shifthound") %>%
  left_join(HRGeneralTable)

MissingIDs<-bind_rows(EmployeeIDNotinCamData,EmployeeIDNotinShiftData) %>%
  mutate(EmployeeID=str_remove(paste(EmployeeID,TINSID,sep=""),"NA")) %>%
  select(-TINSID)

EmployeeIDinBoth<-inner_join(select(FootageTable,TINSID),select(ShiftSample,EmployeeID),
                             by=c("TINSID"="EmployeeID")) %>%
                             unique()

##Build simplified Join table for linking shifts and clips

ShiftSample$UID<-seq.int(from=1,to=nrow(ShiftSample),by=1)

ShiftSampleJoin<-ShiftSample %>%
  select(UID,EmployeeID,ShiftStart,ShiftEnd)

#Clip/shift types:

#Clip End<Shift Start (Not in shift at all: ends before shift begins)
#Clip Start<Shift Start & Clip End<Shift End (Exceeds shift at beginning: starts before shift begins, ends before shift ends)
#Clip Start<Shift Start & Shift End<Clip End (Exceeds shift on both ends: starts before shift starts, ends after shift ends)
#Shift Start<Clip Start & Clip End<Shift End (clip contained entirely within shift)
#Shift Start<Clip Start & Shift End<Clip End (Exceeds shift at end: starts after shift begins, ends after shift ends)
#Shift End<Clip Start (Not in shift at all: starts after shift ends)

ClipsWithin<-sqldf('SELECT UID, EmployeeID, EvidenceID, ClipHoursDuration from ShiftSampleJoin
                   LEFT JOIN FootageJoin
                   ON (EmployeeID=TINSID AND NumericClipStart>ShiftStart AND NumericClipStart<ShiftEnd AND NumericClipEnd>ShiftStart AND NumericClipEnd<ShiftEnd)')

FootageWithin<-ClipsWithin %>%
  group_by(EmployeeID,UID) %>%
  summarize(FootageWithin=sum(as.numeric(ClipHoursDuration))) %>%
  mutate(FootageWithin=replace_na(FootageWithin,0))

ClipsBeforeandDuring<-sqldf('SELECT UID, EmployeeID, EvidenceID, ClipHoursDuration from ShiftSampleJoin
                            LEFT JOIN FootageJoin
                            ON (EmployeeID=TINSID AND NumericClipStart<ShiftStart AND NumericClipEnd>ShiftStart AND NumericClipEnd<ShiftEnd)')

FootageBeforeandDuring<-ClipsBeforeandDuring %>%
  group_by(EmployeeID,UID) %>%
  summarize(FootageBeforeandDuring=sum(as.numeric(ClipHoursDuration))) %>%
  mutate(FootageBeforeandDuring=replace_na(FootageBeforeandDuring,0))

ClipsDuringandAfter<-sqldf('SELECT UID, EmployeeID, EvidenceID, ClipHoursDuration from ShiftSampleJoin
                           LEFT JOIN FootageJoin
                           ON (EmployeeID=TINSID AND NumericClipStart>ShiftStart AND NumericClipStart<ShiftEnd AND NumericClipEnd>ShiftEnd)')

FootageDuringandAfter<-ClipsDuringandAfter %>%
  group_by(EmployeeID,UID) %>%
  summarize(FootageDuringandAfter=sum(as.numeric(ClipHoursDuration))) %>%
  mutate(FootageDuringandAfter=replace_na(FootageDuringandAfter,0))

ClipsExceeding<-sqldf('SELECT UID, EmployeeID, EvidenceID, ClipHoursDuration from ShiftSampleJoin
                      LEFT JOIN FootageJoin
                      ON (EmployeeID=TINSID AND NumericClipStart<ShiftStart AND NumericClipEnd>ShiftEnd)')

FootageExceeding<-ClipsExceeding %>%
  group_by(EmployeeID,UID) %>%
  summarize(FootageExceeding=sum(as.numeric(ClipHoursDuration))) %>%
  mutate(FootageExceeding=replace_na(FootageExceeding,0))

AllShiftClips<-bind_rows(ClipsWithin,ClipsExceeding,ClipsDuringandAfter,ClipsBeforeandDuring) %>% na.omit

#Generate summary stats

sum(AllShiftClips$ClipHoursDuration)

AllClipsWithNoShifts<-anti_join(FootageTable,AllShiftClips,  by="EvidenceID")

sum(AllClipsWithNoShifts$ClipHoursDuration)

AllClipsWithNoShiftsStaffinShifthound<-anti_join(inner_join(FootageTable,EmployeeIDinBoth),AllShiftClips,  by="EvidenceID")

sum(AllClipsWithNoShiftsStaffinShifthound$ClipHoursDuration)

#Join Data

AprilJoinedData<-ShiftSample %>%
  inner_join(FootageBeforeandDuring) %>%
  inner_join(FootageDuringandAfter) %>%
  inner_join(FootageWithin) %>%
  inner_join(FootageExceeding) %>%
  anti_join(EmployeeIDNotinCamData) %>%
  mutate(TotalShiftFootage=if_else(FootageExceeding==0,(FootageBeforeandDuring+FootageDuringandAfter+FootageWithin),FootageExceeding))

MultiEntry<-AprilJoinedData %>%
  group_by(EmployeeID,UID) %>%
  summarize(Count=n()) %>%
  filter(Count>1)

write_csv(AprilJoinedData,"AprilJoinedData.csv")
write_csv(FootageTable,"FootageTable.csv")
write_csv(ShiftSample,"AprilShiftTable.csv")
write_csv(HRGeneralTable,"HRGeneralTable.csv")

#Hour-by-hour

HourTable<-data.frame(HourStart=seq.int(ymd_hms("2019-4-1 0:00:00"),ymd_hms("2019-4-21 23:00:00"),by=3600)) %>%
  mutate(HourEnd=HourStart+3599,
         HourNumericStart=as.numeric(HourStart),
         HourNumericEnd=as.numeric(HourEnd))

ShiftsbyHour<-sqldf('SELECT * from HourTable
                            LEFT JOIN ShiftSample
                            ON (ShiftStartNumeric>=HourNumericStart AND ShiftEndNumeric<=HourNumericEnd)
                            OR (ShiftStartNumeric<=HourNumericStart AND ShiftEndNumeric>=HourNumericStart AND ShiftEndNumeric<=HourNumericEnd)
                            OR (ShiftStartNumeric>=HourNumericStart AND ShiftStartNumeric<=HourNumericEnd AND ShiftEndNumeric>=HourNumericEnd)
                            OR (ShiftStartNumeric<=HourNumericStart AND ShiftEndNumeric>=HourNumericEnd)')        

FootagebyHour<-sqldf('SELECT * from HourTable
                            LEFT JOIN FootageTable
                            ON (NumericClipStart>=HourNumericStart AND NumericClipEnd<=HourNumericEnd)
                            OR (NumericClipStart<=HourNumericStart AND NumericClipEnd>=HourNumericStart AND NumericClipEnd<=HourNumericEnd)
                            OR (NumericClipStart>=HourNumericStart AND NumericClipStart<=HourNumericEnd AND NumericClipEnd>=HourNumericEnd)
                            OR (NumericClipStart<=HourNumericStart AND NumericClipEnd>=HourNumericEnd)') %>%
  mutate(EmployeeID=TINSID)

FullHourTable<-full_join(ShiftsbyHour,FootagebyHour,by=c("HourStart","HourEnd","EmployeeID"))

write_csv(FullHourTable,"FullHourTable.csv")
