library(TJJD)

Employees <- Employee_Summary_Get()

Employees_Current <- Employees %>% 
  filter(is.na(Termination_Date))

write_csv(Employees_Current, "Current Employees.csv", na = "")

# Population Sheet -------------------------------------------------------

Pop_Sheet <- Metrics_Pop_Sheet()

write_csv(Pop_Sheet, str_c("Weekly Population - ",today(),".csv"))

# Axon Bodycam Data Updates ----------------------------------------------

Axon_Bodycam_Data_Update()

# CAPPS data processing ----------------------------

Permanent_Job_History <- CAPPS_Job_History_Get()

write_csv(Permanent_Job_History, "\\\\tjjd4avresaus1\\public\\HR and Analytics\\Job History Reformat.csv", na = "")

CAPPS_Leave_Monthly <- CAPPS_Leave_by_Month()

write_csv(CAPPS_Leave_Monthly, "\\\\tjjd4avresaus1\\public\\HR and Analytics\\Leave by Month.csv", na = "")

Employment_by_Month <- CAPPS_Job_History_Monthly()

write_csv(Employment_by_Month, "\\\\tjjd4avresaus1\\public\\HR and Analytics\\Job History Monthly.csv", na = "")

Employment_by_Month %>% 
  filter(str_detect(Job_Title, "JCO"),
         Month <= "2024-02-29") %>% 
  group_by(FY, FQ) %>% 
  summarize(Count = n_distinct(Empl_ID),
            Terms = sum(Term),
            Hires = sum(Hire)) %>% 
  group_by(FY) %>% 
  summarize(Quarterly_Average = mean(Count),
            Terms = sum(Terms),
            Hires = sum(Hires),
            LBB = sum(Terms)/mean(Count)) %>% 
  ungroup()

# Spells <- CAPPS_Employment_Spells()  
# 
# Employment_by_Month %>% 
#   inner_join(Spells %>% 
#                mutate(Tenure = as.numeric(if_else(is.na(Term_Date), today(), Term_Date) - Last_Hire))) %>% 
#   filter(str_detect(Job_Title, "JCO"),
#          Month >= Last_Hire_Month,
#          Month <= Last_Term_Month | is.na(Last_Term_Month),
#          Tenure > 90) %>% 
#   group_by(FY, FQ) %>% 
#   summarize(Count = n_distinct(Empl_ID),
#             Terms = sum(Term),
#             Hires = sum(Hire)) %>% 
#   group_by(FY) %>% 
#   summarize(Quarterly_Average = mean(Count),
#             Terms = sum(Terms),
#             Hires = sum(Hires),
#             LBB = sum(Terms)/mean(Count)) %>% 
#   ungroup()

Daily <- Daily_Pop_Get()

Daily_by_Type <- Daily %>% 
  mutate(Facility_Type = if_else(Facility_Type == "O & A", "Secure", Facility_Type)) %>% 
  group_by(Facility_Type, Date) %>% 
  summarize(Pop = sum(Total_Population)) %>% 
  ungroup()

FQ_ADP <- Daily_by_Type %>% 
  mutate(FY = State_FY(Date),
         FQ = State_FQ(Date)) %>% 
  group_by(FY, FQ, Facility_Type) %>% 
  summarize(ADP = mean(Pop)) %>% 
  pivot_wider(names_from = Facility_Type, values_from = ADP)

