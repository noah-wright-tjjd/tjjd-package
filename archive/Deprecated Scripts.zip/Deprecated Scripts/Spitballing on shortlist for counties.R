Population_Sheet <- Metrics_Pop_Sheet()

MF <- MF_Get()

ID <- ID_Get()

Risk <- Risk_MLOS_Get(Source = "sql")

#exclude:
#crimes with actual victims (not “the state”)
#offenses involving family violence
#aggravated felonies
#crimes where a firearm was used or exhibited

Relevant_MF <- MF %>% 
  group_by(TJJD_Number) %>% 
  filter(max(Commitment_End_Date) == "2099-12-31",
         max(Determinate_Sentence, na.rm = TRUE) == "N",
         max(Commitment_Type == "RCMT") == 0,
         Commitment_Type == "CMNT") %>% 
  ungroup()

Revocations <- MF %>% 
  group_by(TJJD_Number) %>% 
  filter(max(Commitment_End_Date) == "2099-12-31",
         max(Determinate_Sentence, na.rm = TRUE) == "N",
         max(Commitment_Type == "RCMT") == 0,
         Commitment_Type == "RVKD") %>% 
  ungroup()

Assignments_Current <- Assignments_Get() %>% 
  filter(Assignment_End_Date == "2099-12-31")

Secure <- Relevant_MF %>% 
  inner_join(Assignments_Current %>% 
               select(TJJD_Number, Assignment_Location, Facility_Type) %>% 
               filter(Facility_Type %in% c("Secure", "O & A"))) %>% 
  inner_join(ID %>% select(TJJD_Number, First_Name, Last_Name, Age) %>% filter(Age >= 17)) %>% 
  semi_join(Risk %>% 
               filter(ap_off == "N",
                      wc_off == "N") %>% 
              select(TJJD_Number = tycno)) %>% 
  select(TJJD_Number, 
         First_Name, 
         Last_Name, 
         Age, 
         Assignment_Location,
         Commitment_County, 
         Admission_Date, 
         Offense_Code = Classifying_Offense_Code, 
         Offense = Classifying_Offense)

Extra <- Population_Sheet %>% 
  select(TJJD_Number,
         Most_Recent_Stage,
         contains("Assault"))

write_csv(Secure, "Secure ISO 17+ no weapon or against person.csv")



write_csv(Secure_Classifying_Offenses, "Secure Classifying Offenses.csv")

#Age 17 / 18
#Committing County

#In VIC
#COG, SBTP
#Injury assault upheld in 90 days



#
#Any level 1 or 2 in 30 days? Any in 90 days?
#Are they past MLOS vs. not
#Grade level (or diploma / GED?)
#SPED
#Treatment Complete by treatment type
#Create discrete release packets
#Stage




Disqualifier <- Treatment_Complete %>% 
  filter(is.na(Completion_Level),
         is.na(Waiver_Approval),
         (Treatment == "CSVOTP" & Priority == "H") | Treatment == "SBTP" & Priority %in% c("M", "H"))

Last_Stage <- Stages_Get()

MF_4_or_Less <- MF %>% 
  filter(Commitment_Type == "CMNT",
         (today() - Admission_Date) <= 120)

Risk <- Risk_MLOS_Get()

Category4 <- Population_Sheet %>% 
  left_join(L2_Hearings_Summary) %>% 
  filter(Age >= 17,
         Location_Type == 'Secure',
         is.na(Status_Type),
         Determinate_Sentence == 'N',
         is.na(Assaultive_Injury_L2_90) | Assaultive_Injury_L2_90 == 0,
         Most_Recent_Stage %in% c("S3", "S4", "YES")) %>% 
  anti_join(Disqualifier, by = "TJJD_Number") %>% 
  anti_join(MF_4_or_Less, by = "TJJD_Number")



write_csv(Category4, "ISO, 17+, S3+, No L2 injurious, 4+ months, No incomplete COG or SBTP.csv", na = "")

#Phoenix / RDP

Treatment_Complete <- Metrics_Treatment_Complete()


Category4 %>% 
  filter(Facility != "EVINS PHOENIX",
         L2_Hearings_Past30Days == 0) %>% 
  anti_join(Incomplete, by = "TJJD_Number")

#18-year-olds, how many

         
