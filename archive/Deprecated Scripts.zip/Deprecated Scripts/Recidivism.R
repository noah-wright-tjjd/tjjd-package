library(TJJD)
library(arsenal)

FY <- 2024

KEY_PERF_Directory<-str_c("\\\\tjjd4avsascen\\apps\\KEY_PERF\\FY_", FY, "\\DPS\\Data\\Q4\\August\\")
Working_Directory <- str_c("\\\\tjjd4avsascen\\apps\\ARecid_", str_sub(FY, -2), "\\August\\")

KEY_PERF_SAS_File_Names<-data.frame(Names=list.files(KEY_PERF_Directory)) %>%
  filter(str_detect(Names,"sas7bdat")==TRUE)

Working_Directory_File_Names<-data.frame(Names=list.files(Working_Directory)) %>%
  filter(str_detect(Names,"sas7bdat")==TRUE)

TDCJ <- import(str_c(Working_Directory, "TDCJ\\COHTDCJ.sav"))
DPS <- import(str_c(Working_Directory, "arr3_aug_lbb.sas7bdat"))

Arr3_Aug_Matches %>% 
  group_by(RLFY) %>% 
  summarize(mean(ARR1))

Offense_Codes <- read_excel("Offense Codes.xlsx")
Arrest_Disposition_Codes <- read_excel("Arrest Disposition Codes.xlsx")
Dictionary <- read_excel("Data Dictionary.xlsx")

ID <- ID_Get()

Masterfiles <- Masterfiles_Get(Timeframe = "Historical")

Assignments <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=IRD035",rows_at_time=1),
                        "SELECT TYCNO, ASPTR, PRLSTAT, ERDMDY, LOC, ASMDY, EASMDY, PRELOC, MVNTCODE, MVNTTYPE FROM POPASFixed
                                      WHERE EASMDY>18723") %>%
  left_join(Location_Type_Lookup,by = c("LOC" = "Location_Code")) %>%
  left_join(Location_Type_Lookup, by = c("PRELOC" = "Location_Code")) %>% 
  mutate(Earliest_Release_Date=as.Date(ERDMDY,origin="1960-01-01"),
         Assignment_Start_Date=as.Date(ASMDY,origin="1960-01-01"),
         Assignment_End_Date=as.Date(EASMDY,origin="1960-01-01"),
         Assignment_Duration=if_else(Assignment_End_Date==as.Date("2099-12-31"),
                                     -1,
                                     as.numeric(Assignment_End_Date-Assignment_Start_Date))) %>%
  select(TJJD_Number=TYCNO,
         Assignment_Pointer_Number=ASPTR,
         Assignment_Start_Date,
         Assignment_End_Date,
         Assignment_Duration,
         Earliest_Release_Date,
         Parole_Status=PRLSTAT,
         Assignment_Location = Assignment_Location.x,
         Facility = Facility.x,
         Security_Level = Security_Level.x,
         Facility_Type = Facility_Type.x,
         Previous_Assignment = Assignment_Location.y,
         Previous_Security_Level = Security_Level.y,
         Previous_Facility_Type = Facility_Type.y,
         Movement_Type=MVNTTYPE,
         Movement_Code=MVNTCODE) %>%
  left_join(Movement_Code_Lookup)


# Analysis --------------------

#Create cohorts. Releases to non-secure and discharges.

Movement_from_Secure_Recidivism <- Assignments %>% 
  left_join(Assignments %>% 
              mutate(Assignment_Pointer_Number = Assignment_Pointer_Number+1) %>% 
              select(TJJD_Number, Assignment_Pointer_Number, Prior_Movement_Type = Movement_Type, Prior_Movement_Description = Movement_Description)) %>% 
  mutate(Release_Date = Assignment_Start_Date,
         FY = State_FY(Release_Date),
         Type = "Movement from Secure") %>% 
  filter(Previous_Security_Level %in% c("Secure", "O & A"),
         !Security_Level %in% c("Secure", "O & A"),
         Prior_Movement_Type != "TA",
         FY <= 2021) %>% 
  select(TJJD_Number, Release_Date, FY, Type)

Masterfiles_Recidivism <- ID %>% 
  inner_join(Masterfiles) %>% 
  mutate(Release_Date = Discharge_Date,
         FY = State_FY(Discharge_Date),
         Type = "Discharge") %>% 
  filter(FY <= 2021,
         !Discharge_Reason_Code %in% c("STAD", "JAIL", "TTDC", "DIED", "JACT", NA),
         !First_Name %in% c("Commitment", "Vacated", "Invalid", "Overturned", "Reversed"),
         !Last_Name %in% c("Commitment", "Vacated", "Invalid", "Overturned", "Reversed")) %>% 
  select(TJJD_Number, Release_Date, FY, Type)

Cohort_Recidivism <- bind_rows(Masterfiles_Recidivism, Movement_from_Secure_Recidivism) %>% 
  arrange(TJJD_Number, Release_Date)

First_Release_Date <- Cohort_Recidivism %>% 
  group_by(TJJD_Number) %>% 
  summarize(First_Release_Date = first(Release_Date),
            Release_FY = first(FY)) %>% 
  ungroup() %>% 
  mutate(Time_from_Release = as.Date("2022-08-31") - First_Release_Date) %>% 
  filter(Release_FY >= 2010)

Release_Format <- First_Release_Date %>% 
  mutate(`1-Year` = Time_from_Release >= years(1),
         `2-Year` = Time_from_Release >= years(2),
         `3-Year` = Time_from_Release >= years(3)) %>% 
  pivot_longer(`1-Year`:`3-Year`, names_to = "Years_from_Release", values_to = "Present") %>% 
  filter(Present) %>% 
  select(-Present)

#All Masterfiles accounted for in cohort ('cohort' is complete list that includes TDCJ sentences and overturns)

Arrest_Records <- Arrest_Maint_Match %>% 
  mutate(Arrest_Date = as.Date(DOA3, "%Y%m%d"),
         Arrest_Offense_Date = as.Date(DOO3, "%Y%m%d"),
         Arrest_Disposition_Date = as.Date(ADA3, "%Y%m%d"),
         Level_and_Degree = factor(LDA3, c("M*", "MC", "MB", "MA", "F*", "F3", "F2", "F1", "FX"), ordered = TRUE),
         TJJD_Number = as.integer(TYCNO)) %>% 
  left_join(Offense_Codes, by = c("AON3" = "NCIC")) %>% 
  left_join(Arrest_Disposition_Codes, by = c("ADN3" = "Disposition_Code")) %>% 
  select(TJJD_Number,
         DPS_Number = DPSNBR,
         Name = NAME,
         Arrest_Date,
         Sequence = SEQ3,
         Tracking_Incident_Number = TRS3,
         Arrest_Offense_Date,
         Arrest_Offense_Numeric = AON3,
         Arrest_Offense = OffDesc,
         Arrest_Offense_Notes = AOL3,
         Citation = CIT3,
         Level_and_Degree,
         General_Offense_Character = GOC3,
         Arrest_Disposition_Numeric = ADN3,
         Arrest_Disposition,
         Arrest_Disposition_Notes = ADD3,
         Arrest_Disposition_Date,
         Referred_to_Prosecutor = REF3,
         Juvenile_Arrest = JUV3) %>% 
  filter(!is.na(Arrest_Date),
         Level_and_Degree >= "MB")

#Need to fix this to differentiate between arrests in 2nd year vs. first year etc
Arrest_Format <- Arrest_Records %>% 
  inner_join(First_Release_Date) %>% 
  mutate(Release_to_Arrest = Arrest_Date - First_Release_Date) %>% 
  filter(Release_to_Arrest >= 0,
         Release_to_Arrest <= years(3)) %>% 
  mutate(`1-Year` = Release_to_Arrest < years(1),
         `2-Year` = Release_to_Arrest < years(2),
         `3-Year` = Release_to_Arrest < years(3)) %>% 
  pivot_longer(`1-Year`:`3-Year`, names_to = "Years_from_Release", values_to = "Present") %>% 
  filter(Present) %>% 
  group_by(TJJD_Number, Years_from_Release) %>% 
  summarize(Worst_Level = max(Level_and_Degree)) %>% 
  ungroup() %>% 
  mutate(Any_Arrest = !is.na(Worst_Level),
         Felony_Arrest = str_detect(Worst_Level, "F"))

#Compare individual youth and determine where your calculation is differing from Lory's

Recidivism_by_Youth <- Release_Format %>% 
  left_join(Arrest_Format) %>% 
  mutate(across(contains("Arrest"), ~replace_na(.x, 0)))

Recid_Check <- Recidivism_by_Youth %>% 
  group_by(Release_FY, Years_from_Release) %>% 
  summarize(N = n(),
            Recid_Rate = mean(Any_Arrest),
            Recid_Felony_Rate = mean(Felony_Arrest))

