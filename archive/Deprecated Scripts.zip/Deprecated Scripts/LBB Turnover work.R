library(TJJD)

PM3<-sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=IRD035",rows_at_time=1),
         "SELECT * FROM PM3")


Metrics_LBB_Turnover()


#Part 1: Create 'start date' variable, the more recent of either rehire date or initial hire date
#Part 2: Create 'end date' variable, replacing null values in Termination date with today's date

Employees_Monthly <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=TYCEmployees",rows_at_time=1),
"SELECT Date, ccsloccode as CCS_Location_Code, count(TINSID) AS Coaches, 
count(CASE WHEN Start_Month=Date
THEN 1
END) AS Hires,
count(CASE WHEN End_Month=Date
THEN 1
END) AS Terminations
FROM
(SELECT TINSID, PG2.FullName, LastHireDate AS Initial_Hire_Date, RehireDate,
CASE WHEN Cast(rehiredate AS DATE)>LastHireDate
THEN dateadd(month,datediff(month,0,rehiredate),0)
ELSE dateadd(month,datediff(month,0,LastHireDate),0)
END 
AS Start_Month, 
dateadd(month,datediff(month,0,isnull(PG2.TerminationDate, '2099-12-31')),0) 
AS End_Month,
JobCodeDescription, CCSLocCode, PG2.Location
FROM vCAPPS_PG2_JOB_CURR PG2
LEFT JOIN CAPPS_CEI_Empl CEI
on PG2.TINSID = CEI.Emplid
WHERE JobCodeDescription LIKE '%JCO%') EMP
INNER JOIN (SELECT Date
            FROM DATE_CALENDAR
            where DAY = 1 and YEAR>2019 and Date<GETDATE()) CAL
on EMP.Start_Month <= CAL.Date and EMP.End_Month >= CAL.Date
group by Date, ccsloccode")

Employees_Quarterly <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=TYCEmployees",rows_at_time=1),
                              "SELECT Date, ccsloccode as CCS_Location_Code, count(TINSID) AS Coaches, 
count(CASE WHEN Start_Month=Date
THEN 1
END) AS Hires,
count(CASE WHEN End_Month=Date
THEN 1
END) AS Terminations
FROM
(SELECT TINSID, PG2.FullName, LastHireDate AS Initial_Hire_Date, RehireDate,
CASE WHEN Cast(rehiredate AS DATE)>LastHireDate
THEN dateadd(month,datediff(month,0,rehiredate),0)
ELSE dateadd(month,datediff(month,0,LastHireDate),0)
END 
AS Start_Month, 
dateadd(month,datediff(month,0,isnull(PG2.TerminationDate, '2099-12-31')),0) 
AS End_Month,
JobCodeDescription, CCSLocCode, PG2.Location
FROM vCAPPS_PG2_JOB_CURR PG2
LEFT JOIN CAPPS_CEI_Empl CEI
on PG2.TINSID = CEI.Emplid
WHERE JobCodeDescription LIKE '%JCO%') EMP
INNER JOIN (SELECT *
FROM DATE_CALENDAR
                     where DAY = 1 and (Month = 9 OR Month = 12 OR Month = 3 OR Month = 6)
                     and STATE_FISCAL_YEAR>2019 and Date<GETDATE()) CAL
on EMP.Start_Month <= CAL.Date and EMP.End_Month >= CAL.Date
group by Date, ccsloccode")



#Part 3: Conditional Join on calendar table
#Part 4: Group by location and calendar month, count coaches

Date_Cal <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=TYCEmployees",rows_at_time=1),
                      "SELECT *
FROM DATE_CALENDAR
                     where DAY = 1 and (Month = 9 OR Month = 12 OR Month = 3 OR Month = 6)
                     and STATE_FISCAL_YEAR>2019")

#Reformat rehire date
#Join on calendar


  Combined <- PG2 %>%
    left_join(CEI) %>%
    mutate(Initial_Hire_Date = as.Date(LastHireDate),
           Termination_Date=as.Date(TerminationDate),
           State_Seniority_Date=as.Date(SeniorityDate),
           Birth_Date=as.Date(BirthDate),
           CCS_Loc_Code=str_replace(CCSLocCode,"MCA","MCL"),
           CCS_Loc_Code=str_replace(CCS_Loc_Code,"HNU","HKH"),
           CCS_Loc_Code=if_else(str_detect(PositionCodeDescription,"JCO")==TRUE &
                                  str_detect(tolower(PositionCodeDescription),"trans")==TRUE,"TRA",CCS_Loc_Code),
           CCS_Loc_Code=if_else(str_detect(PositionCodeDescription,"JCO")==TRUE,str_replace(CCS_Loc_Code,"BOA","BWD"),CCS_Loc_Code)) %>%
    select(Employee_ID=TINSID,
           Name=FullName,
           Email,
           Birth_Date = BirthDate,
           Gender,
           Ethnicity = EthnicCode,
           Job_Code_Description = JobCodeDescription,
           Position_Code_Description = PositionCodeDescription,
           State_Seniority_Date,
           Initial_Hire_Date,
           Rehire_Date,
           Termination_Date,
           Location_Code = CCS_Loc_Code,
           HR_Location = Location,
           Supervisor = SupervisorFullname) %>%
    left_join(Location_Type_Lookup, "Location_Code")

Employee_Summary <- Employee_Summary_Get()

Coaches <- Employee_Summary %>%
  filter(str_detect(Job_Code_Description,"JCO") == TRUE) %>%
  mutate(Start_Date=if_else(is.na(Rehire_Date), Initial_Hire_Date, Rehire_Date),
         End_Date =if_else(is.na(Termination_Date), today() + months(1), as.Date(Termination_Date)),
         Start_Month = floor_date(Start_Date, 'month'),
         End_Month = floor_date(End_Date, 'month'),
         Start_Quarter = quarter(Start_Month, with_year = TRUE, fiscal_start = 9),
         End_Quarter = quarter(End_Month, with_year = TRUE, fiscal_start = 9)) %>%
  select(Employee_ID,
         Name,
         Title = Job_Code_Description,
         Start_Date,
         End_Date,
         Start_Month,
         End_Month,
         Start_Quarter,
         End_Quarter,
         Assignment_Location:Facility_Type)
