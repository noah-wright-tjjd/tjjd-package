Current_Employees <- function() {
  Employee_Summary_Get() %>% 
    filter(is.na(Termination_Date)) %>% 
    arrange(HR_Location, Division, Supervisor, Name) %>% 
    mutate(Supervisor = case_when(Name == "Robertson, Jeffery Don" ~ "Office of the Governor",
                                  Name == "Carter, Shandra L" ~ "TJJD Board",
                                  Name == "Guajardo, Daniel" ~ "TJJD Board",
                                  TRUE ~ Supervisor))
}
