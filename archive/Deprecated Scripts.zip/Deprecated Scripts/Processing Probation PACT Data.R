library(tidyverse)
library(RODBC)

#Setup ------------------------------

PACT_and_RPACT_With_Factors <- read_csv("Data Sources/PACT and PRACT Forms and Scores with Factors.csv")

Probation_Connection <- odbcDriverConnect(connection="Driver=ODBC Driver 18 for SQL Server;server=tjjd4avjuvrepdb;database=CSE_IT;Trusted_Connection=yes;TrustServerCertificate=yes",rows_at_time=1)

#' The PACT tables' format is terrible. Every question has its own column and
#' they use full-text responses instead of numeric identifiers, causing
#' everything to run very slowly. I start by pulling the columns and eyeballing
#' the fields I need so I don't have to query the entire thing every time

Probation_PACT_Columns <- sqlQuery(Probation_Connection,
                                   "select top 0 * from TJJD_PACT")

PACT_Column_Index <- data.frame(Names = colnames(Probation_PACT_Columns), 
                                Index = 1:ncol(Probation_PACT_Columns))

#'Units of analysis: first, form-level data, i.e. everything but questions,
#'answers, or results

Form_Info <- PACT_Column_Index %>% 
  filter(Index %in% c(2, 5:13, 17:20, 22:30)) %>% 
  pull(Names) %>% 
  str_c(collapse = ", ")

Form_Instances <- sqlQuery(Probation_Connection,
                           str_c("select distinct ", Form_Info, 
                                 " from TJJD_PACT where 
                                 FORM_MODE = 'Full-Screen' and 
                                 FORM_LABEL = 'Initial Assessment' and
                          COUNTY_NUMBER is not null and
                          PID_NUMBER is not null"))

#' This is cleanup for the results that have different responses for some
#' fields despite being the same youth and form instance ID (which I thought was
#' a unique identifier).

Form_Instances <- Form_Instances %>% 
  group_by(COUNTY_NUMBER, PID_NUMBER, FORM_INSTANCE_ID) %>% 
  summarize_all(last) %>% 
  ungroup()

#Criminal and Social Risk ------------------------------

#'Narrowing down to just the questions that influence criminal and social risk,
#'which makes the query run faster by excluding any questions that don't
#'contribute (especially the free response questions which slow it down a lot)

Criminal_Social_Risk <- PACT_and_RPACT_With_Factors %>% 
  filter(Form == "PACT",
         `Social History_TF`|`Criminal History_TF`) %>% 
  select(Probation_PACT_Question_Format, 
         `Social History`,
         `Criminal History`) %>% 
  pivot_longer(`Social History`:`Criminal History`, names_to = "Risk_Type", values_to = "Score") %>% 
  filter(Score > 0,
         !is.na(Probation_PACT_Question_Format)) %>% 
  select(Probation_PACT_Question_Format) %>% 
  unique() %>% 
  pull(Probation_PACT_Question_Format) %>% 
  str_c(collapse = ", ")

Criminal_Social_First_Results <- sqlQuery(Probation_Connection,
                                          str_c("select distinct COUNTY_NUMBER, PID_NUMBER, FORM_INSTANCE_ID, ", 
                                                Criminal_Social_Risk,
                                                " from TJJD_PACT where 
                                 FORM_MODE = 'Full-Screen' and 
                                 FORM_LABEL = 'Initial Assessment' and
                          COUNTY_NUMBER is not null and
                          PID_NUMBER is not null"))

#' This is cleanup for the results that have different responses for some
#' fields despite being the same youth and form instance ID (which I thought was
#' a unique identifier).

Criminal_Social_Results <- Criminal_Social_First_Results %>% 
  group_by(COUNTY_NUMBER, PID_NUMBER, FORM_INSTANCE_ID) %>% 
  summarize_all(last) %>% 
  ungroup()

Criminal_Social__lookup <- PACT_and_RPACT_With_Factors %>% 
  filter(`Social History_TF`|`Criminal History_TF`,
         Form == "PACT",
         !str_detect(Question_Text, "Hidden")) %>% 
  select(Probation_PACT_Question_Format,
         Section_ID,
         Section,
         Question_ID, 
         Question_Text, 
         Answer_ID, 
         Answer_Text, 
         Checklist,
         `Criminal History`,
         `Social History`)

#'Questions that have mutually exclusive choices

Criminal_Social_Results_Non_Checklist <- Criminal_Social_Results %>% 
  pivot_longer(-c(FORM_INSTANCE_ID, COUNTY_NUMBER, PID_NUMBER), names_to = "Probation_PACT_Question_Format", values_to = "Answer_Text") %>% 
  inner_join(Criminal_Social__lookup %>% 
               filter(Checklist == FALSE)) %>% 
  select(COUNTY_NUMBER, PID_NUMBER, FORM_INSTANCE_ID, Answer_ID, 
         `Social History`,
         `Criminal History`)

#'Questions that can appear multiple times in the data since they're checkboxes

Criminal_Social_Results_Checklist <- Criminal_Social_Results %>% 
  pivot_longer(-c(FORM_INSTANCE_ID, COUNTY_NUMBER, PID_NUMBER), names_to = "Probation_PACT_Question_Format", values_to = "Answer_Text") %>% 
  inner_join(Criminal_Social__lookup %>% 
               filter(Checklist) %>% 
               select(Probation_PACT_Question_Format) %>% 
               unique()) %>% 
  separate(Answer_Text, as.character(c(1:11)), sep = ", ", fill = "right") %>% 
  mutate(`1` = if_else(str_detect(`1`, "Violent outbursts"), str_c(`1`, `2`, `3`, sep = ", "), `1`)) %>% 
  pivot_longer(c(`1`:`11`), names_to = "Response_Number", values_to = "Answer_Text") %>% 
  filter(!is.na(Answer_Text),
         Answer_Text != "NULL") %>% 
  select(-Response_Number) %>% 
  inner_join(Criminal_Social__lookup) %>% 
  select(COUNTY_NUMBER, PID_NUMBER, FORM_INSTANCE_ID, Answer_ID, `Criminal History`, `Social History`)

Criminal_Social_Final_Results <-  Criminal_Social_Results_Checklist %>% 
  bind_rows(Criminal_Social_Results_Non_Checklist) %>% 
  inner_join(Criminal_Social__lookup)

#Look up categories to make sure PACT/RPACT are same

Criminal_Social_Scores <- Criminal_Social_Final_Results %>% 
  group_by(COUNTY_NUMBER, PID_NUMBER, FORM_INSTANCE_ID) %>% 
  summarize(across(contains("History"), sum)) %>% 
  ungroup() %>% 
  mutate(Criminal_Risk = case_when(`Criminal History` <= 5 ~ "Low",
                                   `Criminal History` <= 9 ~ "Moderate",
                                   TRUE ~ "High"),
         Social_Risk = case_when(`Social History` <= 2 ~ "Low",
                                 `Social History` <= 7 ~ "Moderate",
                                 TRUE ~ "High"))

Criminal_Social_Risk <- Form_Instances %>% 
  left_join(Criminal_Social_Scores)

write_csv(Criminal_Social_Risk, "All Probation PACT Criminal and Social Risk.csv")

#Big 8 Factors ------------------------------

#'Narrowing down to just the questions that influence Big 8 Risk factors, which
#'makes the query run faster by excluding any questions that don't contribute
#'(especially the free response questions which slow it down a lot)

Big8_Questions <- PACT_and_RPACT_With_Factors %>% 
  select(Probation_PACT_Question_Format, 
         contains("Big8")) %>% 
  pivot_longer(`Family - Big8RiskFactor`:`Criminal Thinking - Big8RiskFactor`, names_to = "Big8", values_to = "Score") %>% 
  filter(Score > 0,
         !is.na(Probation_PACT_Question_Format)) %>% 
  select(Probation_PACT_Question_Format) %>% 
  unique() %>% 
  pull(Probation_PACT_Question_Format) %>% 
  str_c(collapse = ", ")

Big8_First_Results <- sqlQuery(Probation_Connection,
                               str_c("select distinct COUNTY_NUMBER, PID_NUMBER, FORM_INSTANCE_ID, ", Big8_Questions, 
                                     " from TJJD_PACT where 
                                 FORM_MODE = 'Full-Screen' and 
                                 FORM_LABEL = 'Initial Assessment' and
                          COUNTY_NUMBER is not null and
                          PID_NUMBER is not null"))

#' This is cleanup for the results that have different responses for some
#' fields despite being the same youth and form instance ID (which I thought was
#' a unique identifier).

Big8_Results <- Big8_First_Results %>% 
  group_by(COUNTY_NUMBER, PID_NUMBER, FORM_INSTANCE_ID) %>% 
  summarize_all(last) %>% 
  ungroup()


Big8_Lookup <- PACT_and_RPACT_With_Factors %>% 
  select(Probation_PACT_Question_Format,
         Section_ID,
         Section,
         Question_ID, 
         Question_Text, 
         Answer_ID, 
         Answer_Text, 
         Checklist, 
         contains("Big8"))

#'Questions that have mutually exclusive choices

Big8_Results_Non_Checklist <- Big8_Results %>% 
  pivot_longer(-c(FORM_INSTANCE_ID, COUNTY_NUMBER, PID_NUMBER), names_to = "Probation_PACT_Question_Format", values_to = "Answer_Text") %>% 
  inner_join(Big8_Lookup %>% 
               filter(Checklist == FALSE)) %>% 
  select(COUNTY_NUMBER, PID_NUMBER, FORM_INSTANCE_ID, Answer_ID, contains("Big8"))

#'Questions that can appear multiple times in the data since they're checkboxes

Big8_Results_Checklist <- Big8_Results %>% 
  pivot_longer(-c(FORM_INSTANCE_ID, COUNTY_NUMBER, PID_NUMBER), names_to = "Probation_PACT_Question_Format", values_to = "Answer_Text") %>% 
  inner_join(Big8_Lookup %>% 
               filter(Checklist) %>% 
               select(Probation_PACT_Question_Format) %>% 
               unique()) %>% 
  separate(Answer_Text, as.character(c(1:11)), sep = ", ", fill = "right") %>% 
  mutate(`1` = if_else(str_detect(`1`, "Violent outbursts"), str_c(`1`, `2`, `3`, sep = ", "), `1`)) %>% 
  pivot_longer(c(`1`:`11`), names_to = "Response_Number", values_to = "Answer_Text") %>% 
  filter(!is.na(Answer_Text),
         Answer_Text != "NULL") %>% 
  select(-Response_Number) %>% 
  inner_join(Big8_Lookup) %>% 
  select(COUNTY_NUMBER, PID_NUMBER, FORM_INSTANCE_ID, Answer_ID, contains("Big8"))

Big8_Final_Results <-  Big8_Results_Checklist %>% 
  bind_rows(Big8_Results_Non_Checklist)

Big8_Scores <- Big8_Final_Results %>% 
  group_by(COUNTY_NUMBER, PID_NUMBER, FORM_INSTANCE_ID) %>% 
  summarize(across(contains("Big8"), sum))

Big8_Factors <- Form_Instances %>% 
  left_join(Big8_Scores)

write_csv(Big8_Factors, "All Probation PACT Big 8.csv")
