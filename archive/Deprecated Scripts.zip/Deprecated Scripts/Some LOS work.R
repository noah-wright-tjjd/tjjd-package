Masterfiles <- Masterfiles_Get("Historical")

Commitments <- Masterfiles %>% 
  mutate(Determinate_Sentence = replace_na(Determinate_Sentence, "N"),
         Discharge_Date = replace_na(Discharge_Date, today())) %>% 
  filter(Commitment_Type != "RVKD") %>% 
  group_by(TJJD_Number, Discharge_Date, Determinate = Determinate_Sentence) %>% 
  summarize(Commitment_Start = min(Commitment_Start_Date)) %>% 
  ungroup() %>% 
  filter(Discharge_Date >= "2016-09-01")
  
Assignments <- Assignments_Get("Historical")

by <- join_by(TJJD_Number, Commitment_Start <= Assignment_Start_Date, Discharge_Date >= Assignment_End_Date)

Commitments_With_Assignments <- Commitments %>% 
  inner_join(Assignments, by)

ALOS_at_Discharge <-  Commitments_With_Assignments %>% 
  filter(Discharge_Date != today()) %>% 
  group_by(TJJD_Number, Determinate, Commitment_Start, Discharge_Date, Facility_Type) %>% 
  summarize(Duration = sum(Assignment_Duration)) %>% 
  pivot_wider(names_from = Facility_Type, values_from = Duration, values_fill = 0) %>% 
  group_by(Determinate, FY = State_FY(Discharge_Date)) %>% 
  summarize(across(where(is.numeric), mean))

Current_LOS_by_Month <- Commitments_With_Assignments %>% 
  Interval_Convert.Date(Assignment_Start_Date, Assignment_End_Date, "month") %>% 
  group_by(TJJD_Number, Assignment_Pointer_Number) %>% 
  mutate(Point_in_Time_Duration = cumsum(as.numeric(Seconds_Duration_Within_Interval))) %>% 
  group_by(Determinate, Month = Interval_Start, Facility_Type) %>% 
  summarize(Point_In_Time_Average = mean(Point_in_Time_Duration)) %>% 
  ungroup() %>% 
  filter(Month >= "2016-09-01")

Current_LOS_by_Month %>% 
  filter(Facility_Type == "Secure") %>% 
  ggplot(aes(x = Month, y = Point_In_Time_Average, color = Determinate)) +
  geom_line()
