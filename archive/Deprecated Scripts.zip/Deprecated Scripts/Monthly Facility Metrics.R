library(TJJD)

Employees <- Employee_Summary_Get()

Start_Date <- floor_date(today(), "month") - months(6)
End_Date <- floor_date(today(), "month") - 1
End_FY <- State_FY(today()) - 1

Incidents <- Incidents_Get()
RSU <- RSU_Detention_Get()
SA <- Suicide_Assessments_Get()

Job_History <- CAPPS_Job_History_Get()
HR <- CAPPS_Job_History_Monthly()
Employment_Spells <- CAPPS_Employment_Spells()

ID <- ID_Get()

Incidents_Relevant <- Incidents %>% 
  inner_join(ID) %>% 
  filter(Facility_Type %in% c("Secure", "O & A")) %>% 
  mutate(Any_Mechanical_Restraint = if_else(Mechanical_Restraints_Used_In_Security + 
                                              Mechanical_Restraints_Used_For_Control + 
                                              Mechanical_Restraints_Used_During_Non_Routine_Transportation == 0, 
                                            0, 1))

RSU_Relevant <- RSU  %>% 
  inner_join(ID) %>% 
  filter(Facility_Type %in% c("Secure", "O & A"),
         Admission_Type == "S") 

SA_Relevant <- SA %>% 
  inner_join(ID)  %>% 
  filter(Assessment %in% c("Close", "Constant", "Protective", "1:1"),
         Facility %in% c("Evins", "Gainesville", "Giddings", "Mart", "Ron Jackson"))

HR_Relevant <- HR %>% 
  left_join(Employment_Spells %>% 
              group_by(Empl_ID) %>% 
              summarize_all(last) %>% 
              mutate(Last_Term_Month = if_else(is.na(Last_Term_Month), today(), Last_Term_Month))) %>% 
  filter(str_detect(Job_Title, "JCO"),
         Facility %in% c("Evins", "Gainesville", "Giddings", "Mart", "Ron Jackson")) %>% 
  mutate(Tenure = Month - Last_Hire,
         In_Training = Tenure <= 90,
         Available = (Hire == 0 & Term == 0 & Hours_Leave < 96 & In_Training == FALSE))

#By facility month

Masterfiles <- MF_Get()

Determinate <- Masterfiles %>% 
  filter(!is.na(Determinate_Sentence)) %>% 
  group_by(TJJD_Number) %>% 
  summarize_all(last) %>% 
  select(TJJD_Number, Determinate_Sentence)

Incidents_by_Facility_Month <- Incidents_Relevant %>% 
  inner_join(Determinate) %>% 
  group_by(Determinate_Sentence, 
           Month = floor_date(Incident_Date, "month"),
           Facility) %>% 
  summarize(across(c(Assault_On_Staff:Use_Of_Chemical_Agent, Any_Mechanical_Restraint, RSU_Referral), sum)) %>% 
  ungroup()

RSU_by_Facility_Month <- RSU_Relevant %>% 
  group_by(Sex,
           Month = floor_date(RSU_Detention_End_Date, "month"),
           Facility) %>% 
  summarize(RSU_Admission = n(),
            Average_RSU_Stay_Hours = mean(RSU_Detention_Duration_Hours)) %>% 
  ungroup()

HR_by_Facility_Month <- HR_Relevant %>% 
  group_by(Month, Facility) %>% 
  summarize(Total_JCOs = n_distinct(Empl_ID),
            Available_JCOs = sum(Available),
            Net_JCO_Hires = sum(Hire) - sum(Term)) %>% 
  ungroup()

SA_by_Facility_Month <- SA_Relevant %>% 
  group_by(Sex,
           Month = floor_date(Assessment_Date, "month"),
           Facility) %>% 
  summarize(Suicide_Alerts = n(),
            Suicide_Alerts_with_Self_Harm = sum(Self_Harm_Behavior, na.rm = TRUE)) %>% 
  ungroup()

Metrics_by_Facility_Month <- Incidents_by_Facility_Month %>% 
  full_join(RSU_by_Facility_Month) %>% 
  full_join(SA_by_Facility_Month) %>% 
  full_join(HR_by_Facility_Month) %>% 
  filter(Month >= Start_Date,
         Month <= End_Date)

write_csv(Metrics_by_Facility_Month, str_c("Metrics by Facility and Month ", today(), ".csv"))

#By FY

L2 <- L2_Hearings_Get()

Injurious <- L2 %>%
  mutate(FY = State_FY(Hearing_Date)) %>%
  filter(str_detect(Hearing_Offense_Description, "CAUSING"),
         FY >= 2019,
         FY <= End_FY,
         is.na(Reversed_On_Appeal),
         Hearing_Offense_Proven == "Y") %>%
  mutate(Staff = str_detect(Hearing_Offense_Description, "STAFF"),
         Youth = str_detect(Hearing_Offense_Description, "YOUT|YTH"))

Injurious_Upheld_by_FY <- Injurious %>%
  group_by(FY) %>%
  summarize(Injurious_Staff_Upheld = sum(Staff),
            Injurious_Youth_Upheld = sum(Youth)) %>%
  ungroup()

Incidents <- Incidents_Get()

Incident_RV <- Incident_Rule_Violations_Get()

Injurious_by_FY <- Incidents %>% 
  inner_join(Incident_RV %>% 
              filter(str_detect(Description, "Causing"))) %>%
  mutate(FY = State_FY(Incident_Date)) %>%
  filter(FY >= 2019,
         FY <= 2023) %>% 
  count(FY, Description)

Incidents_by_FY <- Incidents %>%
  group_by(FY = State_FY(Incident_Date)) %>%
  summarize(across(c(Assault_On_Staff:Use_Of_Chemical_Agent, Any_Mechanical_Restraint, RSU_Referral), sum)) %>%
  ungroup()

RSU_by_FY <- RSU_Relevant %>%
  group_by(FY = State_FY(RSU_Detention_End_Date)) %>%
  summarize(RSU_Admission = n()) %>%
  ungroup()

HR_Monthly_Averages <- HR_Relevant %>%
  group_by(Month) %>%
  summarize(Total_JCOs = n_distinct(Empl_ID),
            Available_JCOs = sum(Available)) %>%
  ungroup() %>%
  group_by(FY = State_FY(Month),
           FQ = State_FQ(Month)) %>%
  summarize(Average_Monthly_Total_JCO_FTE = mean(Total_JCOs),
            Average_Monthly_JCO_Strength = mean(Available_JCOs)) %>%
  ungroup()

HR_by_FQ <- HR_Relevant %>%
  group_by(FY = State_FY(Month),
           FQ = State_FQ(Month)) %>%
  summarize(Unique_JCOs = n_distinct(Empl_ID),
            Hires = sum(Hire),
            Terms = sum(Term),
            Ninety_Day_Losses = sum(In_Training & Term == 1),
            Floor_Losses = sum(!In_Training & Term == 1),
            Net_JCO_Hires = sum(Hire) - sum(Term)) %>%
  ungroup() %>%
  filter(FY >= 2019) %>%
  inner_join(HR_Monthly_Averages)

Statuses <- Statuses_Get(Source = "sql")

Statuses %>%
  filter(is.na(TYCNO))
HR_by_FY <- HR_Relevant %>%
  group_by(FY = State_FY(Month)) %>%
  summarize(Unique_JCOs = n_distinct(Empl_ID),
            Hires = sum(Hire),
            Terms = sum(Term),
            Ninety_Day_Losses = sum(In_Training & Term == 1),
            Floor_Losses = sum(!In_Training & Term == 1),
            Net_JCO_Hires = sum(Hire) - sum(Term)) %>%
  ungroup() %>%
  filter(FY >= 2019) %>%
  inner_join(HR_Monthly_Averages)

SA_by_FY <- SA_Relevant %>%
  group_by(FY = State_FY(Assessment_Date)) %>%
  summarize(Suicide_Alerts = n(),
            Suicide_Alerts_with_Self_Harm = sum(Self_Harm_Behavior, na.rm = TRUE)) %>%
  ungroup()

Metrics_by_FY <- Incidents_by_FY %>%
  full_join(RSU_by_FY) %>%
  full_join(SA_by_FY) %>%
  full_join(HR_by_FY) %>%
  full_join(Injurious_by_FY) %>%
  filter(FY >= 2019,
         FY <= End_FY) %>%
  pivot_longer(-FY, names_to = "Metric", values_to = "Value")

write_csv(Metrics_by_FY, str_c("Metrics by Fiscal Year ", today(), ".csv"))

# Metrics_by_Facility_Month_Long <- Metrics_by_Facility_Month %>%
#   pivot_longer(-c(Month, Facility), names_to = "Metric", values_to = "Value") %>%
#   mutate(Subcategory = case_when(str_detect(Metric, "Restraint|Agent") ~ "Restraint",
#                               str_detect(Metric, "Self") ~ "Self-Harm",
#                               str_detect(Metric, "Suicide") ~ "Suicide Alerts",
#                               str_detect(Metric, "Assault") ~ "Assault",
#                               str_detect(Metric, "RSU_Referral|RSU_Admission") ~ "RSU Referrals and Admissions",
#                               str_detect(Metric, "RSU_Stay") ~ "RSU Duration",
#                               str_detect(Metric, "Total_JCO|Available_JCO") ~ "Staff Strength",
#                               str_detect(Metric, "Hire|Termination") ~ "Hires and Terminations"),
#          Category = case_when(str_detect(Subcategory, "RSU") ~ "RSU",
#                               str_detect(Subcategory, "Staff|Hire") ~ "Staffing",
#                               str_detect(Subcategory, "Assault|Restraint") ~ "Violence",
#                               str_detect(Subcategory, "Suicide|Self-Harm") ~ "Self Harm")
#   )
#
# Facilities_Categories <- Metrics_by_Facility_Month_Long %>%
#   select(Facility, Category) %>%
#   unique()
#
# Produce_Graphs <- function(Location, Metric_Category) {
#
#   Metric_Graph <- Metrics_by_Facility_Month_Long %>%
#   filter(Facility == Location,
#          Category == Metric_Category) %>%
#   ggplot(aes(x = Month, y = Value, color = Metric)) +
#   geom_line() +
#   ggtitle(Location, subtitle = Metric_Category) +
#   facet_grid(rows = vars(Subcategory), scales = "free_y") +
#   ylim(0, NA)
#
#   ggsave(str_c("Produced Datasets/", Location, " - ", Metric_Category, ".png"), width = 8, height = 10.5, units = "in")
# }
#
# map2(Facilities_Categories$Facility, Facilities_Categories$Category, Produce_Graphs)

#Push out separately, use GGsave, calculate increased / decreased



