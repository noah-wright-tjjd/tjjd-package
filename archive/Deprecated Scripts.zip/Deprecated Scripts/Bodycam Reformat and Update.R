library(TJJD)

Past_30 <- map_df(seq.Date(today()-31, today(), "day"), Axon_Bodycam_Log_Get)

Past_30_Format <- Past_30 %>% 
  group_by(Evidence_ID) %>% 
  summarize_all(first) %>% 
  arrange(Clip_Start) %>% 
  mutate(Clip_Start = as.POSIXct(Clip_Start),
         Clip_End = as.POSIXct(Clip_End)) %>% 
  group_by(Serial_Number, Employee_ID) %>% 
  mutate(Gap_From_Previous_Clip = replace_na(if_else(lag(Clip_End) > Clip_Start, 
                                                     0, 
                                                     as.numeric(Clip_Start - lag(Clip_End))),
                                             0)
) %>% 
  ungroup()

Past_30_by_Hour <- Past_30_Format %>% 
  select(-Gap_From_Previous_Clip) %>% 
  filter(is.na(Clip_End) == FALSE) %>% 
  Interval_Convert.Posix(Clip_Start, Clip_End, "hour") %>% 
  mutate(Hour_of_Start = hour(Interval_Start),
         Date_of_Start = as.Date(Interval_Start),
         Minutes_of_Hour = Duration_Seconds/60)

write_csv(Past_30_Format, "Data Sources/Axon Bodycam Logs/Past 30 Days Clips.csv")
write_csv(Past_30_by_Hour, "Data Sources/Axon Bodycam Logs/Past 30 Days Clips - by Hour.csv")

Bodycam_Monthly_Past <- read_csv("Data Sources/Axon Bodycam Logs/Footage by Month.csv", lazy = FALSE)

Last_Update <- max(Bodycam_Monthly_Past$Clip_Month)

Update_Span <- seq.Date(floor_date(Last_Update + 31, "month"), floor_date(today(), "month") - 1, "day")

Monthly_Update <- map_df(Update_Span, Axon_Bodycam_Log_Get)

Bodycam_Monthly <- Past_30 %>% 
  group_by(Clip_Month = floor_date(Date_Clip_Start, 'month'), Employee_ID, Serial_Number) %>% 
  summarize(Hours_Recorded = sum(Hours_Duration)) %>% 
  bind_rows(Bodycam_Monthly_Past)

write_csv(Bodycam_Monthly %>% 
            filter(Clip_Month < "2022-06-01"), "Data Sources/Axon Bodycam Logs/Footage by Month.csv")