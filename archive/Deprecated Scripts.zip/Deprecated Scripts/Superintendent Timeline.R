library(TJJD)
library(vistime)

Data_Request("Superintendent Timeline")

Job_History <- CAPPS_Job_History_Get()

Leaders_Update <- Job_History %>% 
  mutate(Job_Title = if_else(str_detect(Job_Title, "Clin Dir Forensic MH|Mgr Inst Clncl Svcs|Psychologist"), "DOC", Job_Title)) %>% 
  filter(str_detect(Job_Title, "Facility Super|Facility Supt|Facility Asst Supt|DOC"),
         !str_detect(Name, "Armando|Martha|Peller|Danuta|Hallmark|Saulter|Townsend|Kuck|Campbell|Randle|Litke|Nemons")) %>% 
  group_by(Job_Title, Facility, Empl_ID) %>% 
  filter(End_Date >= "2024-09-01") %>% 
  summarize(Name = last(Name),
            Start = min(Start_Date),
            End = max(End_Date)) |> 
  ungroup()

Leaders <- read_excel("Leaders.xlsx")

Facilities <- Leaders$Facility %>% unique()

map(Facilities, ~gg_vistime(data = Leaders %>% 
                              filter(Facility == .x), 
                            col.event = "Name", 
                            col.start = "Start", 
                            col.end = "End", 
                            col.group = "Job_Title",
                            title = .x) %>% 
      ggsave(filename = str_c(.x, ".png"),
             width = 12, height = 4, units = "in"))

#Former Query:
# 
# Leaders <- Job_History %>% 
#   mutate(Job_Title = if_else(str_detect(Job_Title, "Clin Dir Forensic MH|Mgr Inst Clncl Svcs|Psychologist"), "DOC", Job_Title)) %>% 
#   filter(str_detect(Job_Title, "Facility Super|Facility Supt|Facility Asst Supt|DOC"),
#          !str_detect(Name, "Armando|Martha|Peller|Danuta|Hallmark|Saulter|Townsend|Kuck|Campbell|Randle|Litke|Nemons")) %>% 
#   group_by(Job_Title, Facility, Empl_ID) %>% 
#   filter(End_Date >= "2018-09-01") %>% 
#   summarize(Name = last(Name),
#             Start = min(Start_Date),
#             End = max(End_Date)) %>% 
#   ungroup() %>% 
#   mutate(Start = if_else(Facility == "Gainesville" & str_detect(Name, "Parks"), as.Date("2019-01-07"), 
#                          if_else(Facility == "Giddings" & str_detect(Name, "Norton"), as.Date("2018-11-01"), Start)),
#          Facility = if_else(Facility == "Gainesville" & str_detect(toupper(Name), "BROWN,JEN") & str_detect(Job_Title, "Super"), "Evins", Facility),
#          Job_Title = str_remove(Job_Title, "Youth "),
#          Job_Title = if_else(str_detect(Name, "Autumn") & str_detect(Job_Title, "Supt"), "Facility Superintendent", Job_Title)) %>% 
#   arrange(Facility, Job_Title, Start) %>% 
#   group_by(Facility, Job_Title) %>% 
#   mutate(Start = if_else(Start <= "2018-09-01", as.Date("2018-09-01"), Start),
#          End = if_else(is.na(lead(Start)), End, 
#                        if_else(End > lead(Start), lead(Start) - 1, End)),
#   ) %>% 
#   ungroup() %>% 
#   arrange(desc(Job_Title), Facility, Start)