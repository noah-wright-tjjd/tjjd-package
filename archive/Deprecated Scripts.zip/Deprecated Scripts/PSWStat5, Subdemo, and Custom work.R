library(TJJD)

PSWStat5 <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=URD033",rows_at_time=1),
                        "SELECT * FROM pswstat5")

Subdemo <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=URD033",rows_at_time=1),
                     "SELECT * FROM subdemo")

PSW_Match <- read_excel("Remainder.xlsx") %>% 
  mutate(across(contains("DATE"), ~as.Date(.x, "%m/%d/%Y")),
         across(everything(), as.character)) %>% 
  pivot_longer(-c(TYCNO, NAME), names_to = "Custom_Var", values_to = "Value")

PSW_Table <- PSWStat5 %>% 
  mutate(across(contains("MDY"), ~as.Date(.x, origin = "1960-01-01")),
         across(everything(), as.character)) %>% 
  pivot_longer(-c(TYCNO, NAME), names_to = "PSW_Var", values_to = "Value")

Matches <- PSW_Match %>%
#  filter(!Value %in% c("NO", "YES", "Y", 0),
#         !is.na(Value)) %>% 
  inner_join(PSW_Table) %>% 
  count(Custom_Var, PSW_Var) %>% 
  filter(n == 931) 

First_Pass_Missing <- Matches %>% 
  group_by(Custom_Var) %>% 
  filter(max(n) < 931) %>% 
  ungroup()

Matches <- PSW_Match %>%
  #  filter(!Value %in% c("NO", "YES", "Y", 0),
  #         !is.na(Value)) %>% 
  inner_join(PSW_Table) %>% 
  count(Custom_Var, PSW_Var) %>% 
  arrange(Custom_Var, -n) %>% 
  semi_join(First_Pass_Missing)


Subdemo_Skim <- Subdemo %>% 
skim()
