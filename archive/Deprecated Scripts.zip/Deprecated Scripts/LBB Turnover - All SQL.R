library(TJJD)

Employee_Summary <- Employee_Summary_Get()

Employees_Monthly <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=TYCEmployees",rows_at_time=1),
"SELECT Date, ccsloccode as CCS_Location_Code, count(TINSID) AS Coaches, 
count(CASE WHEN Start_Month=Date
THEN 1
END) AS Hires,
count(CASE WHEN End_Month=Date
THEN 1
END) AS Terminations
FROM
(SELECT TINSID, PG2.FullName, LastHireDate AS Initial_Hire_Date, RehireDate,
CASE WHEN Cast(rehiredate AS DATE)>LastHireDate
THEN dateadd(month,datediff(month,0,rehiredate),0)
ELSE dateadd(month,datediff(month,0,LastHireDate),0)
END 
AS Start_Month, 
dateadd(month,datediff(month,0,isnull(PG2.TerminationDate, '2099-12-31')),0) 
AS End_Month,
JobCodeDescription, CCSLocCode, PG2.Location
FROM vCAPPS_PG2_JOB_CURR PG2
LEFT JOIN CAPPS_CEI_Empl CEI
on PG2.TINSID = CEI.Emplid
WHERE JobCodeDescription LIKE '%JCO%') EMP
INNER JOIN (SELECT Date
            FROM DATE_CALENDAR
            where DAY = 1 and YEAR>2019 and Date<GETDATE()) CAL
on EMP.Start_Month <= CAL.Date and EMP.End_Month >= CAL.Date
group by Date, ccsloccode")

Employees_Quarterly <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=TYCEmployees",rows_at_time=1),
"SELECT State_Fiscal_Quarter, State_Fiscal_Year, ccsloccode as CCS_Location_Code, count(DISTINCT TINSID) AS Coaches,
count(CASE WHEN Start_Month=Date
THEN 1
END) AS Hires,
count(CASE WHEN End_Month=Date
THEN 1
END) AS Terminations
FROM
(SELECT TINSID, PG2.FullName, LastHireDate AS Initial_Hire_Date, RehireDate,
CASE WHEN Cast(rehiredate AS DATE)>LastHireDate
THEN dateadd(month,datediff(month,0,rehiredate),0)
ELSE dateadd(month,datediff(month,0,LastHireDate),0)
END 
AS Start_Month, 
dateadd(month,datediff(month,0,isnull(PG2.TerminationDate, '2099-12-31')),0) 
AS End_Month,
JobCodeDescription, CCSLocCode, PG2.Location
FROM vCAPPS_PG2_JOB_CURR PG2
LEFT JOIN CAPPS_CEI_Empl CEI
on PG2.TINSID = CEI.Emplid
WHERE JobCodeDescription LIKE '%JCO%') EMP
INNER JOIN (SELECT *
FROM DATE_CALENDAR
                     where DAY = 1 and STATE_FISCAL_YEAR>2019 and Date<GETDATE()) CAL
on EMP.Start_Month <= CAL.Date and EMP.End_Month >= CAL.Date
group by State_Fiscal_Quarter, State_Fiscal_Year, ccsloccode")

Employees_Quarterly %>% 
  rename(Location_Code = CCS_Location_Code) %>% 
  left_join(Location_Type_Lookup) %>% 
  select(Facility) %>% 
  unique()
