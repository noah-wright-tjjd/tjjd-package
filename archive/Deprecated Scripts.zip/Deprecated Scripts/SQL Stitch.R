library(TJJD)
library(dbplyr)

Placements <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=stargazer;database=juvenilecaseextract",rows_at_time=1), 
                                "select * from tblplacements")

Multiples <- Placements %>% 
  count(HQCountyNumber, PIDNumber, ReferralNumber, PlacementFacility) %>% 
  filter(n>1) %>% 
  inner_join(Placements)

Translation <- translate_sql(Placements %>% 
                               group_by(HQCountyNumber, PIDNumber, ReferralNumber, PlacementFacility) %>% 
                               mutate(Continuity = if_else(PlacementDateOut == lead(PlacementDateIn) | 
                                                             (PlacementDateOut + 1) == lead(PlacementDateIn) | 
                                                             PlacementDateIn == lag(PlacementDateOut) | 
                                                             PlacementDateIn == lag(PlacementDateOut) + 1,
                                                           1, 0)) %>% 
                               group_by(HQCountyNumber, PIDNumber, ReferralNumber, PlacementFacility, Continuity) %>% 
                               summarize(PlacementDateIn = min(PlacementDateIn),
                                         PlacementDateOut = max(PlacementDateOut)) %>% 
                               ungroup()
)

Stitch_SQL <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=stargazer;database=juvenilecaseextract",rows_at_time=1), 
                       "select
                      CASE WHEN ('PlacementDateOut' = LEAD('PlacementDateIn', 1, NULL) OVER () OR ('PlacementDateOut' + 1.0) = LEAD('PlacementDateIn', 1, NULL) OVER () OR 'PlacementDateIn' = LAG('PlacementDateOut', 1, NULL) OVER () OR 'PlacementDateIn' = (LAG('PlacementDateOut', 1, NULL) OVER () + 1.0)) THEN 1
                      WHEN NOT ('PlacementDateOut' = LEAD('PlacementDateIn', 1, NULL) OVER () OR ('PlacementDateOut' + 1.0) = LEAD('PlacementDateIn', 1, NULL) OVER () OR 'PlacementDateIn' = LAG('PlacementDateOut', 1, NULL) OVER () OR 'PlacementDateIn' = (LAG('PlacementDateOut', 1, NULL) OVER () + 1.0)) THEN 0
                      END AS 'Continuity'), 
                      'HQCountyNumber', 
                      'PIDNumber', 
                      'ReferralNumber', 
                      'PlacementFacility', 
                      'Continuity'), 
                      MIN('PlacementDateIn') OVER () AS 'PlacementDateIn', 
                      MAX('PlacementDateOut') OVER () AS 'PlacementDateOut')
                      from tblplacements")