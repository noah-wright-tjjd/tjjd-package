library(TJJD)

Noble <- odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avnobsql1;database=NSGCMS_TX_TJJD_JUVENILE;Trusted_Connection=yes;TrustServerCertificate=yes",rows_at_time=1)

View <- sqlQuery(Noble, "select top 10000 *
                       from VW_NSG_REPORTING__SCORES_BY_FACTOR")

Form_Instance<-sqlQuery(Noble, "select SUBJECT_ID_FK as SUBJECT_ID, FORM_ID_FK as FORM_ID, FORM_INSTANCE_ID, CREATED_DATE, MODIFIED_DATE
                       from NSG_FORM_INSTANCE")

CP_Instance<-sqlQuery(Noble, "select SUBJECT_ID_FK as SUBJECT_ID, CASE_PLAN_ID_FK as CASE_PLAN_ID, CASE_PLAN_INSTANCE_ID, SCORE_GROUP_ID_FK as SCORE_GROUP_ID, DATE_STARTED as DATE_CP_STARTED, DATE_COMPLETED as DATE_CP_COMPLETED
                       from NSG_CASE_PLAN_INSTANCE")

Subject_Information<-sqlQuery(Noble, "SELECT SUBJECT_ID, EID as TJJD_Number
                             FROM NSG_SUBJECT")
Form_Lookup<-sqlQuery(Noble, "SELECT FORM_ID, NAME as FORM_NAME
                     FROM NSG_FORM")

  
Factor_Score<-sqlQuery(Noble, "SELECT FACTOR_SCORE_ID, FORM_INSTANCE_ID_FK AS FORM_INSTANCE_ID, FORM_SCORE_TARGET_ID_FK AS FORM_SCORE_TARGET_ID, FACTOR_ID_FK as FACTOR_ID, SCORE, RAW_SCORE, PERCENT_OF_MAX as PERCENT_OF_MAX_FACTOR_SCORE
                     FROM NSG_FORM_INSTANCE_FORM_CP_FACTOR_SCORE")

Factor_Score_Group <-sqlQuery(Noble, "SELECT SCORE_GROUP_ID, SUBJECT_ID_FK as SUBJECT_ID
                     FROM NSG_SUBJECT_CP_FACTOR_SCORE_GROUP")

Factor_Score_Form_Instance<-sqlQuery(Noble, "SELECT SCORE_GROUP_FORM_INSTANCE_ID, SCORE_GROUP_ID_FK as SCORE_GROUP_ID, FORM_INSTANCE_ID_FK as FORM_INSTANCE_ID
                     FROM NSG_SUBJECT_CP_FACTOR_SCORE_GROUP_FORM_INSTANCE")

Factor_Lookup<-sqlQuery(Noble, "select FACTOR_ID, FACTOR_TYPE_ID_FK as FACTOR_TYPE_ID, FACTOR_CATEGORY_ID_FK as FACTOR_CATEGORY_ID, NAME as FACTOR from
          NSG_CP_FACTOR")

Case_Plan_Lookup<-sqlQuery(Noble, "select CASE_PLAN_ID, NAME as CASE_PLAN from
          NSG_CASE_PLAN")

Factor_Type_Lookup<-sqlQuery(Noble, "select FACTOR_TYPE_ID, DISPLAY_NAME as FACTOR_TYPE from
          NSG_CP_FACTOR_TYPE_LOOKUP")

Factor_Category_Lookup<-sqlQuery(Noble, "select FACTOR_CATEGORY_ID, DISPLAY_NAME as FACTOR_CATEGORY from
          NSG_CP_FACTOR_CATEGORY_LOOKUP")

Factor_Category_Family_Lookup<-sqlQuery(Noble, "select CATEGORY_FAMILY_ID, DISPLAY_NAME as FACTOR_CATEGORY_FAMILY from
          NSG_CP_FACTOR_CATEGORY_FAMILY_LOOKUP")

Result <- Form_Instance %>%
         inner_join(Subject_Information) %>%
         inner_join(Form_Lookup) %>%
         inner_join(Factor_Score_Form_Instance) %>%
  inner_join(Factor_Score_Group) %>% 
         inner_join(Factor_Score)  %>%
         inner_join(Factor_Lookup) %>%
         inner_join(Factor_Category_Lookup) %>%
         inner_join(Factor_Type_Lookup) %>% 
  inner_join(CP_Instance)
#         select(-FORM_ID, -FACTOR_TYPE_ID,-FACTOR_CATEGORY_ID,-FACTOR_ID)

Duplicates <- Result %>% 
  group_by(FORM_INSTANCE_ID, FACTOR_CATEGORY_ID, FACTOR_TYPE_ID) %>% 
  filter(n() > 1)

Duplicate_Check <- Duplicates %>% 
  group_by(FORM_INSTANCE_ID, FACTOR_CATEGORY_ID, FACTOR_TYPE_ID, FACTOR_SCORE_ID) %>% 
  filter(n() > 1)

#Factor score ID makes unique
#Score group ID also makes unique

#wtf is a score group