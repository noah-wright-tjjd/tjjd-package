Assignments_by_Day <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=IRD035",rows_at_time=1),
         "
         select * from
         (SELECT Date, LOC as Location_Code, count(TYCNO) as Assignments 
         from DateCalendar 
         inner join POPASFixed
           on DateCalendar.SASDate >= POPASFixed.ASMDY 
         and DateCalendar.SASDate <= POPASFixed.EASMDY
         where DateCalendar.Date >= '2020-01-01'
         and DateCalendar.Date <= '2020-01-31'
         group by Date, LOC) ASN
         left join
         (select Date, Location_Code, ESC, DET, FRLO, JAIL from 
                               (SELECT Date, LOC as Location_Code, STTYPE, count(TYCNO) as Youth 
         from DateCalendar 
         inner join POPST
           on DateCalendar.SASDate >= POPST.STMDY 
         and DateCalendar.SASDate <= POPST.ENDMDY
         where DateCalendar.Date >= '2020-01-01'
         and DateCalendar.Date <= '2020-01-31'
         and STTYPE <> 'SEC'
         group by Date, LOC, STTYPE) as STAT
          PIVOT (
          sum(Youth)
          for STTYPE IN (ESC, DET, FRLO, JAIL, ABS)
                            ) as Piv) STA
         on ASN.Date = STA.Date 
         and ASN.Location_Code = STA.Location_Code
        ") 

Statuses_by_Day <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=IRD035",rows_at_time=1),
                               "select Date, Location_Code, ESC, DET, FRLO, JAIL from 
                               (SELECT Date, LOC as Location_Code, STTYPE, count(TYCNO) as Youth 
         from DateCalendar 
         inner join POPST
           on DateCalendar.SASDate >= POPST.STMDY 
         and DateCalendar.SASDate <= POPST.ENDMDY
         where DateCalendar.Date >= '2020-01-01'
         and DateCalendar.Date <= '2020-01-31'
         and STTYPE <> 'SEC'
         group by Date, LOC, STTYPE) as STA
          PIVOT (
          sum(Youth)
          for STTYPE IN (ESC, DET, FRLO, JAIL, ABS)
                            ) as Piv") 

Deported_by_Day <- sqlQuery(odbcDriverConnect(connection="Driver=SQL Server;server=tjjd4avsql;database=IRD035",rows_at_time=1),
                            "select * from
         (SELECT Date, LOC as Location_Code, count(DISTINCT TYCNO) as Assignments 
         from DateCalendar 
         inner join POPASFixed
           on DateCalendar.SASDate >= POPASFixed.ASMDY 
         and DateCalendar.SASDate <= POPASFixed.EASMDY
         where DateCalendar.Date >= '2014-01-01'
         and DateCalendar.Date <= GETDATE()
         group by Date, LOC) ASN
         left join
         (select Date, Location_Code, ABS, ESC, DET, FRLO, JAIL from 
                               (SELECT Date, LOC as Location_Code, STTYPE, count(DISTINCT TYCNO) as Youth 
         from DateCalendar 
         inner join POPST
           on DateCalendar.SASDate >= POPST.STMDY 
         and DateCalendar.SASDate <= POPST.ENDMDY
         where DateCalendar.Date >= '2014-01-01'
         and DateCalendar.Date <= GETDATE()
         and STTYPE <> 'SEC'
         group by Date, LOC, STTYPE) as STAT
          PIVOT (
          sum(Youth)
          for STTYPE IN (ESC, DET, FRLO, JAIL, ABS)
                            ) as Piv) STA
         on ASN.Date = STA.Date 
         and ASN.Location_Code = STA.Location_Code") 
