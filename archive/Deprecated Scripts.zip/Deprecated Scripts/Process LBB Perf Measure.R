library(TJJD)
library(pdftools)

Strategy <- pdf_text("Strategy.pdf")

Strategy_Format <- data.frame(Raw = read_lines(Strategy))

Outcome <- pdf_text("Outcome.pdf")

Outcome_Format <- data.frame(Raw = read_lines(Outcome))

All_Format <- Strategy_Format %>% 
  mutate(Type = "Strategy") %>% 
  bind_rows(Outcome_Format %>% 
              mutate(Type = "Outcome"))

Top_Vars <- c("Goal No.", "Objective No.", "Outcome No.", "Strategy No.", "Measure Type", "Measure No.")

Head_Vars <- c("Calculation Method", "Target Attainment", "Priority", "Key Measure", "New Measure", "Percentage Measure", "Percent Measure", "Cross Reference") 

Def_Vars <- c("BL 2024 Definition", "BL 2024 Data Limitations", "BL 2024 Data Source", "BL 2024 Methodology", "BL 2024 Purpose")

Top_Lines <- map_df(Top_Vars, function(x) {
  
  All_Format %>% 
    filter(str_detect(Raw, x)) %>% 
    mutate(Var = x,
           Content = str_trim(str_remove_all(str_squish(Raw), x))) %>% 
    group_by(Type) %>% 
    mutate(Page = row_number()) %>% 
    ungroup()
  }
  ) %>% 
  select(-Raw) %>% 
  pivot_wider(names_from = Var, values_from = Content)

Head_Line_1 <- All_Format %>% 
    filter(str_detect(Raw, "Calculation Method")) %>% 
    group_by(Type) %>% 
    mutate(Page = row_number()) %>% 
    ungroup() %>% 
    mutate(Content = str_remove_all(str_trim(str_squish(Raw)), str_c(Head_Vars, collapse = "|"))) %>% 
    separate(Content, c("Blank", "Calculation Method", "Target Attainment", "Priority"), sep = ":") %>% 
  select(-Raw, -Blank)

Head_Line_2 <- All_Format %>% 
  filter(str_detect(Raw, "Key Measure")) %>% 
  group_by(Type) %>% 
  mutate(Page = row_number()) %>% 
  ungroup() %>% 
  mutate(Content = str_remove_all(str_trim(str_squish(Raw)), str_c(Head_Vars, collapse = "|"))) %>% 
  separate(Content, c("Blank", "Key Measure", "New Measure", "Percent Measure"), sep = ":") %>% 
  select(-Raw, -Blank)

Reformat <- All_Format %>% 
  mutate(Content = str_trim(str_squish(Raw)),
         Line = row_number(),
         Indicator = str_detect(Raw, str_c(Def_Vars, collapse = "|")),
         Page_Mark = str_detect(Raw, "Page|OBJECTIVE OUTCOME"))

Inds <- which(Reformat$Indicator)
Page_Marks <- which(Reformat$Page_Mark)

Stops <- unlist(map(Inds, ~Inds[Inds>.x][1]))

Purpose_Stops <- unlist(map(Inds, ~Page_Marks[Page_Marks>.x][1]))

Index <- data.frame(Start = Inds + 1,
                    Stop = Stops,
                    Purpose_Stop = Purpose_Stops) %>% 
  mutate(Line = row_number(),
         Purpose_Stop = if_else(Line == 405, Start + 2, Purpose_Stop))

Index_Fix <- Index %>% 
  mutate(End = if_else(Line %% 5 == 0, Purpose_Stop, Stop) - 1) %>% 
  select(Start, End) %>% 
  arrange(Start)

Def_Lines <- map2_df(Index_Fix$Start, Index_Fix$End, function(y, z) {
  Reformat %>% 
    slice(y:z) %>% 
    group_by(Type) %>% 
    summarize(Val = str_c(Content, collapse = " ")) %>% 
    ungroup()
}
) %>% 
  bind_cols(Var = rep(Def_Vars, 81)) %>% 
  group_by(Var, Type) %>% 
  mutate(Page = row_number()) %>% 
  ungroup() %>% 
  pivot_wider(names_from = Var, values_from = Val)

#Purpose still not working for outcome

Performance_Measures <- Top_Lines %>% 
  inner_join(Head_Line_1) %>% 
  inner_join(Head_Line_2) %>% 
  inner_join(Def_Lines)

write_csv(Performance_Measures, "Performance Measures - Table.csv", na = "")
