source("R/DB/IRD035.R")

IDADDR <- sqlQuery(IRD035, "select * from IDADDR")
IDHOME <- sqlQuery(IRD035, "select * from IDHOME")
ID <- sqlQuery(IRD035, "select * from ID")

Current_Youth <- Assignments_Get() %>% 
  filter(Assignment_End_Date == "2099-12-31")

PopSheet <- Metrics_Pop_Sheet()

Sheet <- PopSheet %>% 
  inner_join(IDHOME %>% select(TJJD_Number = TYCNO, HMZIP)) %>% 
  mutate(Zipcode = str_sub(HMZIP, 1, 5))

#Include Statuses or no?

County_Secure <- Sheet %>% 
  filter(is.na(Status_Type) | Status_Type == "FRLO",
         Location_Type %in% c("Secure", "O & A"),
         !is.na(Commitment_County))

POPM <- sqlQuery(IRD035, "select * from POPM where TYCNO > 1300000")

AssignedByCounty <- Sheet %>% 
  filter(is.na(Commitment_County)) %>% 
  inner_join(POPM %>%
               select(TJJD_Number = TYCNO, CMTCTY) %>% 
               left_join(County_Code_Lookup,by=c("CMTCTY"="COUNTYCODE"))) %>% 
  select(TJJD_Number, Commitment_County = COUNTYNAME) %>% 
  bind_rows(County_Secure) %>% 
  count(Commitment_County)

write_csv(AssignedByCounty, "Youth in Secure by Commitment County.csv")

HouseZip <- read_excel("House_Zip.xls") %>% 
  group_by(District, Zip) %>% 
  summarize(Pop_Perc = sum(Pop_Perc, na.rm = TRUE),
            Pop = sum(Pop, na.rm = TRUE)) %>% 
  ungroup() %>% 
  filter(!(Pop_Perc == 0 & Pop == 0)) %>% 
  mutate(Pop_Perc = if_else(Pop_Perc == 0, 1, Pop_Perc))

AssignedByHouseDistrict <- Sheet %>% 
  filter(Location_Type %in% c("O & A", "Secure"),
         is.na(Status_Type) | Status_Type == "FRLO") %>% 
  count(Zip = Zipcode) %>% 
  inner_join(HouseZip %>% 
               filter(Pop_Perc > .5)) %>% 
  group_by(District) %>% 
  summarize(Youth = sum(n[Pop_Perc == 1])) %>% 
  ungroup() %>% 
  filter(Youth > 0)

write_csv(AssignedByHouseDistrict, "TJJD Youth in Secure by House District.csv")
