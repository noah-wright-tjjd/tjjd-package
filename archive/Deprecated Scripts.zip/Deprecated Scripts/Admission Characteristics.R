Employees <- Employee_Summary_Get()

NewAdmissions <- MF %>% 
  filter(Commitment_Type == "CMNT") %>% 
  group_by(TJJD_Number) %>% 
  summarize_all(first) %>% 
  ungroup()

Offenses_Ind <- NewAdmissions %>% 
  select(TJJD_Number, Determinate_Sentence) %>%
  filter(Determinate_Sentence == "N") %>% 
  inner_join(Risk_MLOS %>% 
               rename(TJJD_Number = tycno)) %>% 
  select(TJJD_Number, Referrals = refs, Adjudications = ajds)


#Question: I removed INMDY which came with the All_Intakes table bc. it wasn't used in the creation of this
Offense_History_Det <- NewAdmissions %>% 
  select(TJJD_Number, Admission_Date, Determinate_Sentence) %>% 
  left_join(Offense_History) %>% 
  filter(Referral_Date <= Admission_Date,
         Determinate_Sentence == "Y") %>% 
  mutate(Adjudication_Offense_Level = if_else(Disposition_Code %in% c('AP','AT','CA','PT','ND','AD') & !is.na(Adjudication_Date) & is.na(Adjudication_Offense_Level), 
                                              if_else(is.na(Referral_Offense_Level), as.integer(3), Referral_Offense_Level),
                                              Adjudication_Offense_Level),
         Adjudication_Offense = if_else(Disposition_Code %in% c('AP','AT','CA','PT','ND','AD') & !is.na(Adjudication_Date) & is.na(Adjudication_Offense),
                                        Referral_Offense, Adjudication_Offense),
         N_Ref_Level = if_else(Referral_Offense_Code %in% c(7340, 7350), Adjudication_Offense_Level, Referral_Offense_Level),
         N_Ref_Code = if_else(Referral_Offense %in% c(7340, 7350), Adjudication_Offense, Referral_Offense))

Offenses_Det <- Offense_History_Det %>% 
  group_by(TJJD_Number) %>% 
  summarize(Referrals = sum(Referral_Offense_Level <= 2),
            Adjudications = sum(Adjudication_Offense_Level<=2 & Disposition_Code %in% c('AP','AT','CA','PT','ND','AD')))

Offenses_All <- On_Probation_at_Commitment %>% 
  rename(TJJD_Number = TYCNO,
         Probation_at_Commitment = PROBATFL) %>% 
  left_join(Prior_Placements) %>% 
  left_join(bind_rows(Offenses_Det,
                      Offenses_Ind)) %>% 
  mutate(Ref_3 = Referrals >= 3,
         Adj_2 = Adjudications >= 2) %>% 
  select(-Referrals, -Adjudications)

Test_Scores_First <- Test_Scores %>% 
  group_by(TJJD_Number, Subject) %>% 
  summarize(Score = first(Score),
            Test_Date = first(Test_Date)) %>% 
  pivot_wider(names_from = Subject,
              values_from = c(Test_Date, Score))

Treatment_Needs_First <- Treatment_Needs %>% 
  group_by(TJJD_Number) %>% 
  summarize(across(everything(), last)) %>% 
  ungroup() %>% 
  mutate(Mental_Health_Indicator = if_else(Mental_Health_Priority == "None"|Mental_Health_Priority == "L",0,1),
         Sexual_Behavior_Indicator = if_else(Sexual_Behavior_Priority == "None"|Sexual_Behavior_Priority == "L",0,1),
         Capital_and_Serious_Violent_Indicator = if_else(Capital_and_Serious_Violent_Priority == "None"|Capital_and_Serious_Violent_Priority == "L",0,1),
         Substance_Use_Indicator = if_else(Substance_Use_Priority == "None"|Substance_Use_Priority == "L",0,1),
         Number_Treatment_Needs = rowSums(across(Mental_Health_Indicator:Substance_Use_Indicator)))


#I've removed "Intake_Date" because it's not available in NEWPOPMFINAL. Don't know what to do about that.
#When comparing STMDY and INMDY from the All_Intakes table, STMDY is not always equal to
#INMDY, therefore, it's not a viable replacement.
#Something else is that Age_at_Intake is calculated off of the INMDY variable. Bc. it's not present,
#I can't calculate it. I can, however, replace Age_at_Intake with Age_at_Commitment_Start
Intakes_Format <- NewAdmissions %>%
  left_join(ID) %>% 
  left_join(Offenses_All) %>% 
  left_join(Treatment_Needs_First) %>% 
  left_join(Completed_ACE_Table) %>% 
  left_join(Test_Scores_First) %>%
  left_join(Spec_Ed) %>%
  mutate(DOB = as.Date(DOB),
         Age_at_Commitment_Start = floor(as.numeric(as.Date(Admission_Date) - as.Date(DOB)) / 365.25),
         Reading_to_Grade_Level = round(as.numeric(Test_Date_Reading - DOB)/365.25, 1) - Score_Reading - 5.5,
         Math_to_Grade_Level = round(as.numeric(Test_Date_Total_Math - DOB)/365.25, 1) - Score_Total_Math - 5.5,
         At_Grade_Level_Reading = if_else(Reading_to_Grade_Level > 0, 0, 1),
         At_Grade_Level_Math = if_else(Math_to_Grade_Level > 0, 0, 1))



#Excluding Last_Commitment_County because it's not relevant.
#Intake FY would be missing (no 1:1 replacement in NEWPOPMFINAL for INMDY).
#Replaced with Commitment FY.
#"Intake_Date" interestingly was associated with the STMDY variable,
# yet Age_At_Intake was calculated based off of INMDY.
# Intake Date was replaced with Commitment Start Date.
#"FelonyLevel" was replaced with "Classifying_Offense_Felony_Level"

Profile_Data <- Intakes_Format %>%
  separate(Admission_Date, into = c("Year", "Month", "Day"), convert = TRUE, remove = FALSE) %>%
  mutate("Intake_FY" = case_when(Month >= 9 ~ (Year + 1),
                                 TRUE ~ as.numeric(Year)
  )
  ) %>%
  select(TJJD_Number,
         First_Name,
         Last_Name,
         Sex,
         Race,
         Age_at_Intake = Age_at_Commitment_Start,
         Commitment_County,
         Classifying_Offense_Code,
         Classifying_Offense,
         Probation_at_Commitment:Adj_2,
         Intake_FY,
         Intake_Date = Admission_Date,
         FelonyLevel = Classifying_Offense_Felony_Level,
         Determinate = Determinate_Sentence,
         Reading_to_Grade_Level,
         At_Grade_Level_Reading,
         Math_to_Grade_Level,
         At_Grade_Level_Math,
         Special_Education,
         Mental_Health_Priority,
         Substance_Use_Priority,
         Sexual_Behavior_Priority,
         Capital_and_Serious_Violent_Priority,
         Mental_Health_Indicator,
         Substance_Use_Indicator,
         Sexual_Behavior_Indicator,
         Capital_and_Serious_Violent_Indicator,
         Number_Treatment_Needs,
         Emotional_Abuse:ACE_Score)

Profile_Data2 <- Profile_Data
Profile_Data2$Prior_Placement[is.na(Profile_Data2$Prior_Placement)] <- "FALSE"
Profile_Data2$Adj_2[is.na(Profile_Data2$Adj_2)] <- "FALSE"
Profile_Data2$Ref_3[is.na(Profile_Data2$Ref_3)] <- "FALSE"

Median_Below_Grade_Level <- Profile_Data %>% 
  group_by(Intake_FY) %>% 
  summarize(Median_Reading = median(Reading_to_Grade_Level, na.rm = TRUE),
            Median_Math = median(Math_to_Grade_Level, na.rm = TRUE)) %>% 
  mutate(across(everything(), as.character)) %>% 
  pivot_longer(Median_Reading:Median_Math, names_to = "Metric", values_to = "n")

Summary_Counts <- map_df(colnames(Profile_Data2 %>% 
                                    select(-c(TJJD_Number:Last_Name, Reading_to_Grade_Level, Math_to_Grade_Level))),
                         ~count(Profile_Data, Intake_FY, !!sym(.x)) %>% 
                           mutate(Metric = .x,
                                  across(everything(), as.character)) %>% 
                           rename(Variable = .x)
) %>% 
  bind_rows(Median_Below_Grade_Level) %>% 
  pivot_wider(names_from = Intake_FY, values_from = `n`)


Profile_Data2 <- Profile_Data2 %>%
  relocate(
    TJJD_Number,
    First_Name,
    Last_Name,
    Sex,
    Race,
    Age_at_Intake,
    Commitment_County,
    Classifying_Offense_Code,
    Classifying_Offense,
    Probation_at_Commitment,
    Prior_Placement,
    Ref_3,
    Adj_2,
    Intake_FY,
    Intake_Date,
    FelonyLevel,
    Determinate,
    Reading_to_Grade_Level,
    Math_to_Grade_Level,
    Special_Education,
    Emotional_Abuse,
    Emotional_Neglect,
    Family_Violence,
    Household_Mental_Illness,
    Household_Substance_Abuse,
    Incarcerated_Household_Member,
    Parents_Separated_Divorced,
    Physical_Abuse,
    Physical_Neglect,
    Sexual_Abuse,
    ACE_Score,
    At_Grade_Level_Reading,
    At_Grade_Level_Math,
    Substance_Use_Indicator,
    Sexual_Behavior_Indicator,
    Capital_and_Serious_Violent_Indicator,
    Substance_Use_Priority,
    Sexual_Behavior_Priority,
    Capital_and_Serious_Violent_Priority,
    Mental_Health_Priority,
    Mental_Health_Indicator,
    Number_Treatment_Needs
  )


group_count_percent <- function(.data, ...) {
  .data %>%
    dplyr::group_by(!!!rlang::ensyms(...)) %>%
    dplyr::summarise("Number" = dplyr::n()) %>%
    mutate(
      "Percent" = Number / sum(Number))
}

NAs <- Profile_Data2[rowSums(is.na(Profile_Data2)) > 0, ]

Profile_Comparison <- Cohort %>% 
  inner_join(Profile_Data2)

Gender <- Profile_Comparison %>%
  group_count_percent(Cohort, Sex)%>%
  mutate(Sex = recode(Sex, M =  "MALE", "F" = "FEMALE")) %>%
  arrange(desc(by = Sex)) %>%
  rename("Metric" = Sex) %>%
  mutate("Subcategory" = "GENDER")

Race_Ethnicity <- Profile_Comparison %>%
  mutate(Race = recode(Race,
                       "B" = "BLACK OR AFRICAN AMERICAN",
                       "W" = "WHITE",
                       "H" = "HISPANIC",
                       "A" = "OTHER",
                       "O" = "OTHER",
                       "AN" = "OTHER")) %>%
  group_count_percent(Cohort, Race) %>%
  ungroup() %>%
  arrange(match(Race, c("BLACK OR AFRICAN AMERICAN", "HISPANIC", "WHITE", "OTHER"))) %>%
  rename("Metric" = Race) %>%
  mutate("Subcategory" = "RACE/ETHNICITY")


Age_Admission <- Profile_Comparison %>%
  mutate(Metric = ifelse(Age_at_Intake %in% 10:14, "10 TO 14 YEARS",
                         ifelse(Age_at_Intake %in% 15:16, "15-16 YEARS",
                                ifelse(Age_at_Intake %in% 17:18, "17 OR OLDER", "NA")))) %>%
  group_count_percent(Cohort, Metric) %>%
  mutate("Subcategory" = "AGE AT ADMISSION")


#COMMITING OFFENSE
Sentence_Type <- Profile_Comparison %>%
  mutate(Metric = recode(Determinate,
                         "N" = "INDETERMINATE SENTENCE",
                         "Y" = "DETERMINATE SENTENCE")) %>%
  group_count_percent(Cohort, Metric) %>%
  mutate("Subcategory" = "SENTENCE TYPE") %>%
  arrange(desc(Metric))


Committing_Offense_Level <- Profile_Comparison %>%
  mutate(Metric = recode(FelonyLevel,
                         "CA" = "CAPITAL OFFENSE",
                         "F1" = "1ST DEGREE FELONY",
                         "F2" = "2ND DEGREE FELONY",
                         "F3" = "3RD DEGREE FELONY",
                         "SJ" = "STATE JAIL FELONY")) %>%
  group_count_percent(Cohort,Metric) %>%
  mutate("Subcategory" = "COMMITTING OFFENSE LEVEL") %>%
  arrange(match(Metric, c("CAPITAL OFFENSE", "1ST DEGREE FELONY", "2ND DEGREE FELONY", "3RD DEGREE FELONY", "STATE JAIL FELONY")))


#Risk Factors
TRUE_Ref_3 <- Profile_Comparison %>%
  group_count_percent(Cohort, Ref_3) %>%
  filter(Ref_3 == TRUE) %>%
  mutate(Variable = "THREE OR MORE PREVIOUS FELONY OR MISD REFERRALS")

TRUE_Adj_2 <- Profile_Comparison %>%
  group_count_percent(Cohort, Adj_2) %>%
  filter(Adj_2 == TRUE) %>%
  mutate(Variable = "TWO OR MORE PREVIOUS FELONY OR MISD ADJUDICATIONS")

TRUE_Prior_Placement <- Profile_Comparison %>%
  group_count_percent(Cohort, Prior_Placement) %>%
  filter(Prior_Placement == TRUE) %>%
  mutate(Variable = "PRIOR COURT-ORDERED OUT-OF-HOME PLACEMENT")

TRUE_Prob_at_Commit <- Profile_Comparison %>%
  group_count_percent(Cohort, Probation_at_Commitment) %>%
  filter(Probation_at_Commitment == "Y") %>%
  mutate(Variable = "ON PROBATION AT TIME OF COMMITMENT")


Formatted_Offense_History <- TRUE_Ref_3 %>%
  bind_rows(TRUE_Adj_2, TRUE_Prior_Placement, TRUE_Prob_at_Commit) %>%
  select(Cohort, Number, Percent, Variable) %>%
  rename("Metric" = Variable) %>%
  relocate(Cohort, Metric, Number, Percent) %>%
  mutate("Subcategory" = "OFFENSE HISTORY")


NewAdmissions_ExcludingACE_NAS <- Profile_Comparison %>%
  select("Emotional_Abuse":"Sexual_Abuse") %>%
  drop_na() %>%
  count()

Adverse_Childhood_Experiences <- Profile_Comparison %>%
  select(Cohort,"Emotional_Abuse":"Sexual_Abuse") %>%
  drop_na() %>%
  rename(
    "HISTORY OF EMOTIONAL ABUSE" = "Emotional_Abuse",
    "HISTORY OF PHYSICAL ABUSE" = "Physical_Abuse",
    "HISTORY SEXUAL ABUSE" = "Sexual_Abuse",
    "HISTORY OF EMOTIONAL NEGLECT" = "Emotional_Neglect",
    "HISTORY OF PHYSICAL NEGLECT" = "Physical_Neglect",
    "HISTORY OF FAMILY VIOLENCE" = "Family_Violence",
    "HOUSEHOLD SUBSTANCE ABUSE" = "Household_Substance_Abuse",
    "HOUSEHOLD MENTAL ILLNESS" = "Household_Mental_Illness",
    "PARENTS SEPARATED OR DIVORCED" = "Parents_Separated_Divorced",
    "INCARCERATED HOUSEHOLD MEMBER" = "Incarcerated_Household_Member"
  ) %>%
  group_by(Cohort) %>%
  summarise(across(everything(), ~ sum(.,0))) %>%
  pivot_longer(cols =  `HISTORY OF EMOTIONAL ABUSE`:`HISTORY SEXUAL ABUSE`, names_to = "Metric", values_to = "Number") %>%
  arrange(match(Metric, c("HISTORY OF EMOTIONAL ABUSE", "HISTORY OF PHYSICAL ABUSE","HISTORY SEXUAL ABUSE",
                          "HISTORY OF EMOTIONAL NEGLECT","HISTORY OF PHYSICAL NEGLECT","HISTORY OF FAMILY VIOLENCE",
                          "HOUSEHOLD SUBSTANCE ABUSE","HOUSEHOLD MENTAL ILLNESS","PARENTS SEPARATED OR DIVORCED",
                          "INCARCERATED HOUSEHOLD MEMBER"))) %>%
  inner_join(N_Cohort) %>% 
  mutate("Percent" = Number / n,
         "Subcategory" = "ADVERSE CHILDHOOD EXPERIENCES (ACES)") %>% 
  select(-n)



Total_Number_Of_ACES <- Profile_Comparison %>%
  mutate(Metric = case_when(ACE_Score %in% 0:1 ~ "0 to 1",
                            ACE_Score %in% 2:3 ~ "2 to 3",
                            ACE_Score %in% 4:5 ~ "4 to 5",
                            ACE_Score %in% 6:7 ~ "6 to 7",
                            ACE_Score %in% 8:10 ~ "8 to 10")) %>%
  filter(Metric != "NA") %>%
  group_count_percent(Cohort, Metric) %>%
  mutate("Subcategory" = "TOTAL NUMBER OF ACES")



#SPECIALIZED TREATMENT NEEDS
Treatment_Capital_And_Serious_Violent_Offender <- Profile_Comparison %>%
  filter(!is.na(Capital_and_Serious_Violent_Priority)) %>%
  mutate("Metric" = recode(Capital_and_Serious_Violent_Priority,
                           "HL2" = "HIGH NEED",
                           "H" = "HIGH NEED",
                           "M" = "MODERATE NEED",
                           "L" = "LOW NEED")) %>%
  group_count_percent(Cohort, Metric) %>%
  filter(Metric != "None") %>%
  ungroup() %>%
  split(~Cohort) %>%
  map_dfr(~ .x %>% add_row(Cohort = .$Cohort[1],
                           Metric = "ANY NEED",
                           Number = sum(.$Number),
                           Percent = sum(.$Percent))) %>%
  arrange(match(Metric, c("HIGH NEED", "MODERATE NEED", "LOW NEED", "ANY NEED"))) %>%
  mutate("Subcategory" = "CAPITAL AND SERIOUS VIOLENT OFFENDER TREATMENT")


Treatment_Sexual_Behavior <- Profile_Comparison %>%
  filter(!is.na(Sexual_Behavior_Priority)) %>%
  mutate("Metric" = recode(Sexual_Behavior_Priority,
                           "H" = "HIGH NEED",
                           "M" = "MODERATE NEED",
                           "L" = "LOW NEED")) %>%
  group_count_percent(Cohort, Metric) %>%
  filter(Metric != "None") %>%
  ungroup() %>%
  split(~Cohort) %>%
  map_dfr(~ .x %>% add_row(Cohort = .$Cohort[1],
                           Metric = "ANY NEED",
                           Number = sum(.$Number),
                           Percent = sum(.$Percent))) %>%
  arrange(match(Metric, c("HIGH NEED", "MODERATE NEED", "LOW NEED", "ANY NEED"))) %>%
  mutate("Subcategory" = "SEXUAL BEHAVIOR TREATMENT")


Treatment_Alcohol_or_Drug <- Profile_Comparison %>%
  filter(!is.na(Substance_Use_Priority)) %>%
  mutate("Metric" = recode(Substance_Use_Priority,
                           "H" = "HIGH NEED",
                           "M" = "MODERATE NEED",
                           "L" = "LOW NEED")) %>%
  group_count_percent(Cohort, Metric) %>%
  filter(Metric != "None") %>%
  ungroup() %>%
  split(~Cohort) %>%
  map_dfr(~ .x %>% add_row(Cohort = .$Cohort[1],
                           Metric = "ANY NEED",
                           Number = sum(.$Number),
                           Percent = sum(.$Percent))) %>%
  arrange(match(Metric, c("HIGH NEED", "MODERATE NEED", "LOW NEED"))) %>%
  mutate("Subcategory" = "ALCOHOL OR OTHER DRUG TREATMENT")


Treatment_Mental_Health <- Profile_Comparison %>%
  filter(!is.na(Mental_Health_Priority)) %>%
  mutate("Metric" = recode(Mental_Health_Priority,
                           "HL2" = "HIGH NEED",
                           "H" = "HIGH NEED",
                           "M" = "MODERATE NEED",
                           "L" = "LOW NEED")) %>%
  group_count_percent(Cohort, Metric) %>%
  filter(Metric != "None") %>%
  ungroup() %>%
  split(~Cohort) %>%
  map_dfr(~ .x %>% add_row(Cohort = .$Cohort[1],
                           Metric = "ANY NEED",
                           Number = sum(.$Number),
                           Percent = sum(.$Percent))) %>%
  arrange(match(Metric, c("HIGH NEED", "MODERATE NEED", "LOW NEED"))) %>%
  mutate("Subcategory" = "MENTAL HEALTH TREATMENT")


Overall_Treatment_Needs <- Profile_Comparison %>%
  group_by(Cohort) %>%
  summarise("AllYouth" = sum(Number_Treatment_Needs >= 0, na.rm = TRUE),
            "ANY SPECIALIZED TREATMENT NEED" = sum(Number_Treatment_Needs >= 1, na.rm = TRUE),
            "TWO OR MORE SPECIALIZED TREATMENT NEEDS" = sum(Number_Treatment_Needs >= 2, na.rm = TRUE),
            "THREE OR MORE SPECIALIZED TREATMENT NEEDS" = sum(Number_Treatment_Needs >= 3, na.rm = TRUE)) %>%
  pivot_longer(cols = `ANY SPECIALIZED TREATMENT NEED`:`THREE OR MORE SPECIALIZED TREATMENT NEEDS`, names_to = "Metric", values_to = "Number") %>%
  mutate("Percent" = Number / AllYouth,
         "Subcategory" = "OVERALL TREATMENT NEEDS") %>%
  select(!AllYouth)


#Education
Special_Education_Eligible <- Profile_Comparison %>%
  group_count_percent(Cohort, Special_Education) %>%
  filter(Special_Education == "Y") %>%
  rename("Metric" = Special_Education) %>%
  mutate(Metric = recode(Metric, "Y" = "SPECIAL EDUCATION ELIGIBLE")) %>%
  mutate("Subcategory" = "SPECIAL EDUCATION ELIGIBLE")


Reading_Below_Grade_Level <- Profile_Comparison %>%
  filter(!is.na(At_Grade_Level_Reading)) %>%
  group_count_percent(Cohort, At_Grade_Level_Reading) %>%
  mutate(At_Grade_Level_Reading = recode(At_Grade_Level_Reading,
                                         "0" = "READING ACHIEVEMENT BELOW GRADE LEVEL",
                                         "1" = "READING ACHIEVEMENT AT GRADE LEVEL")) %>%
  filter(At_Grade_Level_Reading == "READING ACHIEVEMENT BELOW GRADE LEVEL") %>%
  rename("Metric" = At_Grade_Level_Reading) %>%
  mutate("Subcategory" = "ACHIEVEMENT BELOW GRADE LEVEL")


Math_Below_Grade_Level <- Profile_Comparison %>%
  filter(!is.na(At_Grade_Level_Math)) %>%
  group_count_percent(Cohort, At_Grade_Level_Math) %>%
  mutate(At_Grade_Level_Math = recode(At_Grade_Level_Math,
                                      "0" = "MATH ACHIEVEMENT BELOW GRADE LEVEL",
                                      "1" = "MATH ACHIEVEMENT AT GRADE LEVEL")) %>%
  filter(At_Grade_Level_Math == "MATH ACHIEVEMENT BELOW GRADE LEVEL") %>%
  rename("Metric" = At_Grade_Level_Math) %>%
  mutate("Subcategory" = "ACHIEVEMENT BELOW GRADE LEVEL")


Reading_Median_Years_Below_Grade_Level <- Profile_Comparison %>%
  filter(!is.na(Reading_to_Grade_Level)) %>%
  group_by(Cohort) %>%
  summarise(
    "Number" = median(Reading_to_Grade_Level)) %>%
  mutate("Metric" = "MEDIAN YEARS BELOW GRADE LEVEL IN READING") %>%
  mutate("Subcategory" = "MEDIAN YEARS BELOW GRADE LEVEL")


Math_Median_Years_Below_Grade_Level <- Profile_Comparison %>%
  filter(!is.na(Math_to_Grade_Level)) %>%
  group_by(Cohort) %>%
  summarise("Number" = median(Math_to_Grade_Level)) %>%
  mutate("Metric" = "MEDIAN YEARS BELOW GRADE LEVEL IN MATH") %>%
  mutate("Subcategory" = "MEDIAN YEARS BELOW GRADE LEVEL")


# Bringing it all together! -------------------------------------------------------------
Format <- data.frame(Category = character(),
                     Subcategory = character(),
                     Metric = character(),
                     Number = integer(),
                     Cohort = character(),
                     Percent = integer())

Dashboard_Format <- Format %>%
  bind_rows(Gender,
            Race_Ethnicity,
            Age_Admission,
            Sentence_Type,
            Committing_Offense_Level,
            Formatted_Offense_History,
            Adverse_Childhood_Experiences,
            Total_Number_Of_ACES,
            Treatment_Capital_And_Serious_Violent_Offender,
            Treatment_Alcohol_or_Drug,
            Treatment_Sexual_Behavior,
            Treatment_Mental_Health,
            Overall_Treatment_Needs,
            Special_Education_Eligible,
            Reading_Below_Grade_Level,
            Math_Below_Grade_Level,
            Reading_Median_Years_Below_Grade_Level,
            Math_Median_Years_Below_Grade_Level) %>%
  mutate(Percent = round(Percent * 100, 2)) %>%
  mutate("Category" = case_when(Subcategory == "NUMBER OF NEW ADMISSIONS" ~ "NUMBER OF NEW ADMISSIONS",
                                Subcategory %in% c("GENDER", "RACE/ETHNICITY", "AGE AT ADMISSION", "CITIZENSHIP STATUS") ~ "Demographics",
                                Subcategory %in% c("SENTENCE TYPE", "COMMITTING OFFENSE LEVEL") ~ "COMMITTING OFFENSE",
                                Subcategory %in% c("OFFENSE HISTORY", "ADVERSE CHILDHOOD EXPERIENCES (ACES)", "TOTAL NUMBER OF ACES", 
                                                   "OFFENSE HISTORY") ~ "RISK FACTORS",
                                Subcategory %in% c("CAPITAL AND SERIOUS VIOLENT OFFENDER TREATMENT", "SEXUAL BEHAVIOR TREATMENT",
                                                   "ALCOHOL OR OTHER DRUG TREATMENT", "MENTAL HEALTH TREATMENT", "OVERALL TREATMENT NEEDS") ~ "SPECIALIZED TREATMENT NEEDS",
                                Subcategory %in% c("SPECIAL EDUCATION ELIGIBLE", "ACHIEVEMENT BELOW GRADE LEVEL", "MEDIAN YEARS BELOW GRADE LEVEL") ~ "EDUCATION",
                                Subcategory == TRUE ~ "NA")) %>%
  relocate(Category, Subcategory, Metric, Cohort) %>%
  drop_na() %>% 
  pivot_wider(names_from = Cohort, values_from = c(Number, Percent), values_fill = 0)
