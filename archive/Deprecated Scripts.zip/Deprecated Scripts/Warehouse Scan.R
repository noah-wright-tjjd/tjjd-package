library(TJJD)

source("R/DB/Warehouse.R")

Warehouse_Tables <- sqlTables(Warehouse) %>% 
  filter(TABLE_SCHEM == "dbo")

Warehouse_Samples <- map(Warehouse_Tables$TABLE_NAME,
                         ~sqlQuery(Warehouse, str_c("Select top 1000 * from ", .x)))

names(Warehouse_Samples) <- Warehouse_Tables$TABLE_NAME

view(Warehouse_Samples$StayIntake)
