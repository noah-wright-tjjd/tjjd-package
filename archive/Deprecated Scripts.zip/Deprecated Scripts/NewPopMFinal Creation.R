library(TJJD)
library(compareDF)
library(htmltools)

#Parameterize and functionalize this

Output_Tables <- c("popas", "popm", "idmc")
Fix_Tables <- c("popasfx", "popmfx", "idmcfx")

Output_Current <- map(Output_Tables, ~import(str_c("R:\\ZPSAS\\", .x, ".sas7bdat")))
Output_Prior <- map(Output_Tables, ~import(str_c("R:\\ZPSASPrior\\", .x, ".sas7bdat")))

Fix_Current <- map(Fix_Tables, ~import(str_c("R:\\ZPSAS\\", .x, ".sas7bdat")))
Fix_Prior <- map(Fix_Tables, ~import(str_c("R:\\ZPSASPrior\\", .x, ".sas7bdat")))

NewPopMFinal_Current <- import("R:\\ZPSAS\\newpopmfinal.sas7bdat")
NewPopMFinal_Prior <- import("R:\\ZPSASPrior\\newpopmfinal.sas7bdat")

names(Output_Current) <- Output_Tables
names(Output_Prior) <- Output_Tables

names(Fix_Current) <- Fix_Tables
names(Fix_Prior) <- Fix_Tables

Truncation <- Output_Current$popm %>% 
  group_by(TYCNO) %>% 
  filter(as.Date(max(ENDMDY), origin = '1960-01-01') >= "2018-09-01") %>% 
  pull(TYCNO) %>% 
  unique()

Output_Current$idmc %>% 
  filter(TYCNO == 1296358) %>% 
  view()

Current_Tables_Truncated <- map(c(Output_Current, Fix_Current), function(x) {
  x %>% 
    filter(TYCNO %in% Truncation) %>% 
    mutate(across(contains("MDY"), ~as.Date(.x, "1960-01-01")))
})

Prior_Tables_Truncated <- map(c(Output_Prior, Fix_Prior), function(x) {
  x %>% 
    filter(TYCNO %in% Truncation) %>% 
    mutate(across(contains("MDY"), ~as.Date(.x, "1960-01-01")))
})

Current_Prior_Comparisons <- map2(Current_Tables_Truncated, Prior_Tables_Truncated, 
                                  ~compare_df(.x, .y, group = c("TYCNO", "MFPTR")))

Column_Match <- data.frame(NewPopMFinal = colnames(NewPopMFinal_Current)) %>% 
  mutate(Join = NewPopMFinal) %>% 
  full_join(data.frame(PopM = colnames(Output_Current$popm)) %>% 
              mutate(Join = PopM)) %>% 
  full_join(data.frame(PopMFX = colnames(Fix_Current$popmfx)) %>% 
              mutate(Join = PopMFX)) %>% 
  full_join(data.frame(IDMC = colnames(Output_Current$idmc)) %>% 
              mutate(Join = IDMC)) %>% 
  full_join(data.frame(IDMCFX = colnames(Fix_Current$idmcfx)) %>% 
              mutate(Join = IDMCFX)) %>% 
  full_join(data.frame(PopAS = colnames(Output_Current$popas)) %>% 
              mutate(Join = PopAS)) %>% 
  full_join(data.frame(PopASFX = colnames(Fix_Current$popasfx)) %>% 
              mutate(Join = PopASFX)) %>% 
  select(-Join)

popas_commoncols <- colnames(Output_Current$popas)
popm_commoncols <- Column_Match %>% filter(!is.na(PopM), !is.na(PopMFX)) %>% pull(PopM)
idmc_commoncols <- Column_Match %>% filter(!is.na(IDMC), !is.na(IDMCFX)) %>% pull(IDMC)

NewPopForEachIDMC_Source <- map(Current_Tables_Truncated, ~.x %>% 
      filter(TYCNO == 1286500))

NewPopForEachPOPM_Source <- map(Current_Tables_Truncated, ~.x %>% 
                                  filter(TYCNO == 1296358))

PopMCompare1 <- NewPopForEachIDMC_Source$popm %>% 
  mutate(across(everything(), as.character)) %>% 
  pivot_longer(everything(), names_to = "Variable", values_to = "Value")

IDMCCompare1 <- NewPopForEachIDMC_Source$idmc %>% 
       mutate(across(everything(), as.character)) %>% 
       pivot_longer(everything(), names_to = "Variable", values_to = "Value")

NewPopMFinalCompare1 <- NewPopMFinal_Current %>% 
  filter(TYCNO == 1286500) %>% 
  mutate(across(everything(), as.character),
         UID = str_c(TYCNO, " NewPopM Entry Number ", row_number())) %>% 
  pivot_longer(-UID, names_to = "Variable", values_to = "Value") %>% 
  pivot_wider(names_from = UID, values_from = Value)

PopMCompare2 <- NewPopForEachPOPM_Source$popm %>% 
  mutate(across(everything(), as.character)) %>% 
  pivot_longer(everything(), names_to = "Variable", values_to = "Value")

IDMCCompare2 <- NewPopForEachPOPM_Source$idmc %>% 
  mutate(across(everything(), as.character)) %>% 
  pivot_longer(everything(), names_to = "Variable", values_to = "Value")

NewPopMFinalCompare2 <- NewPopMFinal_Current %>% 
  filter(TYCNO == 1296358) %>% 
  mutate(across(everything(), as.character),
         UID = str_c(TYCNO, " NewPopM Entry Number ", row_number())) %>% 
  pivot_longer(-UID, names_to = "Variable", values_to = "Value") %>% 
  pivot_wider(names_from = UID, values_from = Value)

view(inner_join(NewPopMFinalCompare1, NewPopMFinalCompare2))

#PopM is one entry per primary commitment. UID is TYCNO and MFPTR.

UID_Check <- Current_Tables_Truncated$popm %>% 
  group_by(TYCNO, MFPTR) %>% 
  filter(n() > 1)

#For reasons unknown, PopMfx breaks this UID. MCPTR is not helping clear up this
#confusion.

UID_Check <- Current_Tables_Truncated$popmfx %>% 
#  select(TYCNO, MFPTR, MCPTR) %>% 
  group_by(TYCNO, MFPTR, MCPTR) %>% 
  filter(n() > 1)

#IDMC is one entry per commitment and revocation record. UID is TYCNO and MCPTR.
#Multiple commits all at once show up at the same time. PRIMARY designates the
#primary commitment.

#Both idmc and idmcfx break this UID for unclear reasons.

UID_Check <- Current_Tables_Truncated$idmc %>% 
  group_by(TYCNO, MCPTR) %>% 
  filter(n() > 1)

Primary_Check <- Current_Tables_Truncated$idmc %>% 
  filter(PRIMARY == "Y") %>% 
  group_by(TYCNO, PRIMSTMDY) %>% 
  filter(n() > 1)

#Newpopmfinal exists to differentiate between multiple simultaneous commitments
#with one primary and a youth moving through a series of commitments, as well as
#to apply fixes to broken M204 records. 

#UID is one entry per TYCNO and IDMC record that gets transferred. A new
#variable, "IDMC", is created to keep track of this. Maybe. The problem being
#that the fix process creates entirely new manual entries, so it doesn't quite
#correspond to any join one can do between tables.

UID_Check <- NewPopMFinal_Current %>% 
  group_by(TYCNO, IDMC) %>% 
  filter(n() > 1)

#So now the question is - how do we join popmfx to idmcfx to get newpopmfinal?
#Absent the corrections, of course. Looks like one entry per commitment date
#might be one way.

Join_MF <- Fix_Current$popm %>% 
  filter(TYCNO %in% Truncation) %>% 
  ungroup() %>% 
  inner_join(Fix_Current$idmc %>% 
               count(TYCNO, MFPTR, CMTMDY),
             by = c("TYCNO", "MFPTR")) %>% 
  count(TYCNO, MFPTR)

NewPopMFinal_MF <- NewPopMFinal_Current %>% 
  filter(TYCNO %in% Truncation) %>% 
  count(TYCNO, MFPTR)

MF_Mismatch <- Join_MF %>% 
  full_join(NewPopMFinal_MF, by = c("TYCNO", "MFPTR")) %>% 
  filter(n.x != n.y)

NewPopMFinal_Original <- Column_Match %>% 
  filter(!is.na(NewPopMFinal),
         is.na(PopM),
         is.na(IDMC))

# list2env(Current_Tables_Truncated, .GlobalEnv)
# list2env(Prior_Tables_Truncated, .GlobalEnv)

#save_html()